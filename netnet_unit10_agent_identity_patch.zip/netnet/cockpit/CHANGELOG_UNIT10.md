## Unit 10 — Agent Identity (minimal)

- Adds local-only identity storage (display name, Base wallet, optional ERC‑8004/profile URL)
- New page: /identity
- Helper components for embedding in Proof/Execute flows
