Unit 4 patch: Bridge API proxy routes + validation + cache + normalized errors.

After applying:
- Ensure zod is installed (already used elsewhere? If not: `npm i zod` inside netnet/cockpit)
- Set BRIDGE_API_BASE_URL / BRIDGE_API_KEY if you have Bridge access.
