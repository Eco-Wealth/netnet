import { NextRequest, NextResponse } from "next/server";
import { loadPolicyConfig } from "@/lib/policy/config";
import { getProgramStatus, pauseProgram, resumeProgram } from "@/lib/policy/circuitBreaker";
import type { ProgramId } from "@/lib/policy/types";

export const dynamic = "force-dynamic";

function isProgramId(x: any): x is ProgramId {
  return ["TRADING_LOOP", "TOKEN_OPS", "MICRO_RETIRE", "SDG_WORK", "RESTAURANT_OPS"].includes(String(x));
}

export async function GET() {
  const cfg = loadPolicyConfig();
  const statuses = Object.values(cfg.programs).map((p) => getProgramStatus(p.id, p.anomalies.windowSeconds));
  return NextResponse.json({ ok: true, policy: cfg, statuses });
}

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const action = String(body.action || "");
  const programId = body.programId;

  if (!isProgramId(programId)) {
    return NextResponse.json({ ok: false, error: { code: "BAD_REQUEST", message: "programId required" } }, { status: 400 });
  }

  if (action === "pause") {
    const minutes = Number(body.minutes || 15);
    const reason = String(body.reason || "operator_pause");
    pauseProgram(programId, Math.max(1, minutes) * 60, reason);
    return NextResponse.json({ ok: true, programId, paused: true, minutes });
  }

  if (action === "resume") {
    resumeProgram(programId);
    return NextResponse.json({ ok: true, programId, paused: false });
  }

  return NextResponse.json(
    { ok: false, error: { code: "BAD_REQUEST", message: "action must be pause|resume" } },
    { status: 400 }
  );
}
