
export default function Home() {
  return (
    <main>
      <h1>Regen Network 2.0</h1>
      <p>Explorer • Dashboard • Game</p>
    </main>
  );
}
