
export default function Explorer() {
  return (
    <div>
      <h2>Blockchain Explorer</h2>
      <p>Blocks, Transactions, Ecocredits</p>
    </div>
  );
}
