
export default function Game() {
  return (
    <div>
      <h2>Regenerative Strategy Game</h2>
      <p>Simulate ecological impact and token allocation</p>
    </div>
  );
}
