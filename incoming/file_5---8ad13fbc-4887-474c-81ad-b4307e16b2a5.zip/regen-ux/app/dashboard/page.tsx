
export default function Dashboard() {
  return (
    <div>
      <h2>Network Dashboard</h2>
      <p>Issuance, Retirements, Liquidity</p>
    </div>
  );
}
