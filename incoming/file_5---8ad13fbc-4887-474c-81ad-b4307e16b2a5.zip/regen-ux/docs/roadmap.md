
# Build Roadmap

Phase 1: Explorer
- Block viewer
- Transaction decoder
- Ecocredit viewer

Phase 2: Dashboard
- Issuance metrics
- Retirement charts
- Liquidity heatmap

Phase 3: Game
- Impact scoring engine
- Strategy mechanics
- Leaderboard

Each feature can be developed as an independent unit.
