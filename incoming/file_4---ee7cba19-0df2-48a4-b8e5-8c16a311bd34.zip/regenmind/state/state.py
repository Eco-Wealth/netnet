
class SystemState:
    def __init__(self):
        self.data = {}
