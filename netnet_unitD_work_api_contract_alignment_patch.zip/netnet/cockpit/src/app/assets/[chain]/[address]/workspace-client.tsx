"use client";

import { useMemo, useState } from "react";

type Json = Record<string, any>;

async function getJSON<T>(url: string): Promise<T> {
  const res = await fetch(url, { cache: "no-store" });
  const body = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(body?.error || `HTTP ${res.status}`);
  return body as T;
}

export default function AssetWorkspaceClient({
  chain,
  address,
}: {
  chain: string;
  address: string;
}) {
  const assetKey = useMemo(() => `${chain}:${address}`, [chain, address]);
  const [scan, setScan] = useState<Json | null>(null);
  const [work, setWork] = useState<Json | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function runScan() {
    setBusy(true);
    setErr(null);
    try {
      // NOTE: canonical scan contract may be hash-only; Unit E will clarify/align.
      const q = new URLSearchParams({ hash: address });
      const data = await getJSON<Json>(`/api/ecotoken/scan?${q.toString()}`);
      setScan(data);
    } catch (e: any) {
      setErr(e?.message || "Scan failed");
    } finally {
      setBusy(false);
    }
  }

  async function createWorkItem() {
    setBusy(true);
    setErr(null);
    try {
      const res = await fetch("/api/work", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          title: `Asset workspace: ${assetKey}`,
          description: `Seed work item created from Asset Workspace for ${assetKey}. Operator review required before any execution.`,
          tags: ["asset-workspace", chain],
          priority: "MEDIUM",
          owner: "operator",
          status: "PROPOSED",
          meta: { chain, address },
        }),
      });

      const body = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(body?.error || `HTTP ${res.status}`);
      setWork(body);
    } catch (e: any) {
      setErr(e?.message || "Create work failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="grid gap-3">
      <div className="rounded-2xl border border-white/10 bg-white/5 p-3">
        <div className="text-sm font-semibold">Asset</div>
        <div className="text-xs text-white/70">{assetKey}</div>
      </div>

      <div className="flex flex-wrap gap-2">
        <button
          className="rounded-xl border border-white/15 bg-white/10 px-3 py-2 text-sm hover:bg-white/15 disabled:opacity-50"
          onClick={runScan}
          disabled={busy}
          title="Call /api/ecotoken/scan for this asset (contract clarified in Unit E)"
        >
          Run scan
        </button>
        <button
          className="rounded-xl border border-white/15 bg-white/10 px-3 py-2 text-sm hover:bg-white/15 disabled:opacity-50"
          onClick={createWorkItem}
          disabled={busy}
          title="Create a Work item in /api/work for this asset"
        >
          Create work
        </button>
      </div>

      {err ? (
        <div className="rounded-2xl border border-red-500/30 bg-red-500/10 p-3 text-sm">
          {err}
        </div>
      ) : null}

      {scan ? (
        <div className="rounded-2xl border border-white/10 bg-white/5 p-3">
          <div className="text-sm font-semibold">Scan</div>
          <pre className="mt-2 overflow-auto text-xs text-white/80">{JSON.stringify(scan, null, 2)}</pre>
        </div>
      ) : null}

      {work ? (
        <div className="rounded-2xl border border-white/10 bg-white/5 p-3">
          <div className="text-sm font-semibold">Work</div>
          <pre className="mt-2 overflow-auto text-xs text-white/80">{JSON.stringify(work, null, 2)}</pre>
        </div>
      ) : null}
    </div>
  );
}
