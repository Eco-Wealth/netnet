# Skill: netnet-cockpit (agent operator)

## Purpose
Programmatic carbon retirement workflow + verifiable proof artifacts via Netnet Cockpit.

## Guardrails (non-negotiable)
- Never move funds automatically. Only return payment *instructions* unless the operator explicitly confirms.
- Never request or handle private keys or seed phrases.
- Enforce spend limits and require a human-provided `beneficiaryName` and `reason` for any retirement initiation.
- If Bridge or paywall config is missing, return a clear error and stop.

## Base URLs
- Cockpit: `https://<host>`
- Health: `GET /api/health`

## Agent API: Carbon

### 1) Discover capabilities
`GET /api/agent/carbon?action=info`

Expected:
- supported chains/tokens defaults
- paywall requirements (if any)
- required inputs for POST

### 2) (Optional) Estimate compute footprint
`GET /api/agent/carbon?action=estimate&computeHours=<number>&modelSize=<string>`

Return should include:
- `ok:true`
- `estimate` fields
- `nextAction` guidance

### 3) List / search projects
`GET /api/agent/carbon?action=projects`

If filtering is supported, pass query params (e.g., `search=`).

### 4) Get quote
`GET /api/agent/carbon?action=quote&projectId=<id>&amount=<credits>&token=<token>&chain=<chain>`

Validate:
- `amount` is numeric and within safe bounds
- token/chain supported

### 5) Initiate retirement (safe-by-default)
`POST /api/agent/carbon`

Body:
```json
{
  "projectId": "...",
  "amount": 1,
  "chain": "base",
  "token": "usdc",
  "beneficiaryName": "<required>",
  "reason": "<required>"
}
```

Expected response:
- `ok:true`
- `payment` object (recipient, amount, token, chain)
- `txHint` instructions
- `nextAction: "pay"`

### 6) Track status
`GET /api/agent/carbon?action=status&txHash=<0x...>`

Expected:
- lifecycle state
- `certificateId` and/or `refs.url` once retired
- `nextAction` e.g. `wait`, `verify`, `build_proof`

## Proof builder

### Build proof object
`POST /api/proof/build`

Body:
```json
{
  "kind": "bridge_retirement",
  "txHash": "0x...",
  "certificateId": "...",
  "url": "...",
  "subject": {
    "agentId": "optional",
    "wallet": "optional",
    "operator": "optional"
  }
}
```

Output:
- deterministic `proof` JSON with `schema: "netnet.proof.v1"`

## Operational checklist (agent)
1. Call `/api/health` and stop if non-200.
2. Call `carbon?action=info` and confirm required env/config.
3. Quote first; do not initiate if the quote exceeds operator limits.
4. For POST initiate: require `beneficiaryName` + `reason`.
5. Return payment instructions only; operator executes payment externally.
6. Poll `status` until `certificateId` appears.
7. Build proof; return proof JSON + short/long share text.
