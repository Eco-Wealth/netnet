import { WalletStatePanel } from "@/components/WalletStatePanel";

export default function WalletPage() {
  return <WalletStatePanel />;
}
