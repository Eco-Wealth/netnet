import { Shell } from "@/components/Shell";
import { OpsConsole } from "@/components/ops/OpsConsole";

export default function OpsPage() {
  return (
    <Shell>
      <OpsConsole />
    </Shell>
  );
}
