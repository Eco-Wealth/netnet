import Workbench from "@/components/work/Workbench";

export default function Page() {
  return <Workbench />;
}
