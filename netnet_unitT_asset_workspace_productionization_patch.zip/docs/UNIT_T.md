# Unit T — Asset Workspace Productionization (dense + guided)

Adds:
- A compact "insight dock" for the asset workspace that explains:
  what it is, what it can do, what it cannot do, and what each action returns.
- Lightweight tx-hash guard so users don't hit confusing 400s.

Safety:
- Still read-only / propose-only.
