export type FeeRouting = {
  currency: "USD";
  estimatedUsd: number;
  split: {
    operatorUsd: number;
    inferenceUsd: number;
    microRetireUsd: number;
    treasuryUsd: number;
  };
  policy: {
    operatorBps: number;
    inferenceBps: number;
    microRetireBps: number;
    treasuryBps: number;
  };
};

// Default split. Override with ENV later if desired.
const DEFAULT_POLICY_BPS = {
  operatorBps: 3500,
  inferenceBps: 2500,
  microRetireBps: 1000,
  treasuryBps: 3000,
};

function clamp(n: number): number {
  if (!Number.isFinite(n)) return 0;
  return Math.max(0, n);
}

export function feeRouting(estimatedUsd: number, policy = DEFAULT_POLICY_BPS): FeeRouting {
  const usd = clamp(estimatedUsd);
  const totalBps =
    policy.operatorBps + policy.inferenceBps + policy.microRetireBps + policy.treasuryBps;

  // If policy sums wrong, normalize proportionally.
  const norm = totalBps === 0 ? 1 : totalBps;
  const operator = (usd * policy.operatorBps) / norm;
  const inference = (usd * policy.inferenceBps) / norm;
  const microRetire = (usd * policy.microRetireBps) / norm;
  const treasury = (usd * policy.treasuryBps) / norm;

  return {
    currency: "USD",
    estimatedUsd: usd,
    split: {
      operatorUsd: Number(operator.toFixed(6)),
      inferenceUsd: Number(inference.toFixed(6)),
      microRetireUsd: Number(microRetire.toFixed(6)),
      treasuryUsd: Number(treasury.toFixed(6)),
    },
    policy,
  };
}
