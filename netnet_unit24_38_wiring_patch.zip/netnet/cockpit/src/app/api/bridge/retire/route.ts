import { NextRequest } from "next/server";
import { withObsJson } from "@/lib/obs";
import { feeRouting } from "@/lib/economics";

// Wiring: every operator-approved retirement should emit economics metadata for fee routing
export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const estimatedUsd = typeof body?.estimatedUsd === "number" ? body.estimatedUsd : 0;
  const econ = feeRouting(estimatedUsd);

  return withObsJson(req, "/api/bridge/retire", {
    ok: true,
    mode: "PROPOSE_ONLY",
    message: "Retirement execution is operator-approved. Provide beneficiaryName, reason, and payment confirmation before broadcast.",
    inputEcho: {
      beneficiaryName: body?.beneficiaryName,
      reason: body?.reason,
      amount: body?.amount,
      denom: body?.denom,
    },
    economics: econ,
    nextAction: "Call /api/bridge/quote then /api/bridge/tx for a payable packet; once paid, call /api/bridge/status to finalize proof.",
  });
}
