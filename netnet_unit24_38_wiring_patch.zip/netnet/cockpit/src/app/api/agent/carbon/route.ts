import { NextRequest } from "next/server";
import { withObsJson } from "@/lib/obs";
import { feeRouting } from "@/lib/economics";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const action = (searchParams.get("action") || "info").toLowerCase();

  if (action === "info") {
    // economics here represents expected operator/inference/micro-retire split for a future retirement request
    const econ = feeRouting(0);
    return withObsJson(req, "/api/agent/carbon", {
      ok: true,
      actions: ["info", "estimate", "projects", "quote", "status"],
      nextAction: "projects",
      safety: {
        postRequires: ["beneficiaryName", "reason"],
        note: "POST initiates a retirement request; payment must be explicitly confirmed by an operator.",
      },
      economics: econ,
    });
  }

  return withObsJson(
    req,
    "/api/agent/carbon",
    { ok: false, error: { code: "UNSUPPORTED_ACTION", message: `Unsupported action: ${action}` } },
    { status: 400 }
  );
}
