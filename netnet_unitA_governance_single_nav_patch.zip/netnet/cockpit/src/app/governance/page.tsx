import GovernancePolicyEditor from "@/components/GovernancePolicyEditor";

export default function GovernancePage() {
  return (
    <div className="grid gap-4">
      <GovernancePolicyEditor />
    </div>
  );
}
