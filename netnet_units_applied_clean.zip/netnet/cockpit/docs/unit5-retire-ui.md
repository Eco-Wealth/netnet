# Unit 5 — Retire Tab UI

Adds a mobile-first Retire page implementing a safe-by-default flow:
1. Select project
2. Enter credit amount
3. Payment instructions (Bridge)
4. Paste tx hash
5. Track + generate proof

No funds are moved automatically.
