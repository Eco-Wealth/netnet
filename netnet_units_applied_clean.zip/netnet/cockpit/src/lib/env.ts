export const BRIDGE_ECO_API_BASE =
  process.env.BRIDGE_ECO_API_BASE ?? "https://api.bridge.eco";

export const ECOTOKEN_SCAN_BASE =
  process.env.ECOTOKEN_SCAN_BASE ?? "https://scan.ecotoken.earth";
