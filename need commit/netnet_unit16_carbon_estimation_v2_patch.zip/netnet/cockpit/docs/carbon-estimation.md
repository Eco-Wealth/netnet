# Carbon estimation (v2)

Endpoint:
- `GET /api/agent/carbon?action=estimate&computeHours=<number>&modelSize=<tiny|small|medium|large|xl>`

Optional overrides (advanced):
- `pue` (default 1.3)
- `gridIntensityKgPerKwh` (default 0.4)
- `pricePerTonUsd` (default 25)

Response shape:
```json
{
  "ok": true,
  "estimate": {
    "kgCO2e": 1.234,
    "tonsCO2e": 0.001234,
    "estimatedRetirementCostUsd": 0.03,
    "bounds": { "lowKgCO2e": 0.617, "highKgCO2e": 1.851 },
    "confidence": { "level": "low", "notes": ["..."] },
    "methodology": {
      "version": "netnet.estimate.v2",
      "formula": "kWh = hours * kW * PUE; kgCO2e = kWh * gridIntensity",
      "assumptions": { "modelSize": "small", "powerKw": 0.5, "pue": 1.3, "gridIntensityKgPerKwh": 0.4, "pricePerTonUsd": 25 }
    }
  },
  "nextAction": "projects"
}
```

Notes:
- This is a planning estimate intended to be conservative and safe-by-default.
- Bounds are intentionally wide (±50%) until we wire in real telemetry (provider logs, kWh metering, or verified regional intensity).
