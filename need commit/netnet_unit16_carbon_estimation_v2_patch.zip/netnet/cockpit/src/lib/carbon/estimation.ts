import { z } from "zod";

export const CarbonEstimateInputSchema = z.object({
  computeHours: z.number().positive(),
  modelSize: z.enum(["tiny", "small", "medium", "large", "xl"]).default("small"),
  // Optional override knobs (advanced). If omitted, we use conservative defaults.
  pue: z.number().min(1).max(3).default(1.3),
  gridIntensityKgPerKwh: z.number().min(0.01).max(2).default(0.4),
  pricePerTonUsd: z.number().min(0).max(1000).default(25),
});

export type CarbonEstimateInput = z.infer<typeof CarbonEstimateInputSchema>;

export type CarbonEstimateV2 = {
  kgCO2e: number;
  tonsCO2e: number;
  // indicative retirement cost if retiring exact emissions at a given $/t
  estimatedRetirementCostUsd: number;
  bounds: { lowKgCO2e: number; highKgCO2e: number };
  confidence: { level: "low" | "medium" | "high"; notes: string[] };
  methodology: {
    version: "netnet.estimate.v2";
    formula: "kWh = hours * kW * PUE; kgCO2e = kWh * gridIntensity";
    assumptions: Record<string, number | string>;
  };
};

const POWER_KW_BY_MODEL: Record<CarbonEstimateInput["modelSize"], number> = {
  // Conservative ballpark power draw for a single GPU-ish workload.
  // This is NOT a guarantee; it is a planning estimate intended for safe, neutral-by-default defaults.
  tiny: 0.25,
  small: 0.5,
  medium: 1.0,
  large: 2.0,
  xl: 3.5,
};

const round = (n: number, digits = 6) => {
  const p = Math.pow(10, digits);
  return Math.round(n * p) / p;
};

export function estimateAIComputeCarbonV2(raw: unknown): CarbonEstimateV2 {
  const input = CarbonEstimateInputSchema.parse(raw);

  const kW = POWER_KW_BY_MODEL[input.modelSize];
  const kWh = input.computeHours * kW * input.pue;
  const kgCO2e = kWh * input.gridIntensityKgPerKwh;

  // Wide bounds by default; users can tighten via overrides + better telemetry later.
  const lowKg = kgCO2e * 0.5;
  const highKg = kgCO2e * 1.5;

  const tonsCO2e = kgCO2e / 1000;
  const estimatedRetirementCostUsd = tonsCO2e * input.pricePerTonUsd;

  const confidenceNotes: string[] = [
    `Model power draw assumed at ${kW} kW for modelSize=${input.modelSize}.`,
    `PUE assumed ${input.pue}.`,
    `Grid intensity assumed ${input.gridIntensityKgPerKwh} kgCO2e/kWh.`,
    "Bounds are ±50% to reflect variance across hardware, utilization, and grid mix.",
  ];

  return {
    kgCO2e: round(kgCO2e),
    tonsCO2e: round(tonsCO2e),
    estimatedRetirementCostUsd: round(estimatedRetirementCostUsd, 2),
    bounds: { lowKgCO2e: round(lowKg), highKgCO2e: round(highKg) },
    confidence: { level: "low", notes: confidenceNotes },
    methodology: {
      version: "netnet.estimate.v2",
      formula: "kWh = hours * kW * PUE; kgCO2e = kWh * gridIntensity",
      assumptions: {
        modelSize: input.modelSize,
        powerKw: kW,
        pue: input.pue,
        gridIntensityKgPerKwh: input.gridIntensityKgPerKwh,
        pricePerTonUsd: input.pricePerTonUsd,
      },
    },
  };
}
