import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { getClientIp, rateLimit } from "@/lib/http/ratelimit";
import { err, ok } from "@/lib/http/errors";
import { estimateAIComputeCarbonV2 } from "@/lib/carbon/estimation";
import { bridgeRegistry, bridgeProjects, bridgeQuote, bridgeTx, bridgeRetire } from "@/lib/bridge/client";

const QuerySchema = z.object({
  action: z
    .enum(["info", "estimate", "projects", "quote", "status"])
    .default("info"),
  // estimate
  computeHours: z.coerce.number().optional(),
  modelSize: z.enum(["tiny", "small", "medium", "large", "xl"]).optional(),
  pue: z.coerce.number().optional(),
  gridIntensityKgPerKwh: z.coerce.number().optional(),
  pricePerTonUsd: z.coerce.number().optional(),

  // projects / quote
  projectId: z.string().optional(),
  amount: z.coerce.number().optional(),
  token: z.string().optional(),
  chain: z.string().optional(),
  txHash: z.string().optional(),
});

const PostSchema = z.object({
  projectId: z.string().min(1),
  amount: z.number().positive(),
  token: z.string().min(1).default("USDC"),
  chain: z.string().min(1).default("base"),
  beneficiaryName: z.string().min(2),
  reason: z.string().min(4),
});

export async function GET(req: NextRequest) {
  const ip = getClientIp(req);
  const rl = rateLimit(ip, { windowMs: 60_000, max: 60 });
  if (!rl.ok) return err(429, "RATE_LIMITED", "Too many requests");

  const url = new URL(req.url);
  const parsed = QuerySchema.safeParse(Object.fromEntries(url.searchParams));
  if (!parsed.success) return err(400, "BAD_REQUEST", "Invalid query params", parsed.error.flatten());

  const q = parsed.data;

  if (q.action === "info") {
    return ok({
      actions: ["info", "estimate", "projects", "quote", "status"],
      nextAction: "projects",
      safety: {
        postRequires: ["beneficiaryName", "reason"],
        note: "POST initiates a retirement request; payment must be explicitly confirmed by an operator.",
      },
    });
  }

  if (q.action === "estimate") {
    if (typeof q.computeHours !== "number") {
      return err(400, "BAD_REQUEST", "computeHours is required for estimate");
    }
    const estimate = estimateAIComputeCarbonV2({
      computeHours: q.computeHours,
      modelSize: q.modelSize,
      pue: q.pue,
      gridIntensityKgPerKwh: q.gridIntensityKgPerKwh,
      pricePerTonUsd: q.pricePerTonUsd,
    });

    return ok({
      estimate,
      nextAction: "projects",
    });
  }

  if (q.action === "projects") {
    const projects = await bridgeProjects({
      type: url.searchParams.get("type") ?? undefined,
      chain: url.searchParams.get("chain") ?? undefined,
      token: url.searchParams.get("token") ?? undefined,
      search: url.searchParams.get("search") ?? undefined,
    });
    return NextResponse.json(projects);
  }

  if (q.action === "quote") {
    if (!q.projectId || typeof q.amount !== "number") {
      return err(400, "BAD_REQUEST", "projectId and amount are required for quote");
    }
    const quote = await bridgeQuote({
      projectId: q.projectId,
      amount: q.amount,
      token: q.token ?? "USDC",
      chain: q.chain ?? "base",
    });
    return NextResponse.json(quote);
  }

  if (q.action === "status") {
    if (!q.txHash) return err(400, "BAD_REQUEST", "txHash is required for status");
    const status = await bridgeTx({ hash: q.txHash });
    return NextResponse.json(status);
  }

  return err(400, "BAD_REQUEST", "Unknown action");
}

export async function POST(req: NextRequest) {
  const ip = getClientIp(req);
  const rl = rateLimit(ip, { windowMs: 60_000, max: 30 });
  if (!rl.ok) return err(429, "RATE_LIMITED", "Too many requests");

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return err(400, "BAD_REQUEST", "Invalid JSON body");
  }

  const parsed = PostSchema.safeParse(body);
  if (!parsed.success) return err(400, "BAD_REQUEST", "Invalid body", parsed.error.flatten());

  const r = await bridgeRetire(parsed.data);
  return NextResponse.json(r);
}
