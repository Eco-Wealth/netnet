import { test, expect } from "@playwright/test";

test("carbon estimate returns v2 methodology", async ({ request }) => {
  const res = await request.get("/api/agent/carbon?action=estimate&computeHours=2&modelSize=small");
  expect(res.status()).toBe(200);
  const json = await res.json();
  expect(json.ok).toBe(true);
  expect(json.estimate?.methodology?.version).toBe("netnet.estimate.v2");
  expect(typeof json.estimate?.kgCO2e).toBe("number");
  expect(json.nextAction).toBe("projects");
});

test("carbon estimate requires computeHours", async ({ request }) => {
  const res = await request.get("/api/agent/carbon?action=estimate&modelSize=small");
  expect(res.status()).toBe(400);
});
