# netnet-cockpit-carbon (Skill)

Purpose: estimate AI compute emissions and guide an agent through a carbon-neutral-by-default retirement flow.

## 1) Estimate emissions

Request:
- `GET /api/agent/carbon?action=estimate&computeHours=2&modelSize=small`

Optional overrides:
- `pue=1.2`
- `gridIntensityKgPerKwh=0.35`
- `pricePerTonUsd=30`

Expected response:
- `ok=true`
- `estimate.kgCO2e`, `estimate.bounds`, `estimate.confidence`, `estimate.methodology`
- `nextAction="projects"`

## 2) Next steps (high level)
- `GET /api/agent/carbon?action=projects`
- `GET /api/agent/carbon?action=quote&projectId=...&amount=...&token=USDC&chain=base`
- `POST /api/agent/carbon` to initiate retirement (requires `beneficiaryName` + `reason`)
- Track status via `GET /api/agent/carbon?action=status&txHash=0x...`
- Build proof via `POST /api/proof/build`
