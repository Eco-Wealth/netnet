# netnet-cockpit-bankr (Skill)

Purpose: let an operator (or operator-gated agent) use Bankr's Agent API for:
- wallet queries (balances, positions)
- swaps
- token deployment (Bankr-supported chains)
- signing + broadcasting EVM transactions (explicit submit)

## Safety defaults (required)

- Read-only prompts are allowed.
- Any prompt that implies funds movement must be treated as **proposal-only** until an operator approves.

## Required env

- `BANKR_API_KEY`
- `BANKR_API_BASE_URL` (optional)

## Minimal usage (curl)

Prompt:

```bash
curl -X POST https://api.bankr.bot/agent/prompt \
  -H "Content-Type: application/json" \
  -H "X-API-Key: $BANKR_API_KEY" \
  -d '{"prompt":"what are my token balances?"}'
```

Poll:

```bash
curl -X GET https://api.bankr.bot/agent/job/<jobId> \
  -H "X-API-Key: $BANKR_API_KEY"
```
