UNIT 26 — Bankr Agent API connector (foundation)

Adds:
- `src/lib/bankr/*` minimal typed client
- docs + skill markdown for Bankr integration

Next unit should:
- add an agent route `/api/agent/bankr` that exposes safe actions (info, prompt, job) with proposal-only gating.
