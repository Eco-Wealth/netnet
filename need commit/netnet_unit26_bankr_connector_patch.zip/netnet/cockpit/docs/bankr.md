# Bankr Agent API (Connector)

This repo includes a small Bankr Agent API client in `src/lib/bankr/*` so netnet agents can:
- send natural-language prompts (POST `/agent/prompt`)
- poll job results (GET `/agent/job/:jobId`)
- sign transactions (POST `/agent/sign`)
- submit EVM transactions (POST `/agent/submit`)

## Required env

Set these in `netnet/cockpit/.env.local` (or your host environment):

- `BANKR_API_KEY` (required)
- `BANKR_API_BASE_URL` (optional, defaults to `https://api.bankr.bot`)
- `BANKR_TIMEOUT_MS` (optional, default 20000)

## Notes

- Prompt endpoint returns `202 Accepted` with `jobId` + `status: "pending"`.
- Submit accepts an explicit EVM transaction object `{ to, chainId, value?, data?, ... }` and can wait for confirmation.

See Bankr docs for the authoritative request/response fields.
