import {
  BankrJobResponse,
  BankrPromptRequest,
  BankrPromptResponse,
  BankrSignRequest,
  BankrSignResponse,
  BankrSubmitRequest,
  BankrSubmitResponse,
} from "./types";

export type BankrClientOptions = {
  apiKey: string;
  baseUrl?: string; // default https://api.bankr.bot
  timeoutMs?: number; // default 20s
};

export class BankrClient {
  private apiKey: string;
  private baseUrl: string;
  private timeoutMs: number;

  constructor(opts: BankrClientOptions) {
    if (!opts.apiKey) throw new Error("BANKR apiKey is required");
    this.apiKey = opts.apiKey;
    this.baseUrl = (opts.baseUrl || "https://api.bankr.bot").replace(/\/$/, "");
    this.timeoutMs = opts.timeoutMs ?? 20_000;
  }

  private async request<T>(path: string, init: RequestInit): Promise<T> {
    const controller = new AbortController();
    const t = setTimeout(() => controller.abort(), this.timeoutMs);

    try {
      const res = await fetch(`${this.baseUrl}${path}`, {
        ...init,
        headers: {
          "Content-Type": "application/json",
          "X-API-Key": this.apiKey,
          ...(init.headers || {}),
        },
        signal: controller.signal,
      });

      const text = await res.text();
      const isJson = (res.headers.get("content-type") || "").includes("application/json");
      const body = isJson && text ? JSON.parse(text) : text;

      if (!res.ok) {
        const msg =
          typeof body === "object" && body && "message" in (body as any)
            ? String((body as any).message)
            : `Bankr HTTP ${res.status}`;
        const err = new Error(msg);
        (err as any).status = res.status;
        (err as any).body = body;
        throw err;
      }

      return body as T;
    } finally {
      clearTimeout(t);
    }
  }

  prompt(req: BankrPromptRequest): Promise<BankrPromptResponse> {
    return this.request<BankrPromptResponse>("/agent/prompt", {
      method: "POST",
      body: JSON.stringify(req),
    });
  }

  job(jobId: string): Promise<BankrJobResponse> {
    return this.request<BankrJobResponse>(`/agent/job/${encodeURIComponent(jobId)}`, {
      method: "GET",
    });
  }

  sign(req: BankrSignRequest): Promise<BankrSignResponse> {
    return this.request<BankrSignResponse>("/agent/sign", {
      method: "POST",
      body: JSON.stringify(req),
    });
  }

  submit(req: BankrSubmitRequest): Promise<BankrSubmitResponse> {
    return this.request<BankrSubmitResponse>("/agent/submit", {
      method: "POST",
      body: JSON.stringify(req),
    });
  }
}

export function bankrFromEnv(): BankrClient {
  const apiKey = process.env.BANKR_API_KEY || "";
  const baseUrl = process.env.BANKR_API_BASE_URL || "https://api.bankr.bot";
  const timeoutMs = process.env.BANKR_TIMEOUT_MS ? Number(process.env.BANKR_TIMEOUT_MS) : undefined;
  return new BankrClient({ apiKey, baseUrl, timeoutMs });
}
