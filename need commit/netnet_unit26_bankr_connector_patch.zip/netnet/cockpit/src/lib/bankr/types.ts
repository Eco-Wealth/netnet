export type BankrPromptRequest = { prompt: string };

export type BankrPromptResponse = {
  success: boolean;
  jobId: string;
  status: "pending" | string;
  message?: string;
};

export type BankrJobStatus =
  | "pending"
  | "running"
  | "completed"
  | "failed"
  | "canceled"
  | string;

export type BankrJobResponse = {
  success: boolean;
  jobId: string;
  status: BankrJobStatus;
  result?: unknown;
  error?: string;
  message?: string;
};

export type BankrSignRequest = {
  unsignedTransaction: string; // JSON string of tx data (EVM) or tx envelope per Bankr
  description?: string;
};

export type BankrSignResponse = {
  success: boolean;
  signedTransaction: string; // JSON string
  signer?: string;
  chainId?: number;
  message?: string;
};

export type BankrSubmitRequest = {
  transaction: {
    to: string;
    chainId: number;
    value?: string;
    data?: string;
    gas?: string;
    gasPrice?: string;
    maxFeePerGas?: string;
    maxPriorityFeePerGas?: string;
    nonce?: number;
  };
  description?: string;
  waitForConfirmation?: boolean; // default true
};

export type BankrSubmitResponse = {
  success: boolean;
  transactionHash: string;
  status: "success" | "reverted" | "pending" | string;
  blockNumber?: string;
  gasUsed?: string;
  signer?: string;
  chainId?: number;
  error?: string;
};
