# netnet skill: Accounting + Micro-Retire (Unit 31)

Purpose: emit **one ledger record per action** so operators can audit:
- inference spend estimates
- realized fees
- and optional micro-retire intent packets (operator-approved)

## Endpoints
- `GET /api/agent/accounting?action=info`
- `GET /api/agent/accounting?action=ledger&limit=50`
- `POST /api/agent/accounting?action=record`

## Safety
- This skill **never moves funds**
- This skill **never executes retirements**
- It only creates a `microRetire` *intent* packet that an operator may later send to `/api/bridge/retire`.

## Record format (POST body)
```json
{
  "source": "agent.manual",
  "action": "bridge.retire.plan",
  "status": "PLANNED",
  "requiresApproval": true,
  "inferenceUsdEstimate": 0.02,
  "feesUsdRealized": 0,
  "microRetire": {
    "enabled": true,
    "beneficiaryName": "EcoWealth",
    "reason": "micro-retire from fees",
    "quantityTonnes": 0.001,
    "projectId": "optional",
    "referenceId": "optional"
  },
  "meta": { "any": "json" }
}
```

## Output contract
- Always returns:
  - `proofOfAction.type = netnet.ledger.v1`
  - `proofOfAction.digest` (sha256)
  - `entry.id` (stable id)
