# Accounting + Micro-Retire (Unit 31)

This unit adds an internal ledger endpoint for recording **one auditable record per action**, plus an optional
**micro-retire intent packet** that can be executed later using the existing bridge retirement flow.

## What it does
- Records:
  - inference spend estimate (USD)
  - realized fees (USD)
  - action metadata + status
- Optionally emits a `microRetire` packet targeting `POST /api/bridge/retire` (still operator-approved)

## Endpoints
- `GET /api/agent/accounting?action=info`
- `GET /api/agent/accounting?action=ledger&limit=50`
- `POST /api/agent/accounting?action=record`

## Storage
By default, entries append to:
- `netnet/cockpit/.data/ledger.jsonl`

Override via:
- `LEDGER_PATH=/absolute/or/relative/path/to/ledger.jsonl`

## Example
```bash
curl -s -X POST "http://localhost:3000/api/agent/accounting?action=record" \
  -H "content-type: application/json" \
  -d '{
    "source":"agent.bankr-token",
    "action":"bankr.token.launch.plan",
    "status":"PLANNED",
    "requiresApproval":true,
    "inferenceUsdEstimate":0.02,
    "feesUsdRealized":0,
    "microRetire":{"enabled":true,"beneficiaryName":"EcoWealth","reason":"micro-retire from fees","quantityTonnes":0.001},
    "meta":{"chain":"base","note":"proposal-only"}
  }'
```
