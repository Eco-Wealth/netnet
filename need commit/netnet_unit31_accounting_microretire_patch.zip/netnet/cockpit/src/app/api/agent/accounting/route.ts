import { NextRequest, NextResponse } from "next/server";
import { appendLedger, readLedger } from "@/lib/ledger";
import { buildMicroRetireIntent, LedgerSource } from "@/lib/accounting";

export const runtime = "nodejs";

function json(data: unknown, status = 200) {
  return NextResponse.json(data, { status });
}

/**
 * GET /api/agent/accounting?action=info
 * GET /api/agent/accounting?action=ledger&limit=50
 * POST /api/agent/accounting?action=record
 */
export async function GET(req: NextRequest) {
  const url = new URL(req.url);
  const action = url.searchParams.get("action") || "info";

  if (action === "ledger") {
    const limit = Number(url.searchParams.get("limit") || "50");
    const entries = readLedger(Number.isFinite(limit) ? limit : 50);
    return json({ ok: true, entries });
  }

  return json({
    ok: true,
    actions: ["info", "ledger", "record"],
    nextAction: "record",
    safety: {
      note: "This endpoint records accounting/audit events only. It does not move funds or execute retirements.",
    },
    example: {
      method: "POST",
      query: "?action=record",
      body: {
        source: "agent.manual",
        action: "bridge.retire.plan",
        status: "PLANNED",
        requiresApproval: true,
        inferenceUsdEstimate: 0.02,
        feesUsdRealized: 0,
        microRetire: {
          enabled: true,
          beneficiaryName: "EcoWealth",
          reason: "micro-retire from fees",
          quantityTonnes: 0.001,
        },
        meta: { note: "optional metadata" },
      },
    },
  });
}

export async function POST(req: NextRequest) {
  const url = new URL(req.url);
  const action = url.searchParams.get("action") || "record";
  if (action !== "record") return json({ ok: false, error: { code: "BAD_ACTION" } }, 400);

  const body = await req.json().catch(() => null) as any;
  if (!body) return json({ ok: false, error: { code: "BAD_JSON" } }, 400);

  const source = (body.source || "agent.manual") as LedgerSource;
  const name = String(body.action || "unknown");
  const status = (body.status || "PLANNED") as "PLANNED" | "APPROVED" | "EXECUTED" | "FAILED";
  const requiresApproval = Boolean(body.requiresApproval ?? true);

  const inferenceUsdEstimate =
    body.inferenceUsdEstimate == null ? undefined : Number(body.inferenceUsdEstimate);
  const feesUsdRealized = body.feesUsdRealized == null ? undefined : Number(body.feesUsdRealized);

  const micro = body.microRetire || null;
  const microRetire = buildMicroRetireIntent({
    enabled: Boolean(micro?.enabled),
    beneficiaryName: String(micro?.beneficiaryName || ""),
    reason: String(micro?.reason || ""),
    quantityTonnes: Number(micro?.quantityTonnes || 0),
    projectId: micro?.projectId ? String(micro.projectId) : undefined,
    referenceId: micro?.referenceId ? String(micro.referenceId) : undefined,
  });

  const { entry, digest } = appendLedger({
    source,
    action: name,
    status,
    requiresApproval,
    inferenceUsdEstimate: Number.isFinite(inferenceUsdEstimate as any) ? inferenceUsdEstimate : undefined,
    feesUsdRealized: Number.isFinite(feesUsdRealized as any) ? feesUsdRealized : undefined,
    microRetire,
    meta: typeof body.meta === "object" && body.meta ? body.meta : undefined,
  });

  return json({
    ok: true,
    entry,
    proofOfAction: {
      type: "netnet.ledger.v1",
      digest,
      id: entry.id,
      ts: entry.ts,
    },
    nextAction: microRetire ? { endpoint: microRetire.endpoint, method: microRetire.method } : undefined,
  });
}
