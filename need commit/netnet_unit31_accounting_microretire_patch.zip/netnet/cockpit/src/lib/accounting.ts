import crypto from "crypto";

export type AutonomyLevel = "READ_ONLY" | "PROPOSE_ONLY" | "EXECUTE_WITH_LIMITS";

export type LedgerSource =
  | "agent.carbon"
  | "agent.trade"
  | "agent.bankr-token"
  | "agent.manual"
  | "system";

export type LedgerEntry = {
  id: string; // stable id for this record
  ts: string; // ISO timestamp
  source: LedgerSource;
  action: string;
  status: "PLANNED" | "APPROVED" | "EXECUTED" | "FAILED";
  requiresApproval: boolean;

  // economics
  inferenceUsdEstimate?: number; // estimated inference spend for this action
  feesUsdRealized?: number; // realized fees (token ops / trading), if known

  // optional: micro-retire intent packet (operator-approved)
  microRetire?: MicroRetireIntent;

  // freeform metadata for auditing
  meta?: Record<string, unknown>;
};

export type MicroRetireIntent = {
  enabled: boolean;
  // Where the operator should send this next in netnet
  endpoint: "/api/bridge/retire";
  method: "POST";
  // Body is intentionally tolerant; bridge adapter will validate strictly
  body: {
    beneficiaryName: string;
    reason: string;
    quantityTonnes: number;
    projectId?: string;
    // Optional bookkeeping
    referenceId?: string;
  };
};

export function sha256Json(obj: unknown): string {
  const json = JSON.stringify(obj);
  return crypto.createHash("sha256").update(json).digest("hex");
}

export function makeLedgerId(prefix: string, payload: unknown): string {
  const h = sha256Json(payload);
  return `${prefix}_${h.slice(0, 16)}`;
}

export function clamp(n: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, n));
}

/**
 * Very rough inference estimate utility.
 * Prefer passing an explicit inferenceUsdEstimate from the caller when possible.
 */
export function estimateInferenceUsd(params: {
  promptTokens?: number;
  completionTokens?: number;
  usdPer1kPrompt?: number; // e.g. 0.01
  usdPer1kCompletion?: number; // e.g. 0.03
}): number | undefined {
  const pt = params.promptTokens ?? 0;
  const ct = params.completionTokens ?? 0;
  const p = params.usdPer1kPrompt;
  const c = params.usdPer1kCompletion;
  if (p == null || c == null) return undefined;
  const usd = (pt / 1000) * p + (ct / 1000) * c;
  return Math.max(0, Number(usd.toFixed(6)));
}

/**
 * Builds a micro-retire intent packet.
 * This does NOT execute anything. It is a proposed follow-on action that must be approved.
 */
export function buildMicroRetireIntent(params: {
  enabled: boolean;
  beneficiaryName: string;
  reason: string;
  quantityTonnes: number;
  projectId?: string;
  referenceId?: string;
}): MicroRetireIntent | undefined {
  if (!params.enabled) return undefined;
  const q = clamp(Number(params.quantityTonnes || 0), 0, 1_000_000);
  if (!Number.isFinite(q) || q <= 0) return undefined;

  return {
    enabled: true,
    endpoint: "/api/bridge/retire",
    method: "POST",
    body: {
      beneficiaryName: params.beneficiaryName,
      reason: params.reason,
      quantityTonnes: q,
      projectId: params.projectId,
      referenceId: params.referenceId,
    },
  };
}
