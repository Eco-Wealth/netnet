import fs from "fs";
import path from "path";
import { LedgerEntry, makeLedgerId, sha256Json } from "./accounting";

/**
 * Default ledger path is local-dev friendly. In production/serverless, set LEDGER_PATH
 * to a persistent volume or external storage.
 */
const DEFAULT_LEDGER_PATH = path.join(process.cwd(), ".data", "ledger.jsonl");

function getLedgerPath(): string {
  return process.env.LEDGER_PATH || DEFAULT_LEDGER_PATH;
}

function ensureDir(p: string) {
  const dir = path.dirname(p);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}

export function appendLedger(entry: Omit<LedgerEntry, "id" | "ts"> & { id?: string; ts?: string }) {
  const ts = entry.ts ?? new Date().toISOString();
  const base = { ...entry, ts };
  const id = entry.id ?? makeLedgerId("led", base);
  const full: LedgerEntry = { ...(base as LedgerEntry), id };

  const ledgerPath = getLedgerPath();
  ensureDir(ledgerPath);
  fs.appendFileSync(ledgerPath, JSON.stringify(full) + "\n", "utf8");

  return { entry: full, digest: sha256Json(full), ledgerPath };
}

export function readLedger(limit = 50): LedgerEntry[] {
  const ledgerPath = getLedgerPath();
  if (!fs.existsSync(ledgerPath)) return [];
  const lines = fs.readFileSync(ledgerPath, "utf8").trim().split("\n").filter(Boolean);
  const tail = lines.slice(Math.max(0, lines.length - limit));
  return tail.map((l) => JSON.parse(l)) as LedgerEntry[];
}
