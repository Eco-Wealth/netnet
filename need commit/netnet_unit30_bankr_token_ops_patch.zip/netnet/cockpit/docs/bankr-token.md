# Bankr token ops (Unit 30)

This module is **proposal-only**. netnet will never broadcast a token launch or fee-routing transaction.
It produces:

- **What will happen**
- **Estimated costs**
- **Requires approval** (always true)
- A **Bankr prompt** you paste into Bankr to perform the action

## Endpoints

### Discover
`GET /api/agent/bankr-token?action=info`

### Plan a token launch (paste the prompt into Bankr)
Example:

- chain: base
- name: EcoWealth Operator
- symbol: ECOOP
- initialLiquidityUsd: 50 (cap)
- feeBps: 100 (1%)
- feeRecipient: 0xYourRecipient

`GET /api/agent/bankr-token?action=planLaunch&chain=base&name=EcoWealth%20Operator&symbol=ECOOP&initialLiquidityUsd=50&feeBps=100&feeRecipient=0xYourRecipient`

Response includes: `plan.bankrPrompt` and a deterministic `proof` digest.

### Plan fee routing change
`GET /api/agent/bankr-token?action=planFeeRouting&chain=base&tokenAddress=0xToken&feeRecipient=0xRecipient`

## Safety posture

- Always `requiresApproval: true`
- netnet does not hold keys; it does not sign or broadcast
- Use **small caps** for liquidity seeding until proven safe
