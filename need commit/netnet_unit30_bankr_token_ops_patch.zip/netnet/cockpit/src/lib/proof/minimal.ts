import crypto from "crypto";

type Proof = {
  schema: "netnet.proof.v1";
  kind: string;
  timestamp: string;
  subject?: Record<string, unknown>;
  refs?: Record<string, unknown>;
  claims?: Record<string, unknown>;
  signatures?: { type: string; value: string }[];
  digest: { alg: "sha256"; value: string };
};

function stableStringify(obj: unknown): string {
  const seen = new WeakSet();
  const stringify = (v: any): any => {
    if (v && typeof v === "object") {
      if (seen.has(v)) return "[Circular]";
      seen.add(v);
      if (Array.isArray(v)) return v.map(stringify);
      return Object.keys(v).sort().reduce((acc: any, k: string) => {
        acc[k] = stringify(v[k]);
        return acc;
      }, {});
    }
    return v;
  };
  return JSON.stringify(stringify(obj));
}

export function buildProof(params: Omit<Proof, "schema" | "timestamp" | "digest">): Proof {
  const base = {
    schema: "netnet.proof.v1" as const,
    timestamp: new Date().toISOString(),
    ...params,
  };
  const canon = stableStringify({ ...base, digest: undefined });
  const digest = crypto.createHash("sha256").update(canon).digest("hex");
  return { ...base, digest: { alg: "sha256", value: digest } };
}
