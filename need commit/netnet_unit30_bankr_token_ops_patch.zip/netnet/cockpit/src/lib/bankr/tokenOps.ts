import { z } from "zod";

export const BankrTokenLaunchPlanInput = z.object({
  chain: z.string().min(1).default("base"),
  name: z.string().min(2).max(40),
  symbol: z.string().min(2).max(10).regex(/^[A-Z0-9]+$/, "symbol must be A-Z0-9"),
  // Optional knobs; these do NOT execute anything inside netnet.
  initialLiquidityUsd: z.number().positive().max(2500).optional(),
  feeBps: z.number().int().min(0).max(1000).optional(), // up to 10%
  feeRecipient: z.string().min(1).optional(),
  notes: z.string().max(500).optional(),
});

export type BankrTokenLaunchPlanInput = z.infer<typeof BankrTokenLaunchPlanInput>;

export const BankrFeeRoutingPlanInput = z.object({
  chain: z.string().min(1).default("base"),
  tokenAddress: z.string().min(1),
  feeRecipient: z.string().min(1),
  notes: z.string().max(500).optional(),
});

export type BankrFeeRoutingPlanInput = z.infer<typeof BankrFeeRoutingPlanInput>;

export type BankrActionPlan = {
  whatWillHappen: string;
  estimatedCosts: string;
  requiresApproval: true;
  bankrPrompt: string;
};

function fmtUsd(n?: number) {
  if (n === undefined) return "n/a";
  return `$${n.toFixed(2)}`;
}

/**
 * Builds an operator-mediated prompt that can be pasted into Bankr.
 * netnet does not broadcast transactions; it produces a plan + prompt only.
 */
export function buildLaunchPlan(input: BankrTokenLaunchPlanInput): BankrActionPlan {
  const il = input.initialLiquidityUsd;
  const feeLine =
    input.feeBps !== undefined ? `Fee: ${input.feeBps} bps.` : "Fee: default (Bankr).";
  const recipientLine = input.feeRecipient ? `Fee recipient: ${input.feeRecipient}.` : "";

  const what = [
    `Create a new token on ${input.chain} named "${input.name}" (${input.symbol}).`,
    il !== undefined ? `Seed initial liquidity up to ${fmtUsd(il)} (operator-controlled).` : `No liquidity seed unless operator adds it.`,
    feeLine,
    recipientLine,
    input.notes ? `Notes: ${input.notes}` : "",
  ].filter(Boolean).join(" ");

  const est = [
    `Gas: variable (chain conditions).`,
    il !== undefined ? `Liquidity seed: up to ${fmtUsd(il)}.` : `Liquidity seed: $0 unless added.`,
    `Netnet does not move funds; execution requires operator approval in Bankr.`,
  ].join(" ");

  const prompt = [
    `BANKR TOKEN LAUNCH (operator-approved)`,
    `Chain: ${input.chain}`,
    `Name: ${input.name}`,
    `Symbol: ${input.symbol}`,
    il !== undefined ? `Initial liquidity (USD cap): ${il}` : `Initial liquidity: none`,
    input.feeBps !== undefined ? `Fee (bps): ${input.feeBps}` : `Fee (bps): default`,
    input.feeRecipient ? `Fee recipient: ${input.feeRecipient}` : "",
    input.notes ? `Notes: ${input.notes}` : "",
    ``,
    `Please respond with:`,
    `1) What will happen`,
    `2) Estimated costs (gas + any liquidity)`,
    `3) The exact transaction steps`,
    `4) A confirmation prompt for me to approve/deny`,
  ].filter(Boolean).join("\n");

  return {
    whatWillHappen: what,
    estimatedCosts: est,
    requiresApproval: true,
    bankrPrompt: prompt,
  };
}

export function buildFeeRoutingPlan(input: BankrFeeRoutingPlanInput): BankrActionPlan {
  const what = [
    `Update fee routing for token ${input.tokenAddress} on ${input.chain}.`,
    `Set fee recipient to ${input.feeRecipient}.`,
    input.notes ? `Notes: ${input.notes}` : "",
  ].filter(Boolean).join(" ");

  const est = [
    `Gas: variable.`,
    `No funds moved by netnet; operator must approve execution in Bankr.`,
  ].join(" ");

  const prompt = [
    `BANKR FEE ROUTING (operator-approved)`,
    `Chain: ${input.chain}`,
    `Token: ${input.tokenAddress}`,
    `Fee recipient: ${input.feeRecipient}`,
    input.notes ? `Notes: ${input.notes}` : "",
    ``,
    `Please respond with:`,
    `1) What will happen`,
    `2) Estimated gas`,
    `3) Exact transaction steps`,
    `4) A confirmation prompt for me to approve/deny`,
  ].filter(Boolean).join("\n");

  return {
    whatWillHappen: what,
    estimatedCosts: est,
    requiresApproval: true,
    bankrPrompt: prompt,
  };
}
