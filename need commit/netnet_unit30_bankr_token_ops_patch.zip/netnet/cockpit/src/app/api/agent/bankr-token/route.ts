import { NextResponse } from "next/server";
import { z } from "zod";
import { buildLaunchPlan, buildFeeRoutingPlan, BankrTokenLaunchPlanInput, BankrFeeRoutingPlanInput } from "@/lib/bankr/tokenOps";
import { buildProof } from "@/lib/proof/minimal";

function ok(data: Record<string, unknown>) {
  return NextResponse.json({ ok: true, ...data });
}
function bad(code: string, message: string, details?: unknown, status = 400) {
  return NextResponse.json({ ok: false, error: { code, message, details } }, { status });
}

const Action = z.enum(["info", "planLaunch", "planFeeRouting"]);

export async function GET(req: Request) {
  try {
    const url = new URL(req.url);
    const actionRaw = url.searchParams.get("action") || "info";
    const action = Action.safeParse(actionRaw);
    if (!action.success) return bad("BAD_ACTION", "Unsupported action", { action: actionRaw });

    if (action.data === "info") {
      return ok({
        actions: ["planLaunch", "planFeeRouting"],
        safety: {
          execution: "PROPOSE_ONLY",
          note: "This endpoint never broadcasts transactions. It returns a plan + a Bankr prompt. Operator approval is required.",
        },
        nextAction: "planLaunch",
      });
    }

    if (action.data === "planLaunch") {
      const parsed = BankrTokenLaunchPlanInput.safeParse({
        chain: url.searchParams.get("chain") || "base",
        name: url.searchParams.get("name") || "",
        symbol: (url.searchParams.get("symbol") || "").toUpperCase(),
        initialLiquidityUsd: url.searchParams.get("initialLiquidityUsd") ? Number(url.searchParams.get("initialLiquidityUsd")) : undefined,
        feeBps: url.searchParams.get("feeBps") ? Number(url.searchParams.get("feeBps")) : undefined,
        feeRecipient: url.searchParams.get("feeRecipient") || undefined,
        notes: url.searchParams.get("notes") || undefined,
      });
      if (!parsed.success) return bad("BAD_INPUT", "Invalid token launch params", parsed.error.flatten());

      const plan = buildLaunchPlan(parsed.data);
      const proof = buildProof({
        kind: "agent_action",
        subject: { service: "netnet-cockpit", module: "bankr-token" },
        refs: { chain: parsed.data.chain },
        claims: { action: "planLaunch", input: parsed.data, plan },
      });

      return ok({ plan, proof, nextAction: "Paste plan.bankrPrompt into Bankr; wait for reply; then build a final proof object with the results." });
    }

    if (action.data === "planFeeRouting") {
      const parsed = BankrFeeRoutingPlanInput.safeParse({
        chain: url.searchParams.get("chain") || "base",
        tokenAddress: url.searchParams.get("tokenAddress") || "",
        feeRecipient: url.searchParams.get("feeRecipient") || "",
        notes: url.searchParams.get("notes") || undefined,
      });
      if (!parsed.success) return bad("BAD_INPUT", "Invalid fee routing params", parsed.error.flatten());

      const plan = buildFeeRoutingPlan(parsed.data);
      const proof = buildProof({
        kind: "agent_action",
        subject: { service: "netnet-cockpit", module: "bankr-token" },
        refs: { chain: parsed.data.chain, tokenAddress: parsed.data.tokenAddress },
        claims: { action: "planFeeRouting", input: parsed.data, plan },
      });

      return ok({ plan, proof, nextAction: "Paste plan.bankrPrompt into Bankr; approve/deny manually." });
    }

    return bad("UNREACHABLE", "Unhandled action", { action: action.data }, 500);
  } catch (e: any) {
    return bad("SERVER_ERROR", "Unhandled server error", { message: e?.message }, 500);
  }
}

const PostBody = z.object({
  // Intentionally limited: POST still returns a plan only (no execution).
  action: z.enum(["planLaunch", "planFeeRouting"]),
  payload: z.record(z.any()),
});

export async function POST(req: Request) {
  try {
    const body = PostBody.safeParse(await req.json().catch(() => null));
    if (!body.success) return bad("BAD_BODY", "Invalid JSON body", body.error.flatten());

    const url = new URL(req.url);
    url.searchParams.set("action", body.data.action);
    for (const [k, v] of Object.entries(body.data.payload)) {
      if (v === undefined || v === null) continue;
      url.searchParams.set(k, String(v));
    }
    // Reuse GET logic for deterministic behavior
    return GET(new Request(url.toString(), { method: "GET" }));
  } catch (e: any) {
    return bad("SERVER_ERROR", "Unhandled server error", { message: e?.message }, 500);
  }
}
