# Skill: netnet bankr token ops (proposal-only)

## Purpose
Generate operator-approved Bankr prompts for:
- launching a token
- configuring fee routing

This skill is **proposal-only**: it never broadcasts transactions.

## Endpoints
- `GET /api/agent/bankr-token?action=info`
- `GET /api/agent/bankr-token?action=planLaunch&chain=&name=&symbol=&initialLiquidityUsd=&feeBps=&feeRecipient=&notes=`
- `GET /api/agent/bankr-token?action=planFeeRouting&chain=&tokenAddress=&feeRecipient=&notes=`
- `POST /api/agent/bankr-token` (same as GET; wraps params in JSON)

## Guardrails
- Always require explicit operator approval before any on-chain action.
- Do not request or store private keys.
- Keep liquidity seed small (e.g., $25–$100 caps) unless operator explicitly increases it.
- Treat token operations as high-risk: mistakes can be irreversible.

## Workflow (agent)
1. Call `action=planLaunch` with desired parameters.
2. Present `plan.whatWillHappen`, `plan.estimatedCosts`, and the `plan.bankrPrompt` to the operator.
3. Operator pastes into Bankr and receives execution steps.
4. Agent records the Bankr reply text and builds a final proof object (use `/api/proof/build` if available).
5. Never proceed unless operator explicitly approves.
