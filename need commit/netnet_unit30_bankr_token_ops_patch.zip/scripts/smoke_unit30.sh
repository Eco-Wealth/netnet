#!/usr/bin/env bash
set -euo pipefail

BASE_URL="${BASE_URL:-http://localhost:3000}"

echo "== Unit 30 smoke: /api/agent/bankr-token?action=info"
curl -sS "${BASE_URL}/api/agent/bankr-token?action=info" | head -c 500; echo
