## Unit 25 — Agent spine (Policy Engine)

Adds a shared policy/approval layer:
- Safe-by-default caps + allowlists
- Operator approval gate (header-based)
- Canonical action envelope: `netnet.action.v1`

See `netnet/cockpit/docs/policy.md` and `netnet/cockpit/.env.example`.
