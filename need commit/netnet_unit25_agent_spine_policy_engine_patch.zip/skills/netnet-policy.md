# netnet Policy Engine (v1)

netnet uses a policy layer so an agent can plan freely, but anything risky is gated.

## Operator approval
- Default header: `x-netnet-approve`
- Dev approval: send `x-netnet-approve: YES`
- Production: set `NETNET_APPROVAL_SECRET` and use that value

## Defaults
- Trading disabled (`TRADE_ENABLED=false`)
- Retirements disabled (`RETIRE_ENABLED=false`)

## Envelope
All agent calls should emit a `netnet.action.v1` envelope for audit.
