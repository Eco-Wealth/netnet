import { getPolicyConfig } from "./env";

/**
 * Operator approval gate:
 * - If NETNET_APPROVALS_ENABLED=true (default), EXECUTE_APPROVED actions require approval.
 * - Approval header (default: x-netnet-approve).
 * - If NETNET_APPROVAL_SECRET is set, header must match exactly.
 * - If secret is NOT set, header must equal "YES".
 */
export function isApprovedByOperator(headers: Headers): boolean {
  const cfg = getPolicyConfig();
  const key = cfg.approvalHeader.toLowerCase();
  const v = headers.get(key) || headers.get(cfg.approvalHeader) || "";

  if (!cfg.approvalsEnabled) return true;

  if (cfg.approvalSecret && cfg.approvalSecret.length > 0) {
    return v === cfg.approvalSecret;
  }

  return v.toUpperCase() === "YES";
}
