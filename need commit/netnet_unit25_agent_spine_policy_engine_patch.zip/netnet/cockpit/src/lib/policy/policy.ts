import type { ActionEnvelope, PolicyDecision } from "./types";
import { getPolicyConfig } from "./env";

export function evaluatePolicy(envelope: ActionEnvelope<any>): PolicyDecision {
  const cfg = getPolicyConfig();

  if (!envelope || envelope.schema !== "netnet.action.v1") {
    return {
      ok: false,
      requiresApproval: false,
      reason: "Invalid action envelope",
      nextAction: "fix_request",
    };
  }

  const wantsExecute = envelope.mode === "EXECUTE_APPROVED";

  if (envelope.kind === "agent.trade") {
    const { usd = 0, token = "", chain = "" } = envelope.input || {};
    const tokenNorm = String(token).toUpperCase();
    const chainNorm = String(chain).toLowerCase();

    const limits = {
      maxUsd: cfg.tradeMaxUsd,
      allowlistTokens: cfg.tradeAllowlistTokens,
      allowlistChains: cfg.tradeAllowlistChains,
    };

    if (!cfg.tradeEnabled) {
      return {
        ok: false,
        requiresApproval: false,
        reason: "Trading is disabled (TRADE_ENABLED=false)",
        limitsApplied: limits,
        nextAction: "enable_trade_and_retry",
      };
    }

    if (Number(usd) > cfg.tradeMaxUsd) {
      return {
        ok: false,
        requiresApproval: true,
        reason: `Trade exceeds cap (${usd} > ${cfg.tradeMaxUsd} USD)`,
        limitsApplied: limits,
        nextAction: "reduce_size_or_request_override",
      };
    }

    if (!cfg.tradeAllowlistTokens.map((t) => t.toUpperCase()).includes(tokenNorm)) {
      return {
        ok: false,
        requiresApproval: true,
        reason: `Token not allowlisted (${tokenNorm})`,
        limitsApplied: limits,
        nextAction: "choose_allowlisted_token_or_request_override",
      };
    }

    if (!cfg.tradeAllowlistChains.map((c) => c.toLowerCase()).includes(chainNorm)) {
      return {
        ok: false,
        requiresApproval: true,
        reason: `Chain not allowlisted (${chainNorm})`,
        limitsApplied: limits,
        nextAction: "choose_allowlisted_chain_or_request_override",
      };
    }

    return {
      ok: true,
      requiresApproval: wantsExecute,
      limitsApplied: limits,
      nextAction: wantsExecute ? "await_operator_approval" : "ok",
    };
  }

  if (envelope.kind === "agent.carbon" || envelope.kind === "bridge.retire") {
    const { amount = 0, credits = 0, usd = 0, token = "", chain = "" } = envelope.input || {};
    const creditsN = Number.isFinite(Number(credits)) ? Number(credits) : Number(amount) || 0;
    const usdN = Number.isFinite(Number(usd)) ? Number(usd) : 0;

    const tokenNorm = String(token || "").toUpperCase();
    const chainNorm = String(chain || "").toLowerCase();

    const limits = {
      maxCredits: cfg.retireMaxCredits,
      maxUsd: cfg.retireMaxUsd,
      allowlistTokens: cfg.retireAllowlistTokens,
      allowlistChains: cfg.retireAllowlistChains,
    };

    if (!cfg.retireEnabled) {
      return {
        ok: false,
        requiresApproval: false,
        reason: "Retirements are disabled (RETIRE_ENABLED=false)",
        limitsApplied: limits,
        nextAction: "enable_retirements_and_retry",
      };
    }

    if (creditsN > cfg.retireMaxCredits) {
      return {
        ok: false,
        requiresApproval: true,
        reason: `Retirement exceeds credit cap (${creditsN} > ${cfg.retireMaxCredits})`,
        limitsApplied: limits,
        nextAction: "reduce_amount_or_request_override",
      };
    }

    if (usdN > cfg.retireMaxUsd) {
      return {
        ok: false,
        requiresApproval: true,
        reason: `Retirement exceeds USD cap (${usdN} > ${cfg.retireMaxUsd})`,
        limitsApplied: limits,
        nextAction: "reduce_cost_or_request_override",
      };
    }

    if (tokenNorm && !cfg.retireAllowlistTokens.map((t) => t.toUpperCase()).includes(tokenNorm)) {
      return {
        ok: false,
        requiresApproval: true,
        reason: `Token not allowlisted (${tokenNorm})`,
        limitsApplied: limits,
        nextAction: "choose_allowlisted_token_or_request_override",
      };
    }

    if (chainNorm && !cfg.retireAllowlistChains.map((c) => c.toLowerCase()).includes(chainNorm)) {
      return {
        ok: false,
        requiresApproval: true,
        reason: `Chain not allowlisted (${chainNorm})`,
        limitsApplied: limits,
        nextAction: "choose_allowlisted_chain_or_request_override",
      };
    }

    return {
      ok: true,
      requiresApproval: true,
      limitsApplied: limits,
      nextAction: "await_operator_approval",
    };
  }

  if (envelope.kind === "proof.build") {
    return { ok: true, requiresApproval: false, nextAction: "ok" };
  }

  return {
    ok: true,
    requiresApproval: wantsExecute,
    nextAction: wantsExecute ? "await_operator_approval" : "ok",
  };
}
