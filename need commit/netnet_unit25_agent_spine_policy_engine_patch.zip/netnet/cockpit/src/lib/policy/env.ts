export type PolicyConfig = {
  approvalsEnabled: boolean;
  approvalHeader: string;
  approvalSecret?: string;

  tradeEnabled: boolean;
  tradeMaxUsd: number;
  tradeAllowlistTokens: string[];
  tradeAllowlistChains: string[];

  retireEnabled: boolean;
  retireMaxCredits: number;
  retireMaxUsd: number;
  retireAllowlistTokens: string[];
  retireAllowlistChains: string[];
};

function parseBool(v: string | undefined, def: boolean) {
  if (v === undefined) return def;
  return ["1", "true", "yes", "on"].includes(v.toLowerCase());
}

function parseNum(v: string | undefined, def: number) {
  const n = Number(v);
  return Number.isFinite(n) ? n : def;
}

function parseList(v: string | undefined, def: string[]) {
  if (!v) return def;
  return v
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
}

export function getPolicyConfig(): PolicyConfig {
  return {
    approvalsEnabled: parseBool(process.env.NETNET_APPROVALS_ENABLED, true),
    approvalHeader: process.env.NETNET_APPROVAL_HEADER || "x-netnet-approve",
    approvalSecret: process.env.NETNET_APPROVAL_SECRET,

    tradeEnabled: parseBool(process.env.TRADE_ENABLED, false),
    tradeMaxUsd: parseNum(process.env.TRADE_MAX_USD, 25),
    tradeAllowlistTokens: parseList(process.env.TRADE_ALLOWLIST_TOKENS, ["USDC", "ETH"]),
    tradeAllowlistChains: parseList(process.env.TRADE_ALLOWLIST_CHAINS, ["base"]),

    retireEnabled: parseBool(process.env.RETIRE_ENABLED, false),
    retireMaxCredits: parseNum(process.env.RETIRE_MAX_CREDITS, 5),
    retireMaxUsd: parseNum(process.env.RETIRE_MAX_USD, 50),
    retireAllowlistTokens: parseList(process.env.RETIRE_ALLOWLIST_TOKENS, ["USDC"]),
    retireAllowlistChains: parseList(process.env.RETIRE_ALLOWLIST_CHAINS, ["base"]),
  };
}
