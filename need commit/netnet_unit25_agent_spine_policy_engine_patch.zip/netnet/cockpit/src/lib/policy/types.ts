export type ActionMode = "READ_ONLY" | "PROPOSE" | "EXECUTE_APPROVED";

export type ActionKind =
  | "agent.carbon"
  | "agent.trade"
  | "bridge.quote"
  | "bridge.retire"
  | "proof.build"
  | "work.order"
  | "sdg.tag";

export type Subject = {
  agentId?: string;
  wallet?: string;
  operator?: string;
  ip?: string;
};

export type ActionEnvelope<TInput = unknown> = {
  schema: "netnet.action.v1";
  actionId: string;
  kind: ActionKind;
  mode: ActionMode;
  timestamp: string; // ISO
  subject?: Subject;
  input: TInput;
  meta?: Record<string, unknown>;
};

export type PolicyLimitsApplied = {
  maxUsd?: number;
  maxCredits?: number;
  allowlistTokens?: string[];
  allowlistChains?: string[];
};

export type PolicyDecision = {
  ok: boolean;
  requiresApproval: boolean;
  reason?: string;
  limitsApplied?: PolicyLimitsApplied;
  nextAction?: string;
};
