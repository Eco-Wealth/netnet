import type { ActionEnvelope, ActionKind, ActionMode, Subject } from "./types";

export function newActionId(prefix: string = "act"): string {
  const rand = Math.random().toString(16).slice(2, 10);
  return `${prefix}_${Date.now().toString(36)}_${rand}`;
}

export function buildEnvelope<TInput>(args: {
  kind: ActionKind;
  mode: ActionMode;
  input: TInput;
  subject?: Subject;
  meta?: Record<string, unknown>;
  actionId?: string;
}): ActionEnvelope<TInput> {
  return {
    schema: "netnet.action.v1",
    actionId: args.actionId || newActionId(),
    kind: args.kind,
    mode: args.mode,
    timestamp: new Date().toISOString(),
    subject: args.subject,
    input: args.input,
    meta: args.meta,
  };
}
