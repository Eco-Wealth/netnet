import { NextRequest, NextResponse } from "next/server";
import { buildEnvelope } from "@/lib/policy/action";
import { evaluatePolicy } from "@/lib/policy/policy";
import { isApprovedByOperator } from "@/lib/policy/approval";

function json(data: any, status: number = 200) {
  return NextResponse.json(data, { status });
}

export async function GET(req: NextRequest) {
  const url = new URL(req.url);
  const action = url.searchParams.get("action") || "info";

  if (action === "info") {
    return json({
      ok: true,
      trade: {
        enabled: (process.env.TRADE_ENABLED || "false").toLowerCase() === "true",
        maxUsd: Number(process.env.TRADE_MAX_USD || 25),
        allowlistTokens: (process.env.TRADE_ALLOWLIST_TOKENS || "USDC,ETH")
          .split(",")
          .map((s) => s.trim())
          .filter(Boolean),
        defaultMode: "DRY_RUN",
      },
      nextAction: "Use action=quote to simulate; POST to get an executionPlan (DRY_RUN).",
    });
  }

  if (action === "quote") {
    const usd = Number(url.searchParams.get("usd") || 0);
    const token = (url.searchParams.get("token") || "USDC").toUpperCase();
    const chain = (url.searchParams.get("chain") || "base").toLowerCase();

    const envelope = buildEnvelope({
      kind: "agent.trade",
      mode: "PROPOSE",
      input: { usd, token, chain },
      subject: { ip: req.headers.get("x-forwarded-for") || undefined },
    });

    const decision = evaluatePolicy(envelope);
    if (!decision.ok) {
      return json(
        { ok: false, error: { code: "POLICY_DENY", message: decision.reason, details: decision }, action: envelope },
        400
      );
    }

    return json({
      ok: true,
      action: envelope,
      decision,
      quote: {
        mode: "DRY_RUN",
        usd,
        token,
        chain,
        estFill: "SIMULATED",
        estFeesUsd: Math.max(0.01, usd * 0.002),
      },
      nextAction: "POST to /api/agent/trade for a DRY_RUN executionPlan.",
    });
  }

  return json({ ok: false, error: { code: "BAD_ACTION", message: "Unsupported action" } }, 400);
}

export async function POST(req: NextRequest) {
  let body: any = {};
  try {
    body = await req.json();
  } catch {
    return json({ ok: false, error: { code: "BAD_JSON", message: "Invalid JSON body" } }, 400);
  }

  const usd = Number(body.usd || 0);
  const token = String(body.token || "USDC").toUpperCase();
  const chain = String(body.chain || "base").toLowerCase();
  const mode = (body.mode === "EXECUTE_APPROVED" ? "EXECUTE_APPROVED" : "PROPOSE") as any;

  const envelope = buildEnvelope({
    kind: "agent.trade",
    mode,
    input: { usd, token, chain },
    subject: { ip: req.headers.get("x-forwarded-for") || undefined },
    meta: { requested: body },
  });

  const decision = evaluatePolicy(envelope);
  if (!decision.ok) {
    return json(
      { ok: false, error: { code: "POLICY_DENY", message: decision.reason, details: decision }, action: envelope },
      400
    );
  }

  if (decision.requiresApproval && !isApprovedByOperator(req.headers)) {
    return json(
      {
        ok: false,
        action: envelope,
        decision,
        error: { code: "APPROVAL_REQUIRED", message: "Operator approval required" },
        nextAction: "Provide operator approval header and retry",
      },
      403
    );
  }

  return json({
    ok: true,
    action: envelope,
    decision,
    executionPlan: {
      mode: "DRY_RUN",
      steps: [
        { kind: "policy_check", ok: true },
        { kind: "quote", usd, token, chain },
        { kind: "execute", note: "Execution is stubbed; no broadcast occurs in v0.4.x" },
      ],
    },
    nextAction: "Review executionPlan. No funds moved.",
  });
}
