import { NextRequest, NextResponse } from "next/server";
import { buildEnvelope } from "@/lib/policy/action";
import { evaluatePolicy } from "@/lib/policy/policy";
import { isApprovedByOperator } from "@/lib/policy/approval";

function json(data: any, status: number = 200) {
  return NextResponse.json(data, { status });
}

export async function GET(req: NextRequest) {
  const url = new URL(req.url);
  const action = url.searchParams.get("action") || "info";

  if (action === "info") {
    return json({
      ok: true,
      actions: ["info", "estimate", "projects", "quote", "status"],
      nextAction: "projects",
      safety: {
        postRequires: ["beneficiaryName", "reason"],
        note: "POST creates a retirement request packet. Payment must be explicitly confirmed by an operator.",
      },
    });
  }

  return json({ ok: false, error: { code: "BAD_ACTION", message: "Unsupported action" } }, 400);
}

export async function POST(req: NextRequest) {
  let body: any = {};
  try {
    body = await req.json();
  } catch {
    return json({ ok: false, error: { code: "BAD_JSON", message: "Invalid JSON body" } }, 400);
  }

  const beneficiaryName = String(body.beneficiaryName || "").trim();
  const reason = String(body.reason || "").trim();

  if (!beneficiaryName || !reason) {
    return json({ ok: false, error: { code: "VALIDATION", message: "beneficiaryName and reason are required" } }, 400);
  }

  const projectId = String(body.projectId || "").trim();
  const credits = Number(body.credits ?? body.amount ?? 0);
  const chain = String(body.chain || "base").toLowerCase();
  const token = String(body.token || "USDC").toUpperCase();
  const usd = Number(body.usd || 0);

  const envelope = buildEnvelope({
    kind: "agent.carbon",
    mode: "EXECUTE_APPROVED",
    input: { projectId, credits, chain, token, usd, beneficiaryName, reason },
    subject: { ip: req.headers.get("x-forwarded-for") || undefined },
  });

  const decision = evaluatePolicy(envelope);
  if (!decision.ok) {
    return json(
      { ok: false, error: { code: "POLICY_DENY", message: decision.reason, details: decision }, action: envelope },
      400
    );
  }

  if (decision.requiresApproval && !isApprovedByOperator(req.headers)) {
    return json(
      {
        ok: false,
        action: envelope,
        decision,
        error: { code: "APPROVAL_REQUIRED", message: "Operator approval required" },
        nextAction: "Operator must approve before proceeding",
      },
      403
    );
  }

  return json({
    ok: true,
    action: envelope,
    decision,
    retirementRequest: {
      projectId,
      credits,
      chain,
      token,
      beneficiaryName,
      reason,
      note: "Next: call /api/bridge/quote then /api/bridge/retire for payment + status tracking.",
    },
    nextAction: "bridge_quote",
  });
}
