# Policy Engine (v1)

netnet enforces a safe-by-default execution model. Every action is wrapped in a `netnet.action.v1` envelope and evaluated by policy before doing anything risky.

## Modes
- READ_ONLY: no side effects
- PROPOSE: return a plan / instructions, no side effects
- EXECUTE_APPROVED: only allowed when operator explicitly approves

## Operator approval
- Header: `x-netnet-approve` (override with `NETNET_APPROVAL_HEADER`)
- If `NETNET_APPROVAL_SECRET` is set, header must match exactly.
- If secret is not set, header must equal `YES`.

## Defaults
- Trading disabled (`TRADE_ENABLED=false`)
- Retirements disabled (`RETIRE_ENABLED=false`)
