import { NextRequest, NextResponse } from "next/server";
import { loadPolicy, actionAllowed, assertAutonomy, assertMaxTrade, assertTokenAllowed, assertVenueAllowed } from "@/lib/policy";

export const dynamic = "force-dynamic";

function ok(data: any) {
  return NextResponse.json({ ok: true, ...data });
}

function err(status: number, code: string, message: string, details?: any) {
  return NextResponse.json({ ok: false, error: { code, message, details } }, { status });
}

export async function GET(req: NextRequest) {
  const policy = loadPolicy();
  const { searchParams } = new URL(req.url);
  const action = (searchParams.get("action") || "info").toLowerCase();

  if (action === "info") {
    return ok({
      trade: {
        enabled: policy.autonomyLevel === "EXECUTE_WITH_LIMITS",
        maxUsd: policy.limits.maxUsdPerTrade,
        allowlistTokens: policy.allowlists.tokens,
        defaultMode: "DRY_RUN",
      },
      policy: { autonomyLevel: policy.autonomyLevel },
      nextAction: "Use action=quote to simulate; POST returns executionPlan (DRY_RUN unless policy allows execute).",
    });
  }

  if (action === "quote") {
    if (!actionAllowed(policy, "trade.quote")) return err(403, "ACTION_FORBIDDEN", "Action not allowed by policy");
    // Simulated quote (no external calls)
    const tokenIn = searchParams.get("tokenIn") ?? "USDC";
    const tokenOut = searchParams.get("tokenOut") ?? "ETH";
    const usd = Number(searchParams.get("usd") ?? "10");
    try {
      assertAutonomy(policy, "PROPOSE_ONLY");
      assertTokenAllowed(policy, tokenIn);
      assertTokenAllowed(policy, tokenOut);
      assertMaxTrade(policy, usd);
    } catch (e: any) {
      return err(400, "POLICY_REJECTED", e?.message ?? "Rejected by policy");
    }
    return ok({
      quote: {
        venue: "SIMULATED",
        tokenIn,
        tokenOut,
        usd,
        estimatedOut: "SIMULATED",
        warnings: ["This is a simulated quote (DRY_RUN)."],
      },
      nextAction: "POST /api/agent/trade to produce an executionPlan (still DRY_RUN by default).",
    });
  }

  return err(400, "BAD_REQUEST", "Unknown action");
}

export async function POST(req: NextRequest) {
  const policy = loadPolicy();
  if (!actionAllowed(policy, "trade.plan") && !actionAllowed(policy, "trade.execute_dry_run")) {
    return err(403, "ACTION_FORBIDDEN", "Trade planning not allowed by policy");
  }

  const body = await req.json().catch(() => null);
  const tokenIn = body?.tokenIn ?? "USDC";
  const tokenOut = body?.tokenOut ?? "ETH";
  const usd = Number(body?.usd ?? 10);
  const venue = body?.venue ?? "SIMULATED";

  try {
    assertAutonomy(policy, "PROPOSE_ONLY");
    assertTokenAllowed(policy, tokenIn);
    assertTokenAllowed(policy, tokenOut);
    assertVenueAllowed(policy, venue);
    assertMaxTrade(policy, usd);
  } catch (e: any) {
    return err(400, "POLICY_REJECTED", e?.message ?? "Rejected by policy");
  }

  const executionPlan = {
    mode: "DRY_RUN",
    venue,
    tokenIn,
    tokenOut,
    usd,
    steps: [
      { kind: "check_policy", ok: true, autonomyLevel: policy.autonomyLevel },
      { kind: "simulate", note: "No transaction will be broadcast." },
    ],
    requiresApproval: true,
    estimatedCosts: { gasUsd: null, feesUsd: null },
  };

  return ok({ executionPlan, nextAction: "If/when EXECUTE_WITH_LIMITS is enabled, wire a real connector." });
}
