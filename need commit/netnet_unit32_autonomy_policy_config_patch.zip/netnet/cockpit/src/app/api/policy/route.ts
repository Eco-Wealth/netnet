import { NextResponse } from "next/server";
import { loadPolicy } from "@/lib/policy";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const policy = loadPolicy();
    return NextResponse.json({ ok: true, policy });
  } catch (e: any) {
    return NextResponse.json(
      { ok: false, error: { code: "POLICY_LOAD_FAILED", message: e?.message ?? "Failed to load policy" } },
      { status: 500 }
    );
  }
}
