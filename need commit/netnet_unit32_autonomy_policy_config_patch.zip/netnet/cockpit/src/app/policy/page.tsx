import { headers } from "next/headers";

async function getPolicy(baseUrl: string) {
  const res = await fetch(`${baseUrl}/api/policy`, { cache: "no-store" });
  return res.json();
}

export default async function PolicyPage() {
  const h = headers();
  const host = h.get("host");
  const proto = h.get("x-forwarded-proto") ?? "http";
  const baseUrl = host ? `${proto}://${host}` : "http://localhost:3000";

  const data = await getPolicy(baseUrl);

  return (
    <div className="mx-auto max-w-xl p-4 space-y-4">
      <h1 className="text-xl font-semibold">Policy</h1>
      <p className="text-sm opacity-80">
        Single source of truth for autonomy + caps + allowlists. Edit the JSON file (repo) and redeploy.
      </p>

      <div className="rounded-xl border p-3">
        <pre className="text-xs whitespace-pre-wrap break-words">
          {JSON.stringify(data, null, 2)}
        </pre>
      </div>
    </div>
  );
}
