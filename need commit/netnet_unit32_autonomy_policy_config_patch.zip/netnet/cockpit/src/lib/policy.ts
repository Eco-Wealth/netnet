import fs from "node:fs";
import path from "node:path";

export type AutonomyLevel = "READ_ONLY" | "PROPOSE_ONLY" | "EXECUTE_WITH_LIMITS";

export type NetnetPolicyV1 = {
  schema: "netnet.policy.v1";
  autonomyLevel: AutonomyLevel;
  limits: {
    maxUsdPerDay: number;
    maxUsdPerTrade: number;
  };
  allowlists: {
    tokens: string[];
    venues: string[];
    actions: string[];
  };
  notes?: string;
};

const DEFAULT_POLICY_PATH = "netnet/cockpit/policy/netnet.policy.json";

function safeJsonParse<T>(raw: string): { ok: true; value: T } | { ok: false; error: string } {
  try {
    return { ok: true, value: JSON.parse(raw) as T };
  } catch (e: any) {
    return { ok: false, error: e?.message ?? "Invalid JSON" };
  }
}

export function getPolicyPath(): string {
  const fromEnv = process.env.NETNET_POLICY_PATH?.trim();
  return fromEnv && fromEnv.length > 0 ? fromEnv : DEFAULT_POLICY_PATH;
}

export function loadPolicy(): NetnetPolicyV1 {
  const p = getPolicyPath();
  const abs = path.isAbsolute(p) ? p : path.join(process.cwd(), p);
  const raw = fs.readFileSync(abs, "utf8");
  const parsed = safeJsonParse<NetnetPolicyV1>(raw);
  if (!parsed.ok) {
    throw new Error(`NETNET_POLICY invalid JSON: ${parsed.error}`);
  }
  if (parsed.value?.schema !== "netnet.policy.v1") {
    throw new Error("NETNET_POLICY schema mismatch (expected netnet.policy.v1)");
  }
  return parsed.value;
}

export function actionAllowed(policy: NetnetPolicyV1, action: string): boolean {
  return policy.allowlists.actions.includes(action);
}

export function assertAutonomy(policy: NetnetPolicyV1, need: AutonomyLevel) {
  const order: Record<AutonomyLevel, number> = { READ_ONLY: 0, PROPOSE_ONLY: 1, EXECUTE_WITH_LIMITS: 2 };
  if (order[policy.autonomyLevel] < order[need]) {
    throw new Error(`Autonomy level too low (need ${need}, have ${policy.autonomyLevel})`);
  }
}

export function assertTokenAllowed(policy: NetnetPolicyV1, token: string) {
  if (!policy.allowlists.tokens.includes(token)) {
    throw new Error(`Token not allowlisted: ${token}`);
  }
}

export function assertVenueAllowed(policy: NetnetPolicyV1, venue: string) {
  if (!policy.allowlists.venues.includes(venue)) {
    throw new Error(`Venue not allowlisted: ${venue}`);
  }
}

export function assertMaxTrade(policy: NetnetPolicyV1, usd: number) {
  if (usd > policy.limits.maxUsdPerTrade) {
    throw new Error(`Trade exceeds maxUsdPerTrade (${usd} > ${policy.limits.maxUsdPerTrade})`);
  }
}
