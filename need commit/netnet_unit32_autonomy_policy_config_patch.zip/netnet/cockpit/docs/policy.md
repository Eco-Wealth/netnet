# Policy (netnet.policy.v1)

Netnet uses a single policy file to control autonomy, spend limits, and allowlists.

## File
- Default: `netnet/cockpit/policy/netnet.policy.json`
- Override path: `NETNET_POLICY_PATH=/absolute/or/relative/path.json`

## Autonomy levels
- `READ_ONLY`: no state-changing actions
- `PROPOSE_ONLY`: can generate plans/quotes; no execution
- `EXECUTE_WITH_LIMITS`: execution allowed, but only within caps + allowlists

## What this protects
- Prevents accidental fund movement
- Centralizes caps + allowlists for all agent endpoints
