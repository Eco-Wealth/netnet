# Unit 29 Notes

Adds guarded execute mode to Bankr agent surface while keeping proposal-first default.

- Execution disabled unless BANKR_EXECUTION_ENABLED=true
- Requires operator token header to proceed (still DRY_RUN)
- Enforces allowlists + max USD cap server-side
