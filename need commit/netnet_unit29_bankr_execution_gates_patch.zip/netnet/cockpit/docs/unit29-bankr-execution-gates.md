# Unit 29 — Bankr execution gates (safe-by-default)

This unit makes the Bankr agent surface **proposal-only by default** and adds an optional, **operator-confirmed execute mode**.

## What changed

- Adds strict policy gates to `/api/agent/bankr`:
  - execution disabled unless `BANKR_EXECUTION_ENABLED=true`
  - **operator confirmation required** via `x-operator-token` header matching `OPERATOR_CONFIRM_TOKEN`
  - `BANKR_MAX_USD` cap enforced server-side
  - allowlists enforced: `BANKR_ALLOWLIST_TOKENS`, `BANKR_ALLOWLIST_CHAINS`
- Adds deterministic proof for both proposal and execute-attempt (kind=`agent_action`)

## Env vars

Add to `.env` (or `netnet/cockpit/.env.local`):

- `BANKR_EXECUTION_ENABLED=false`
- `BANKR_MAX_USD=25`
- `BANKR_ALLOWLIST_TOKENS=USDC,ETH`
- `BANKR_ALLOWLIST_CHAINS=base`
- `OPERATOR_CONFIRM_TOKEN=` (leave empty to keep execute locked)

## Curl checks

1) Info:
```bash
curl -s "http://localhost:3000/api/agent/bankr?action=info" | jq
```

2) Plan (querystring):
```bash
curl -s "http://localhost:3000/api/agent/bankr?action=plan&intent=swap&chain=base&tokenIn=USDC&tokenOut=ETH&usd=10" | jq
```

3) Proposal POST (always allowed):
```bash
curl -s -X POST "http://localhost:3000/api/agent/bankr" \
  -H "content-type: application/json" \
  -d '{"intent":"swap","chain":"base","tokenIn":"USDC","tokenOut":"ETH","usd":10,"beneficiaryName":"EcoWealth","reason":"test proposal"}' | jq
```

4) Execute attempt (should 403 by default):
```bash
curl -i -X POST "http://localhost:3000/api/agent/bankr?action=execute" \
  -H "content-type: application/json" \
  -d '{"intent":"swap","chain":"base","tokenIn":"USDC","tokenOut":"ETH","usd":10,"beneficiaryName":"EcoWealth","reason":"test execute"}'
```

5) Execute (guarded DRY_RUN):
```bash
export BANKR_EXECUTION_ENABLED=true
export OPERATOR_CONFIRM_TOKEN="local-dev-token"

curl -s -X POST "http://localhost:3000/api/agent/bankr?action=execute" \
  -H "content-type: application/json" \
  -H "x-operator-token: local-dev-token" \
  -d '{"intent":"swap","chain":"base","tokenIn":"USDC","tokenOut":"ETH","usd":10,"beneficiaryName":"EcoWealth","reason":"operator approved"}' | jq
```
