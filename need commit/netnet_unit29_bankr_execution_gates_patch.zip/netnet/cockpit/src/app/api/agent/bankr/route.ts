import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { err, ok } from "@/lib/http/errors";
import { rateLimit } from "@/lib/http/ratelimit";
import { env } from "@/lib/env";
import { buildProof } from "@/lib/proof";

/**
 * Bankr Agent API (proposal-only by default).
 *
 * Safe-by-default gates:
 * - BANKR_EXECUTION_ENABLED must be "true" to allow execute mode.
 * - x-operator-token header must match OPERATOR_CONFIRM_TOKEN for execute.
 * - strict USD caps + allowlists (chains/tokens) are enforced server-side.
 *
 * Actions:
 *  GET  /api/agent/bankr?action=info
 *  GET  /api/agent/bankr?action=plan&intent=swap&chain=base&tokenIn=USDC&tokenOut=ETH&usd=10
 *  POST /api/agent/bankr  (proposal payload; returns executionPlan + proof)
 *
 *  POST /api/agent/bankr?action=execute (DISABLED by default)
 *    - requires x-operator-token; returns { ok:true, mode:"DRY_RUN"|"LIVE", proof, nextAction }
 */

const QuerySchema = z.object({
  action: z.enum(["info", "plan", "execute"]).default("info"),
  intent: z.enum(["swap", "token_launch", "transfer"]).optional(),
  chain: z.string().optional(),
  tokenIn: z.string().optional(),
  tokenOut: z.string().optional(),
  usd: z.coerce.number().positive().optional(),
});

const PlanBodySchema = z.object({
  intent: z.enum(["swap", "token_launch", "transfer"]),
  chain: z.string(),
  tokenIn: z.string().optional(),
  tokenOut: z.string().optional(),
  usd: z.number().positive().optional(),
  recipient: z.string().optional(),
  reason: z.string().min(3),
  beneficiaryName: z.string().min(2),
  // optional identifiers
  requestId: z.string().optional(),
});

function normalizeSymbol(s?: string) {
  return (s || "").trim().toUpperCase();
}

function allowlisted(list: string[], value?: string) {
  if (!value) return false;
  return list.map((x) => x.toUpperCase()).includes(value.toUpperCase());
}

function bankrPolicy() {
  const enabled = env("BANKR_EXECUTION_ENABLED", "false") === "true";
  const maxUsd = Number(env("BANKR_MAX_USD", "25"));
  const allowlistTokens = env("BANKR_ALLOWLIST_TOKENS", "USDC,ETH").split(",").map((s) => s.trim()).filter(Boolean);
  const allowlistChains = env("BANKR_ALLOWLIST_CHAINS", "base").split(",").map((s) => s.trim()).filter(Boolean);
  const operatorToken = env("OPERATOR_CONFIRM_TOKEN", "");
  return { enabled, maxUsd, allowlistTokens, allowlistChains, operatorToken };
}

export async function GET(req: NextRequest) {
  const limited = rateLimit(req, { windowMs: 10_000, max: 30 });
  if (!limited.ok) return err("RATE_LIMITED", "Too many requests", { retryAfterMs: limited.retryAfterMs }, 429);

  const url = new URL(req.url);
  const parsed = QuerySchema.safeParse(Object.fromEntries(url.searchParams.entries()));
  if (!parsed.success) return err("BAD_REQUEST", "Invalid query params", parsed.error.flatten(), 400);

  const policy = bankrPolicy();

  if (parsed.data.action === "info") {
    return ok({
      ok: true,
      bankr: {
        executionEnabled: policy.enabled,
        maxUsd: policy.maxUsd,
        allowlistTokens: policy.allowlistTokens,
        allowlistChains: policy.allowlistChains,
        defaultMode: policy.enabled ? "LIVE_REQUIRES_OPERATOR" : "PROPOSAL_ONLY",
      },
      nextAction: "plan",
      safety: {
        note: "Execution is disabled by default. Enable BANKR_EXECUTION_ENABLED=true AND provide OPERATOR_CONFIRM_TOKEN to allow guarded execution.",
      },
    });
  }

  if (parsed.data.action === "plan") {
    // lightweight plan via querystring (agent-friendly)
    const intent = parsed.data.intent;
    if (!intent) return err("BAD_REQUEST", "Missing intent", { required: ["intent"] }, 400);

    const chain = (parsed.data.chain || "").trim();
    const usd = parsed.data.usd;
    const tokenIn = normalizeSymbol(parsed.data.tokenIn);
    const tokenOut = normalizeSymbol(parsed.data.tokenOut);

    if (!allowlisted(policy.allowlistChains, chain)) {
      return err("POLICY_DENY", "Chain not allowlisted", { allowlistChains: policy.allowlistChains }, 400);
    }
    if (usd && usd > policy.maxUsd) {
      return err("POLICY_DENY", "USD amount exceeds max", { maxUsd: policy.maxUsd }, 400);
    }
    if (tokenIn && !allowlisted(policy.allowlistTokens, tokenIn)) {
      return err("POLICY_DENY", "tokenIn not allowlisted", { allowlistTokens: policy.allowlistTokens }, 400);
    }
    if (tokenOut && !allowlisted(policy.allowlistTokens, tokenOut)) {
      return err("POLICY_DENY", "tokenOut not allowlisted", { allowlistTokens: policy.allowlistTokens }, 400);
    }

    return ok({
      ok: true,
      plan: {
        intent,
        chain,
        tokenIn: tokenIn || undefined,
        tokenOut: tokenOut || undefined,
        usd: usd || undefined,
        mode: policy.enabled ? "LIVE_REQUIRES_OPERATOR" : "PROPOSAL_ONLY",
        steps: [
          "Generate a proposal payload with beneficiaryName + reason",
          "POST /api/agent/bankr to get an executionPlan and proof",
          policy.enabled ? "Operator may POST /api/agent/bankr?action=execute with x-operator-token" : "Execution is disabled; stop at proposal stage",
        ],
      },
      nextAction: "POST proposal",
    });
  }

  return err("BAD_REQUEST", "Unsupported action", { supported: ["info", "plan"] }, 400);
}

export async function POST(req: NextRequest) {
  const limited = rateLimit(req, { windowMs: 10_000, max: 20 });
  if (!limited.ok) return err("RATE_LIMITED", "Too many requests", { retryAfterMs: limited.retryAfterMs }, 429);

  const url = new URL(req.url);
  const parsedQuery = QuerySchema.safeParse(Object.fromEntries(url.searchParams.entries()));
  if (!parsedQuery.success) return err("BAD_REQUEST", "Invalid query params", parsedQuery.error.flatten(), 400);

  const policy = bankrPolicy();
  const isExecute = parsedQuery.data.action === "execute";

  const bodyJson = await req.json().catch(() => null);
  const parsedBody = PlanBodySchema.safeParse(bodyJson);
  if (!parsedBody.success) return err("BAD_REQUEST", "Invalid body", parsedBody.error.flatten(), 400);

  const body = parsedBody.data;
  const chain = body.chain.trim();
  const tokenIn = normalizeSymbol(body.tokenIn);
  const tokenOut = normalizeSymbol(body.tokenOut);

  if (!allowlisted(policy.allowlistChains, chain)) {
    return err("POLICY_DENY", "Chain not allowlisted", { allowlistChains: policy.allowlistChains }, 400);
  }
  if (body.usd && body.usd > policy.maxUsd) {
    return err("POLICY_DENY", "USD amount exceeds max", { maxUsd: policy.maxUsd }, 400);
  }
  if (tokenIn && !allowlisted(policy.allowlistTokens, tokenIn)) {
    return err("POLICY_DENY", "tokenIn not allowlisted", { allowlistTokens: policy.allowlistTokens }, 400);
  }
  if (tokenOut && !allowlisted(policy.allowlistTokens, tokenOut)) {
    return err("POLICY_DENY", "tokenOut not allowlisted", { allowlistTokens: policy.allowlistTokens }, 400);
  }

  const executionPlan = {
    intent: body.intent,
    chain,
    tokenIn: tokenIn || undefined,
    tokenOut: tokenOut || undefined,
    usd: body.usd || undefined,
    recipient: body.recipient,
    requestId: body.requestId,
    policy: {
      executionEnabled: policy.enabled,
      maxUsd: policy.maxUsd,
      allowlistTokens: policy.allowlistTokens,
      allowlistChains: policy.allowlistChains,
    },
    gates: policy.enabled
      ? ["operator_token_required", "server_side_allowlists", "max_usd_cap"]
      : ["execution_disabled_by_default"],
    mode: policy.enabled ? "LIVE_REQUIRES_OPERATOR" : "PROPOSAL_ONLY",
    createdAt: new Date().toISOString(),
  };

  const proof = buildProof({
    kind: "agent_action",
    refs: { url: "/api/agent/bankr" },
    claims: {
      system: "bankr",
      action: isExecute ? "execute_attempt" : "proposal",
      executionPlan,
      beneficiaryName: body.beneficiaryName,
      reason: body.reason,
    },
  });

  if (!isExecute) {
    return ok({
      ok: true,
      mode: "PROPOSAL_ONLY",
      executionPlan,
      proof,
      nextAction: policy.enabled
        ? "If operator approves: POST /api/agent/bankr?action=execute with x-operator-token"
        : "Execution disabled. Present plan to operator for manual execution.",
    });
  }

  // execute mode (guarded)
  if (!policy.enabled) {
    return err("EXECUTION_DISABLED", "Bankr execution is disabled by default", { hint: "Set BANKR_EXECUTION_ENABLED=true and OPERATOR_CONFIRM_TOKEN" }, 403);
  }
  const token = req.headers.get("x-operator-token") || "";
  if (!policy.operatorToken || token !== policy.operatorToken) {
    return err("OPERATOR_CONFIRMATION_REQUIRED", "Missing or invalid operator token", { header: "x-operator-token" }, 403);
  }

  // NOTE: Still DRY_RUN until we wire a real Bankr client.
  return ok({
    ok: true,
    mode: "DRY_RUN",
    executionPlan,
    proof,
    nextAction: "Wire Bankr client (future unit) OR execute manually with Bankr UI/bot.",
  });
}
