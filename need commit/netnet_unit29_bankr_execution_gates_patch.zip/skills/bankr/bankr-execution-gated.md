# Skill: bankr.execution_gated

Purpose: generate **proposal-first** Bankr plans and optionally run an **operator-confirmed** execute attempt (still DRY_RUN until Bankr client wiring is added).

## Endpoints

- `GET /api/agent/bankr?action=info`
- `GET /api/agent/bankr?action=plan&intent=swap&chain=base&tokenIn=USDC&tokenOut=ETH&usd=10`
- `POST /api/agent/bankr` (proposal payload)
- `POST /api/agent/bankr?action=execute` (operator-confirmed; default disabled)

## Guardrails

- Never move funds autonomously.
- Always return an execution plan + proof.
- Only execute when:
  - `BANKR_EXECUTION_ENABLED=true`
  - operator supplies `x-operator-token` matching `OPERATOR_CONFIRM_TOKEN`
- Enforce allowlists and caps:
  - `BANKR_ALLOWLIST_TOKENS`
  - `BANKR_ALLOWLIST_CHAINS`
  - `BANKR_MAX_USD`

## Proposal flow

1) Plan:
- call `GET ...action=plan...`

2) Proposal:
- call `POST /api/agent/bankr` with:
  - `beneficiaryName`
  - `reason`

3) Operator approval:
- If approved, operator calls `POST ...action=execute` with `x-operator-token`.

## Success criteria

- Proposal always succeeds if within policy.
- Execute is blocked by default and requires explicit operator confirmation.
