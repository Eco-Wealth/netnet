#!/usr/bin/env bash
set -euo pipefail

BASE_URL="${BASE_URL:-http://localhost:3000}"

echo "[bankr] info"
curl -s "$BASE_URL/api/agent/bankr?action=info" | grep -q '"ok":true'

echo "[bankr] proposal"
curl -s -X POST "$BASE_URL/api/agent/bankr" \
  -H "content-type: application/json" \
  -d '{"intent":"swap","chain":"base","tokenIn":"USDC","tokenOut":"ETH","usd":10,"beneficiaryName":"EcoWealth","reason":"smoke"}' \
  | grep -q '"ok":true'

echo "[bankr] execute should be blocked"
HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" -X POST "$BASE_URL/api/agent/bankr?action=execute" \
  -H "content-type: application/json" \
  -d '{"intent":"swap","chain":"base","tokenIn":"USDC","tokenOut":"ETH","usd":10,"beneficiaryName":"EcoWealth","reason":"smoke"}')

if [ "$HTTP_CODE" != "403" ]; then
  echo "Expected 403, got $HTTP_CODE"
  exit 1
fi

echo "[bankr] ok"
