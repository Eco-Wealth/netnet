# Unit 22 — Skill QA Harness

Purpose: prevent skill/API contract drift by running a small, deterministic suite against the live dev server.

## What it checks
- `/api/health` returns `{ ok:true }`
- `/api/proof-paid` is paywalled by default (402) unless `X402_DEV_BYPASS=true`
- Agent endpoints respond with the expected top-level shape
- Proof builder is deterministic for identical inputs
- Validation errors use the normalized `{ ok:false, error:{ code, message } }` shape

## How to run
From repo root:
- `npm run test`

Or from cockpit:
- `npm --prefix netnet/cockpit run test:contracts`

Notes:
- By default Playwright starts `next dev` on port 3001 for contract tests.
- If you already have a server running, set `PW_BASE_URL=http://localhost:3000`.
