import { defineConfig } from "@playwright/test";

export default defineConfig({
  testDir: "./tests",
  timeout: 60_000,
  use: {
    baseURL: process.env.PW_BASE_URL || "http://localhost:3001",
  },
  webServer: process.env.PW_BASE_URL
    ? undefined
    : {
        command: "npm run dev -- -p 3001",
        port: 3001,
        reuseExistingServer: !process.env.CI,
        timeout: 120_000,
      },
  reporter: process.env.CI ? [["list"]] : [["html", { open: "never" }], ["list"]],
});
