import { test, expect } from "@playwright/test";

// Contract-level smoke tests for agent/skill endpoints.
// These tests are intentionally small + deterministic to prevent drift.

test.describe("Skill contract smoke", () => {
  test("GET /api/health -> { ok:true, service }", async ({ request, baseURL }) => {
    const res = await request.get(`${baseURL}/api/health`);
    expect(res.status()).toBe(200);
    const body = await res.json();
    expect(body.ok).toBe(true);
    expect(typeof body.service).toBe("string");
  });

  test("GET /api/proof-paid -> 402 unless bypass", async ({ request, baseURL }) => {
    const res = await request.get(`${baseURL}/api/proof-paid`);
    // In CI/dev default posture: paywall should be enforced.
    expect([200, 402]).toContain(res.status());
    const body = await res.json();
    if (res.status() === 402) {
      expect(body.ok).toBe(false);
      expect(body.paid).toBe(false);
      expect(body.error?.code).toBe("PAYMENT_REQUIRED");
    } else {
      // If someone sets X402_DEV_BYPASS=true, allow 200.
      expect(body.ok).toBe(true);
      expect(body.paid).toBe(true);
    }
  });

  test("GET /api/agent/carbon?action=info -> ok + actions", async ({ request, baseURL }) => {
    const res = await request.get(`${baseURL}/api/agent/carbon?action=info`);
    expect(res.status()).toBe(200);
    const body = await res.json();
    expect(body.ok).toBe(true);
    expect(Array.isArray(body.actions)).toBe(true);
    expect(body.actions).toContain("projects");
    expect(body.actions).toContain("quote");
    expect(body.actions).toContain("status");
  });

  test("GET /api/agent/trade?action=info -> safe defaults", async ({ request, baseURL }) => {
    const res = await request.get(`${baseURL}/api/agent/trade?action=info`);
    expect(res.status()).toBe(200);
    const body = await res.json();
    expect(body.ok).toBe(true);
    expect(body.trade?.enabled).toBe(false);
    expect(body.trade?.defaultMode).toBe("DRY_RUN");
  });

  test("GET /api/ecotoken/scan invalid hash -> 400 normalized error", async ({ request, baseURL }) => {
    const res = await request.get(`${baseURL}/api/ecotoken/scan?hash=not-a-hash`);
    expect(res.status()).toBe(400);
    const body = await res.json();
    expect(body.ok).toBe(false);
    expect(body.error?.code).toBeDefined();
  });

  test("POST /api/proof/build -> deterministic proof", async ({ request, baseURL }) => {
    const payload = {
      kind: "bridge_retirement",
      refs: { txHash: "0x" + "11".repeat(32), certificateId: "cert_test_123", url: "https://example.com" },
      claims: { amount: 1, token: "USDC", chain: "base" },
    };

    const r1 = await request.post(`${baseURL}/api/proof/build`, { data: payload });
    expect(r1.status()).toBe(200);
    const b1 = await r1.json();
    expect(b1.ok).toBe(true);
    expect(b1.proof?.schema).toBe("netnet.proof.v1");

    const r2 = await request.post(`${baseURL}/api/proof/build`, { data: payload });
    expect(r2.status()).toBe(200);
    const b2 = await r2.json();

    // Deterministic: same input -> identical proof JSON
    expect(JSON.stringify(b1.proof)).toBe(JSON.stringify(b2.proof));
  });
});
