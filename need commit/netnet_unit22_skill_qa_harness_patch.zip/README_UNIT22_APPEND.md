## QA (Skill Contract Tests)

Run the contract suite (starts cockpit on port 3001 automatically):
- `npm run test`

If you already have the app running elsewhere:
- `PW_BASE_URL=http://localhost:3000 npm run test`
