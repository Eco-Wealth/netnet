# netnet-cockpit-handoff (operator pay packet)

## What it does
Creates a stable **pay instruction packet** to hand off to an operator when a workflow requires a manual payment.

## Endpoint
POST `/api/handoff/pay`

## Inputs
- chain (default: base)
- token (default: USDC)
- recipient (required)
- amount (required; string or number)
- memo (optional)
- deadlineIso (optional)

## Output
- ok:true
- nextAction:"pay"
- pay:{ chain, token, recipient, amount, memo?, deadlineIso? }
- warnings?: string[]

## Example (curl)
```bash
curl -s -X POST http://localhost:3000/api/handoff/pay \
  -H "content-type: application/json" \
  -d '{"chain":"base","token":"USDC","recipient":"0x0000000000000000000000000000000000000000","amount":"1.00"}'
```

## Guardrails
- Never invent recipient/amount. Use only trusted upstream values.
- If warnings present, require operator confirmation against the UI/wallet display.
