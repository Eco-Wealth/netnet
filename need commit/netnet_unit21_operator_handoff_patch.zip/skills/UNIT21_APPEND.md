## Unit 21: Operator handoff
- Added `netnet-cockpit-handoff.md` for normalized pay packets via `/api/handoff/pay`.
