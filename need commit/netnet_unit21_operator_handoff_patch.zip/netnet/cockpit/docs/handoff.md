# Operator handoff: pay instructions (Unit 21)

This endpoint creates a **stable, agent-readable payment instruction packet**. Use it when a workflow (Bridge retirement, x402, etc.) returns a provider-specific payment shape and you want one normalized object to hand to a human operator.

## Endpoint

`POST /api/handoff/pay`

Request JSON:

```json
{
  "chain": "base",
  "token": "USDC",
  "recipient": "0x...",
  "amount": "1.23",
  "memo": "optional",
  "deadlineIso": "2026-02-08T20:00:00Z"
}
```

Response JSON:

```json
{
  "ok": true,
  "nextAction": "pay",
  "pay": {
    "chain": "base",
    "token": "USDC",
    "recipient": "0x...",
    "amount": "1.23",
    "memo": "optional",
    "deadlineIso": "2026-02-08T20:00:00Z"
  },
  "warnings": ["...optional..."]
}
```

Errors:

```json
{ "ok": false, "error": { "code": "BAD_REQUEST", "message": "...", "details": {...} } }
```

## Safety notes

- This endpoint does **not** broadcast transactions.
- It is intended to standardize the last-mile “human pays” step.
- Treat `warnings` as “slow down and verify”.
