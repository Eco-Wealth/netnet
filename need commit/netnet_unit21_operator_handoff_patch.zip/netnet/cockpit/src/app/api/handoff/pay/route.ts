import { NextResponse } from "next/server";
import { z } from "zod";
import { buildPayPacket } from "@/lib/payments/instructions";

const BodySchema = z.object({
  chain: z.string().min(1).default("base"),
  token: z.string().min(1).default("USDC"),
  recipient: z.string().min(1),
  amount: z.union([z.string().min(1), z.number().positive()]).transform((v) => String(v)),
  memo: z.string().optional(),
  deadlineIso: z.string().optional(),
});

export async function POST(req: Request) {
  try {
    const json = await req.json().catch(() => null);
    const parsed = BodySchema.safeParse(json);

    if (!parsed.success) {
      return NextResponse.json(
        { ok: false, error: { code: "BAD_REQUEST", message: "Invalid payload", details: parsed.error.flatten() } },
        { status: 400 }
      );
    }

    const pay = parsed.data;
    const warnings: string[] = [];
    if (!pay.recipient.startsWith("0x")) warnings.push("Recipient does not look like an EVM address (expected 0x…).");
    if (pay.token.toUpperCase() === "USDC" && pay.amount.includes(".")) {
      // informational only; USDC supports decimals but downstream systems vary.
      warnings.push("Amount contains decimals; confirm the wallet UX displays the exact amount before sending.");
    }

    return NextResponse.json(buildPayPacket({ ...pay, token: pay.token.toUpperCase() }, warnings));
  } catch (e: any) {
    return NextResponse.json(
      { ok: false, error: { code: "INTERNAL", message: e?.message || "Unexpected error" } },
      { status: 500 }
    );
  }
}
