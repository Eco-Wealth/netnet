export type ChainId = string;
export type TokenSymbol = string;

export type PayInstruction = {
  chain: ChainId;                 // e.g. "base"
  token: TokenSymbol;             // e.g. "USDC"
  recipient: string;              // 0x...
  amount: string;                 // decimal string (human units)
  memo?: string;                  // optional memo / note
  deadlineIso?: string;           // ISO timestamp
};

export type PayPacket = {
  ok: true;
  nextAction: "pay";
  pay: PayInstruction;
  warnings?: string[];
};

export type PayErrorPacket = {
  ok: false;
  error: { code: string; message: string; details?: any };
};

export function buildPayPacket(input: PayInstruction, warnings: string[] = []): PayPacket {
  return {
    ok: true,
    nextAction: "pay",
    pay: {
      chain: input.chain,
      token: input.token,
      recipient: input.recipient,
      amount: input.amount,
      memo: input.memo,
      deadlineIso: input.deadlineIso,
    },
    ...(warnings.length ? { warnings } : {}),
  };
}

/**
 * Best-effort normalizer for upstream payment shapes (Bridge or other providers).
 * Goal: produce a stable, agent-friendly PayInstruction without leaking provider quirks.
 */
export function normalizeUpstreamPayInstruction(upstream: any): { pay?: PayInstruction; warnings: string[] } {
  const warnings: string[] = [];
  if (!upstream || typeof upstream !== "object") return { warnings: ["Upstream payload missing or invalid."] };

  // Common candidates
  const recipient =
    upstream.recipient ||
    upstream.to ||
    upstream.payTo ||
    upstream.pay_to ||
    upstream?.payment?.recipient ||
    upstream?.payment?.to;

  const amount =
    upstream.amount ||
    upstream.total ||
    upstream.totalCost ||
    upstream?.payment?.amount ||
    upstream?.payment?.total ||
    upstream?.payment?.value;

  const chain = upstream.chain || upstream.network || upstream?.payment?.chain || "base";
  const token = upstream.token || upstream.currency || upstream?.payment?.token || "USDC";
  const memo = upstream.memo || upstream.note || upstream?.payment?.memo;
  const deadlineIso = upstream.deadlineIso || upstream.deadline || upstream?.payment?.deadlineIso;

  if (!recipient) warnings.push("Missing recipient (pay-to address).");
  if (!amount) warnings.push("Missing amount.");

  if (!recipient || !amount) return { warnings };

  return {
    pay: {
      chain: String(chain),
      token: String(token),
      recipient: String(recipient),
      amount: String(amount),
      ...(memo ? { memo: String(memo) } : {}),
      ...(deadlineIso ? { deadlineIso: String(deadlineIso) } : {}),
    },
    warnings,
  };
}
