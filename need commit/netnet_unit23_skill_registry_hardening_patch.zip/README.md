# netnet

## Quickstart

- Node: see `.nvmrc` (Node 20+ recommended)

```bash
npm install --legacy-peer-deps
npm run dev
```

Cockpit runs at http://localhost:3000

## Skills Registry

This repo maintains a versioned skills manifest at `skills/manifest.json`.

Validate locally:

```bash
npm run skills:validate
```

