import fs from "node:fs";
import path from "node:path";

function fail(msg) {
  console.error(`skills:validate: ${msg}`);
  process.exit(1);
}

const manifestPath = path.join(process.cwd(), "skills", "manifest.json");
if (!fs.existsSync(manifestPath)) fail("missing skills/manifest.json");

const raw = fs.readFileSync(manifestPath, "utf8");
let manifest;
try {
  manifest = JSON.parse(raw);
} catch (e) {
  fail(`manifest.json is not valid JSON: ${e?.message || e}`);
}

if (manifest.schema !== "netnet.skills.manifest.v1") {
  fail(`unexpected schema: ${manifest.schema}`);
}
if (!Array.isArray(manifest.skills) || manifest.skills.length === 0) {
  fail("skills must be a non-empty array");
}

const errors = [];
for (const s of manifest.skills) {
  if (!s.id) errors.push("skill missing id");
  if (!s.name) errors.push(`skill ${s.id || "<unknown>"} missing name`);
  if (!s.version) errors.push(`skill ${s.id || "<unknown>"} missing version`);
  if (!Array.isArray(s.entrypoints) || s.entrypoints.length === 0) errors.push(`skill ${s.id} missing entrypoints`);
  for (const e of s.entrypoints || []) {
    if (!e.path) errors.push(`skill ${s.id} entrypoint missing path`);
    else {
      const p = path.join(process.cwd(), e.path);
      if (!fs.existsSync(p)) errors.push(`skill ${s.id} entrypoint path not found: ${e.path}`);
    }
  }
  if (!Array.isArray(s.endpoints) || s.endpoints.length === 0) errors.push(`skill ${s.id} missing endpoints`);
  if (!Array.isArray(s.tests) || s.tests.length === 0) errors.push(`skill ${s.id} missing tests`);
}

if (errors.length) {
  for (const e of errors) console.error(`- ${e}`);
  process.exit(1);
}

console.log("skills:validate: OK");

