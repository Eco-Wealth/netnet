## Contract notes (Unit 17)

- The agent should treat `POST /api/agent/carbon` as **initiation only**; it returns `{ state: "PAYMENT_REQUIRED", payment, nextAction }`.
- After operator payment, agent calls `GET /api/agent/carbon?action=status&txHash=...` until `state === "RETIRED"`.
- Then call `POST /api/proof/build` to produce a `netnet.proof.v1` artifact.

Recommended idempotency:
- Provide `idempotencyKey` in POST body or `Idempotency-Key` header to avoid duplicates during retries.
