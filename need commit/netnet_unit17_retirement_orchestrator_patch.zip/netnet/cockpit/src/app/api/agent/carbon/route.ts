import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { ratelimit } from "@/lib/http/ratelimit";
import { jsonError, ok } from "@/lib/http/errors";
import { bridgeClient } from "@/lib/bridge/client";
import { buildCarbonNextAction, type CarbonOrchestratorState, upsertIdempotency } from "@/lib/orchestrator/carbon";

const rl = ratelimit({ windowMs: 10_000, max: 30 });

const ActionSchema = z.enum(["info", "estimate", "projects", "quote", "status"]);
const ChainSchema = z.string().min(1);
const TokenSchema = z.string().min(1);

const EstimateQuerySchema = z.object({
  computeHours: z.coerce.number().min(0).max(24 * 365).default(1),
  modelSize: z.coerce.number().min(0).max(1_000_000_000).default(0),
});

const ProjectsQuerySchema = z.object({
  type: z.string().optional(),
  chain: z.string().optional(),
  token: z.string().optional(),
  search: z.string().optional(),
});

const QuoteQuerySchema = z.object({
  projectId: z.string().min(1),
  amount: z.coerce.number().positive(),
  chain: ChainSchema.default("base"),
  token: TokenSchema.default("USDC"),
});

const StatusQuerySchema = z.object({
  txHash: z.string().min(1),
});

const PostBodySchema = z.object({
  // Safe-by-default: required for any POST
  beneficiaryName: z.string().min(2),
  reason: z.string().min(3),

  // Retirement intent
  projectId: z.string().min(1),
  amount: z.number().positive(),
  chain: ChainSchema.default("base"),
  token: TokenSchema.default("USDC"),

  // Optional: caller can provide an idempotency key to avoid duplicate "init" calls.
  // In serverless, this is best-effort; still useful for local + short retry loops.
  idempotencyKey: z.string().min(8).max(128).optional(),
});

export async function GET(req: NextRequest) {
  const limited = rl(req);
  if (!limited.ok) return jsonError("RATE_LIMITED", "Too many requests", { retryAfterMs: limited.retryAfterMs }, 429);

  const url = new URL(req.url);
  const actionRaw = url.searchParams.get("action") ?? "info";
  const action = ActionSchema.safeParse(actionRaw);
  if (!action.success) return jsonError("BAD_REQUEST", "Invalid action", { allowed: ActionSchema.options }, 400);

  try {
    if (action.data === "info") {
      return ok({
        actions: ActionSchema.options,
        nextAction: "projects",
        safety: {
          postRequires: ["beneficiaryName", "reason"],
          note:
            "POST initiates a retirement request and returns payment instructions; payment must be explicitly executed by an operator.",
        },
      });
    }

    if (action.data === "estimate") {
      // Keep backward compatibility: simple estimator stays, but ensure typed output for agents.
      const parsed = EstimateQuerySchema.safeParse({
        computeHours: url.searchParams.get("computeHours") ?? undefined,
        modelSize: url.searchParams.get("modelSize") ?? undefined,
      });
      if (!parsed.success) return jsonError("BAD_REQUEST", "Invalid estimate params", parsed.error.flatten(), 400);

      // Placeholder: does NOT claim accuracy. Just a deterministic heuristic with confidence metadata.
      const { computeHours, modelSize } = parsed.data;
      const kgCO2e = Math.max(0, computeHours) * 0.05 + (Math.max(0, modelSize) / 1e9) * 0.02;
      return ok({
        ok: true,
        estimate: {
          kgCO2e: Number(kgCO2e.toFixed(6)),
          method: "heuristic_v1",
          confidence: "low",
          notes: "Heuristic estimate only; replace with calibrated model when available.",
        },
        nextAction: "projects",
      });
    }

    if (action.data === "projects") {
      const parsed = ProjectsQuerySchema.safeParse({
        type: url.searchParams.get("type") ?? undefined,
        chain: url.searchParams.get("chain") ?? undefined,
        token: url.searchParams.get("token") ?? undefined,
        search: url.searchParams.get("search") ?? undefined,
      });
      if (!parsed.success) return jsonError("BAD_REQUEST", "Invalid projects params", parsed.error.flatten(), 400);

      const projects = await bridgeClient().projects(parsed.data);
      return ok({ ok: true, projects, nextAction: "quote" });
    }

    if (action.data === "quote") {
      const parsed = QuoteQuerySchema.safeParse({
        projectId: url.searchParams.get("projectId") ?? undefined,
        amount: url.searchParams.get("amount") ?? undefined,
        chain: url.searchParams.get("chain") ?? undefined,
        token: url.searchParams.get("token") ?? undefined,
      });
      if (!parsed.success) return jsonError("BAD_REQUEST", "Invalid quote params", parsed.error.flatten(), 400);

      const quote = await bridgeClient().quote(parsed.data);
      return ok({ ok: true, quote, nextAction: "POST /api/agent/carbon" });
    }

    // status
    const parsed = StatusQuerySchema.safeParse({ txHash: url.searchParams.get("txHash") ?? undefined });
    if (!parsed.success) return jsonError("BAD_REQUEST", "Invalid status params", parsed.error.flatten(), 400);

    const status = await bridgeClient().tx(parsed.data.txHash);
    const state: CarbonOrchestratorState = status?.ok && status?.status === "RETIRED" ? "RETIRED" : "TRACKING";
    return ok({
      ok: true,
      state,
      status,
      nextAction: buildCarbonNextAction(state),
    });
  } catch (e: any) {
    return jsonError("UPSTREAM_ERROR", "Agent carbon endpoint failed", { message: e?.message }, 502);
  }
}

export async function POST(req: NextRequest) {
  const limited = rl(req);
  if (!limited.ok) return jsonError("RATE_LIMITED", "Too many requests", { retryAfterMs: limited.retryAfterMs }, 429);

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return jsonError("BAD_REQUEST", "Body must be JSON", undefined, 400);
  }
  const parsed = PostBodySchema.safeParse(body);
  if (!parsed.success) return jsonError("BAD_REQUEST", "Invalid request body", parsed.error.flatten(), 400);

  const idKey =
    parsed.data.idempotencyKey ||
    req.headers.get("idempotency-key") ||
    // deterministic-ish fallback: helps dedupe accidental repeat clicks in the same runtime
    `${parsed.data.projectId}:${parsed.data.chain}:${parsed.data.token}:${parsed.data.amount}:${parsed.data.beneficiaryName}`.slice(0, 128);

  const cached = upsertIdempotency(idKey);
  if (cached.hit) return ok(cached.value);

  try {
    const retire = await bridgeClient().retire({
      projectId: parsed.data.projectId,
      amount: parsed.data.amount,
      chain: parsed.data.chain,
      token: parsed.data.token,
      beneficiaryName: parsed.data.beneficiaryName,
      reason: parsed.data.reason,
    });

    // Normalize to a predictable agent contract.
    const response = {
      ok: true,
      state: "PAYMENT_REQUIRED" as CarbonOrchestratorState,
      nextAction: buildCarbonNextAction("PAYMENT_REQUIRED"),
      request: {
        projectId: parsed.data.projectId,
        amount: parsed.data.amount,
        chain: parsed.data.chain,
        token: parsed.data.token,
        beneficiaryName: parsed.data.beneficiaryName,
        reason: parsed.data.reason,
      },
      payment: retire?.payment || retire,
    };

    upsertIdempotency(idKey, response);
    return ok(response);
  } catch (e: any) {
    const err = jsonError("UPSTREAM_ERROR", "Failed to initiate retirement", { message: e?.message }, 502);
    upsertIdempotency(idKey, { ok: false, state: "ERROR", nextAction: "retry_later", error: err });
    return err;
  }
}
