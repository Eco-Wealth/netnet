export type CarbonOrchestratorState =
  | "PLANNING"
  | "PAYMENT_REQUIRED"
  | "TRACKING"
  | "RETIRED"
  | "ERROR";

export function buildCarbonNextAction(state: CarbonOrchestratorState): string {
  switch (state) {
    case "PLANNING":
      return "projects";
    case "PAYMENT_REQUIRED":
      return "operator_pay_then_status";
    case "TRACKING":
      return "status";
    case "RETIRED":
      return "build_proof";
    case "ERROR":
    default:
      return "retry_later";
  }
}

type CacheEntry = { value: any; expiresAt: number };

const TTL_MS = 60_000; // best-effort, short-lived idempotency (good for retries)
const cache = (globalThis as any).__NN_IDEMPOTENCY__ as Map<string, CacheEntry> | undefined;
const store: Map<string, CacheEntry> = cache ?? new Map<string, CacheEntry>();
(globalThis as any).__NN_IDEMPOTENCY__ = store;

export function upsertIdempotency(key: string, value?: any): { hit: boolean; value?: any } {
  const now = Date.now();
  const existing = store.get(key);
  if (existing && existing.expiresAt > now) return { hit: true, value: existing.value };

  // cleanup opportunistically
  for (const [k, v] of store.entries()) {
    if (v.expiresAt <= now) store.delete(k);
  }

  if (value !== undefined) store.set(key, { value, expiresAt: now + TTL_MS });
  return { hit: false };
}
