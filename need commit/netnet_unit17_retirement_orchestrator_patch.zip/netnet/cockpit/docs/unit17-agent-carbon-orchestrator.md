# Unit 17 — Retirement Orchestrator Skill (Agent Carbon)

Goal: make the agent-facing carbon endpoint predictable for autonomous retries **without** enabling autonomous fund movement.

## What changed
- `/api/agent/carbon` now returns an explicit `state` + `nextAction` for `status` and `POST` flows.
- `POST` supports **best-effort idempotency** via `idempotencyKey` (body) or `Idempotency-Key` (header).
- Output is normalized for agents: `payment` is returned as an object; the UI/operator executes payment separately.

## States
- `PAYMENT_REQUIRED`: operator must pay; agent should wait for a tx hash then call `status`.
- `TRACKING`: retirement in flight (tx pending / not retired yet).
- `RETIRED`: completed; agent should call `/api/proof/build`.

## Curl examples
```bash
# info
curl -s "http://localhost:3000/api/agent/carbon?action=info" | jq

# projects
curl -s "http://localhost:3000/api/agent/carbon?action=projects" | jq

# quote
curl -s "http://localhost:3000/api/agent/carbon?action=quote&projectId=demo&amount=1&chain=base&token=USDC" | jq

# initiate (does NOT move funds)
curl -s -X POST "http://localhost:3000/api/agent/carbon" \
  -H "content-type: application/json" \
  -H "idempotency-key: demo-12345678" \
  -d '{"beneficiaryName":"EcoWealth Operator","reason":"test retirement","projectId":"demo","amount":1,"chain":"base","token":"USDC"}' | jq

# status
curl -s "http://localhost:3000/api/agent/carbon?action=status&txHash=0xdeadbeef" | jq
```
