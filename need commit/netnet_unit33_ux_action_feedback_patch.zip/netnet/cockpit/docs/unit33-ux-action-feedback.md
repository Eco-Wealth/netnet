# Unit 33 — UX Action Feedback + Tooltips

This unit adds a lightweight “action feed” and hover tooltips so operator clicks produce visible, durable feedback.

## What changed

- `/execute` is now a command center that:
  - reads `/api/agent/trade?action=info`
  - reads `/api/agent/carbon?action=info`
  - writes a local `action feed` entry for important clicks (no spend)
- Added:
  - `src/lib/actionLog.ts` (localStorage-backed log)
  - `src/components/ActionFeed.tsx` (UI)
  - `src/components/Tooltip.tsx` (hover info)
- Shell nav adds `Identity`

## Notes

This does **not** enable autonomous execution. It makes the cockpit feel responsive and audit-friendly during development.

