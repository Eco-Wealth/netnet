export type ActionEvent = {
  id: string;
  ts: string; // ISO
  kind: "INFO" | "PROPOSE" | "DRY_RUN" | "EXECUTE" | "ERROR";
  title: string;
  detail?: string;
  costNote?: string;
};

const KEY = "netnet.actionLog.v1";

export function loadActionLog(): ActionEvent[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed as ActionEvent[];
  } catch {
    return [];
  }
}

export function pushActionEvent(ev: Omit<ActionEvent, "id" | "ts">): ActionEvent {
  const full: ActionEvent = {
    id: crypto.randomUUID(),
    ts: new Date().toISOString(),
    ...ev,
  };
  if (typeof window === "undefined") return full;
  const next = [full, ...loadActionLog()].slice(0, 50);
  window.localStorage.setItem(KEY, JSON.stringify(next));
  return full;
}

export function clearActionLog() {
  if (typeof window === "undefined") return;
  window.localStorage.removeItem(KEY);
}
