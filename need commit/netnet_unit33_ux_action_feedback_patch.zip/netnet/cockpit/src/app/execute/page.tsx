"use client";

import React from "react";
import Link from "next/link";
import { Card, CardBody, Pill, Button } from "@/components/ui";
import { Tooltip } from "@/components/Tooltip";
import { ActionFeed } from "@/components/ActionFeed";
import { pushActionEvent } from "@/lib/actionLog";

type ApiResult = { ok: boolean; [k: string]: any };

async function getJson(url: string): Promise<ApiResult> {
  const res = await fetch(url, { cache: "no-store" });
  const txt = await res.text();
  let data: any = {};
  try {
    data = JSON.parse(txt);
  } catch {
    data = { raw: txt };
  }
  if (!res.ok) {
    throw new Error(data?.error?.message ?? `HTTP ${res.status}`);
  }
  return data;
}

export default function ExecutePage() {
  const [loading, setLoading] = React.useState<string | null>(null);
  const [tradeInfo, setTradeInfo] = React.useState<ApiResult | null>(null);
  const [carbonInfo, setCarbonInfo] = React.useState<ApiResult | null>(null);

  async function refresh() {
    setLoading("refresh");
    try {
      const [t, c] = await Promise.all([
        getJson("/api/agent/trade?action=info"),
        getJson("/api/agent/carbon?action=info"),
      ]);
      setTradeInfo(t);
      setCarbonInfo(c);
      pushActionEvent({
        kind: "INFO",
        title: "Refreshed agent surfaces",
        detail: "Fetched /agent/trade?action=info and /agent/carbon?action=info",
        costNote: "No spend. Read-only.",
      });
    } catch (e: any) {
      pushActionEvent({
        kind: "ERROR",
        title: "Refresh failed",
        detail: e?.message ?? String(e),
      });
    } finally {
      setLoading(null);
    }
  }

  React.useEffect(() => {
    refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold">Execute</h1>
          <p className="text-sm text-neutral-400 mt-1">
            Safe-by-default command center. Most actions are propose-only unless operator approves.
          </p>
        </div>

        <Button disabled={loading === "refresh"} onClick={refresh}>
          {loading === "refresh" ? "Refreshing…" : "Refresh"}
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardBody>
            <div className="flex items-center justify-between">
              <div className="font-semibold">Trading (stub)</div>
              <Pill>{tradeInfo?.ok ? "OK" : "…"}</Pill>
            </div>

            <div className="mt-3 text-sm text-neutral-300">
              <div className="flex items-center gap-2">
                <Tooltip label="Paper trading only until enabled by policy">
                  <span className="underline decoration-dotted text-neutral-200">Mode</span>
                </Tooltip>
                <span className="text-neutral-400">{tradeInfo?.trade?.defaultMode ?? "—"}</span>
              </div>

              <div className="flex items-center gap-2 mt-2">
                <span className="text-neutral-400">Caps</span>
                <span className="text-neutral-200">
                  ${tradeInfo?.trade?.maxUsd ?? "—"} / trade
                </span>
              </div>
            </div>

            <div className="mt-4 flex gap-2">
              <Link className="no-underline" href="/execute/paper">
                <Button variant="secondary">Paper</Button>
              </Link>
              <Button
                variant="secondary"
                onClick={() =>
                  pushActionEvent({
                    kind: "PROPOSE",
                    title: "Proposed: trade quote",
                    detail: "Next: call /api/agent/trade?action=quote with params (still DRY_RUN).",
                    costNote: "Will be read-only until EXECUTE is enabled.",
                  })
                }
              >
                Propose
              </Button>
            </div>
          </CardBody>
        </Card>

        <Card>
          <CardBody>
            <div className="flex items-center justify-between">
              <div className="font-semibold">Carbon (bridge)</div>
              <Pill>{carbonInfo?.ok ? "OK" : "…"}</Pill>
            </div>

            <div className="mt-3 text-sm text-neutral-300">
              <div className="text-neutral-400">Actions</div>
              <div className="mt-1 text-neutral-200">
                {(carbonInfo?.actions ?? []).join(", ") || "—"}
              </div>

              <div className="mt-2 text-neutral-400">Safety</div>
              <div className="mt-1 text-neutral-200">
                {carbonInfo?.safety?.note ?? "—"}
              </div>
            </div>

            <div className="mt-4 flex gap-2">
              <Link className="no-underline" href="/retire">
                <Button variant="secondary">Retire</Button>
              </Link>
              <Button
                variant="secondary"
                onClick={() =>
                  pushActionEvent({
                    kind: "PROPOSE",
                    title: "Proposed: retirement quote",
                    detail: "Next: /api/bridge/quote (operator-approved execution only).",
                    costNote: "No irreversible action without explicit approval.",
                  })
                }
              >
                Propose
              </Button>
            </div>
          </CardBody>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <div className="space-y-4">
          <Card>
            <CardBody>
              <div className="font-semibold">Quick links</div>
              <div className="mt-3 flex flex-wrap gap-2">
                <Link className="no-underline" href="/proof">
                  <Button variant="secondary">Proof</Button>
                </Link>
                <Link className="no-underline" href="/identity">
                  <Button variant="secondary">Identity</Button>
                </Link>
              </div>
              <p className="mt-3 text-sm text-neutral-400">
                Tip: Use Proof as the “receipt layer” for anything that gets approved/executed.
              </p>
            </CardBody>
          </Card>

          <Card>
            <CardBody>
              <div className="font-semibold">How to use</div>
              <ol className="mt-3 text-sm text-neutral-300 space-y-2 list-decimal list-inside">
                <li>Refresh to see current policy + surfaces.</li>
                <li>Use Propose to generate a plan (no spend).</li>
                <li>Operator approves execution in the Retire / Paper flows.</li>
                <li>Publish proof objects after execution.</li>
              </ol>
            </CardBody>
          </Card>
        </div>

        <ActionFeed />
      </div>
    </div>
  );
}
