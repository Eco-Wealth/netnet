"use client";

import React from "react";

export function Tooltip({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <span className="relative inline-flex items-center group">
      {children}
      <span
        className={[
          "pointer-events-none absolute left-1/2 -translate-x-1/2 top-full mt-2",
          "whitespace-nowrap rounded-xl border border-neutral-800 bg-neutral-950/95",
          "px-3 py-2 text-xs text-neutral-200 shadow-lg",
          "opacity-0 translate-y-1 transition",
          "group-hover:opacity-100 group-hover:translate-y-0",
        ].join(" ")}
        role="tooltip"
      >
        {label}
      </span>
    </span>
  );
}
