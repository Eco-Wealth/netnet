"use client";

import React from "react";
import { ActionEvent, clearActionLog, loadActionLog } from "@/lib/actionLog";

function fmt(ts: string) {
  try {
    return new Date(ts).toLocaleString();
  } catch {
    return ts;
  }
}

export function ActionFeed() {
  const [items, setItems] = React.useState<ActionEvent[]>([]);

  React.useEffect(() => {
    setItems(loadActionLog());
    const onStorage = () => setItems(loadActionLog());
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, []);

  function onClear() {
    clearActionLog();
    setItems([]);
  }

  if (items.length === 0) {
    return (
      <div className="rounded-2xl border border-neutral-900 bg-neutral-950 p-4 text-sm text-neutral-300">
        No actions yet.
      </div>
    );
  }

  return (
    <div className="rounded-2xl border border-neutral-900 bg-neutral-950 p-4">
      <div className="flex items-center justify-between mb-3">
        <div className="text-sm font-semibold">Action feed</div>
        <button
          onClick={onClear}
          className="text-xs text-neutral-400 hover:text-neutral-200"
        >
          Clear
        </button>
      </div>

      <div className="space-y-3">
        {items.map((it) => (
          <div key={it.id} className="rounded-xl border border-neutral-900 bg-neutral-950/40 p-3">
            <div className="flex items-center justify-between gap-3">
              <div className="text-sm font-medium">{it.title}</div>
              <div className="text-xs text-neutral-500">{fmt(it.ts)}</div>
            </div>
            <div className="mt-1 text-xs text-neutral-400">{it.kind}</div>
            {it.detail ? <div className="mt-2 text-sm text-neutral-200">{it.detail}</div> : null}
            {it.costNote ? <div className="mt-2 text-xs text-neutral-400">{it.costNote}</div> : null}
          </div>
        ))}
      </div>
    </div>
  );
}
