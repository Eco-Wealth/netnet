import { NextResponse } from "next/server";
import fs from "node:fs/promises";
import path from "node:path";

export const runtime = "nodejs";

// Reads the skills manifest from repo root: ../../skills/manifest.json (relative to netnet/cockpit)
async function readManifest(): Promise<any> {
  const cwd = process.cwd(); // netnet/cockpit
  const candidates = [
    path.join(cwd, "..", "..", "skills", "manifest.json"), // repo root skills
    path.join(cwd, "skills", "manifest.json"), // fallback if colocated
  ];

  let lastErr: unknown = null;
  for (const p of candidates) {
    try {
      const raw = await fs.readFile(p, "utf-8");
      return JSON.parse(raw);
    } catch (err) {
      lastErr = err;
    }
  }
  throw lastErr ?? new Error("manifest not found");
}

export async function GET() {
  try {
    const manifest = await readManifest();
    return NextResponse.json({ ok: true, manifest });
  } catch (err: any) {
    return NextResponse.json(
      {
        ok: false,
        error: {
          code: "SKILLS_MANIFEST_NOT_FOUND",
          message:
            "Could not read skills manifest. Expected ../../skills/manifest.json relative to netnet/cockpit.",
          details: String(err?.message ?? err),
        },
      },
      { status: 404 }
    );
  }
}
