"use client";

import { useEffect, useMemo, useState } from "react";
import { SkillCard } from "@/components/SkillCard";
import { fetchSkillsManifest, SkillManifestEntry } from "@/lib/skills/manifest";

type ViewState =
  | { kind: "loading" }
  | { kind: "error"; message: string }
  | { kind: "ready"; skills: SkillManifestEntry[]; updatedAt?: string };

function norm(s: string) {
  return (s ?? "").toLowerCase().trim();
}

export default function SkillsPage() {
  const [state, setState] = useState<ViewState>({ kind: "loading" });
  const [q, setQ] = useState("");
  const [safety, setSafety] = useState<string>("");

  useEffect(() => {
    let mounted = true;
    fetchSkillsManifest()
      .then((m) => {
        if (!mounted) return;
        setState({
          kind: "ready",
          skills: Array.isArray(m.skills) ? m.skills : [],
          updatedAt: m.updatedAt,
        });
      })
      .catch((e) => {
        if (!mounted) return;
        setState({ kind: "error", message: e?.message ?? String(e) });
      });
    return () => {
      mounted = false;
    };
  }, []);

  const filtered = useMemo(() => {
    if (state.kind !== "ready") return [];
    const query = norm(q);
    return state.skills
      .filter((s) => {
        if (safety && s.safety !== safety) return false;
        if (!query) return true;
        const hay = [
          s.id,
          s.name,
          s.description ?? "",
          ...(s.tags ?? []),
          ...(s.endpoints ?? []),
        ]
          .map((x) => norm(String(x)))
          .join(" ");
        return hay.includes(query);
      })
      .sort((a, b) => (a.name ?? "").localeCompare(b.name ?? ""));
  }, [state, q, safety]);

  async function copy(text: string) {
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      // ignore
    }
  }

  return (
    <div className="mx-auto w-full max-w-3xl px-4 py-5">
      <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h1 className="text-lg font-semibold text-white">Skills</h1>
            <p className="mt-1 text-sm text-neutral-300">
              This view is powered by <span className="font-mono">skills/manifest.json</span>.
              Keep it updated as you add skills.
            </p>
            {state.kind === "ready" && state.updatedAt ? (
              <p className="mt-1 text-xs text-neutral-400">
                Updated: {state.updatedAt}
              </p>
            ) : null}
          </div>
          <a
            href="/api/skills/manifest"
            className="rounded-xl border border-white/10 bg-neutral-950/40 px-3 py-2 text-xs text-white hover:bg-neutral-950/60"
          >
            Open manifest JSON
          </a>
        </div>

        <div className="mt-4 grid grid-cols-1 gap-2 sm:grid-cols-3">
          <input
            className="col-span-1 sm:col-span-2 rounded-xl border border-white/10 bg-neutral-950/40 px-3 py-2 text-sm text-white placeholder:text-neutral-500 outline-none focus:border-white/20"
            placeholder="Search skills, tags, endpoints…"
            value={q}
            onChange={(e) => setQ(e.target.value)}
          />
          <select
            className="rounded-xl border border-white/10 bg-neutral-950/40 px-3 py-2 text-sm text-white outline-none focus:border-white/20"
            value={safety}
            onChange={(e) => setSafety(e.target.value)}
          >
            <option value="">All safety</option>
            <option value="read_only">read_only</option>
            <option value="propose_only">propose_only</option>
            <option value="execute_with_limits">execute_with_limits</option>
          </select>
        </div>
      </div>

      <div className="mt-4 space-y-3">
        {state.kind === "loading" ? (
          <div className="rounded-2xl border border-white/10 bg-white/5 p-4 text-sm text-neutral-300">
            Loading manifest…
          </div>
        ) : null}

        {state.kind === "error" ? (
          <div className="rounded-2xl border border-red-500/30 bg-red-500/10 p-4 text-sm text-red-200">
            {state.message}
          </div>
        ) : null}

        {state.kind === "ready" ? (
          filtered.length ? (
            filtered.map((s) => (
              <SkillCard key={s.id} skill={s} onCopyCurl={copy} />
            ))
          ) : (
            <div className="rounded-2xl border border-white/10 bg-white/5 p-4 text-sm text-neutral-300">
              No skills match your filters.
            </div>
          )
        ) : null}
      </div>
    </div>
  );
}
