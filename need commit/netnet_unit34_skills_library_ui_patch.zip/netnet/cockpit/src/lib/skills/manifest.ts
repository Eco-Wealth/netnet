export type SkillSafety = "read_only" | "propose_only" | "execute_with_limits";

export type SkillManifestEntry = {
  id: string;
  name: string;
  version?: string;
  description?: string;
  safety?: SkillSafety;
  endpoints?: string[];
  requiredEnv?: string[];
  docs?: string[];
  examples?: { title: string; curl: string }[];
  tags?: string[];
};

export type SkillsManifest = {
  schema?: string;
  updatedAt?: string;
  skills: SkillManifestEntry[];
};

export async function fetchSkillsManifest(): Promise<SkillsManifest> {
  const res = await fetch("/api/skills/manifest", { cache: "no-store" });
  const data = await res.json();
  if (!res.ok || !data?.ok) {
    const msg =
      data?.error?.message ??
      `Failed to load skills manifest (status ${res.status})`;
    throw new Error(msg);
  }
  return data.manifest as SkillsManifest;
}
