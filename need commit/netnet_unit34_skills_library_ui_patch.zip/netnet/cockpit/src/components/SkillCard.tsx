"use client";

import { SkillManifestEntry } from "@/lib/skills/manifest";
import { Tooltip } from "@/components/Tooltip";

function Pill({ children }: { children: React.ReactNode }) {
  return (
    <span className="rounded-full border border-white/10 bg-white/5 px-2 py-0.5 text-[11px] text-neutral-200">
      {children}
    </span>
  );
}

function SafetyPill({ safety }: { safety?: string }) {
  const label = safety ?? "unspecified";
  const help =
    label === "read_only"
      ? "No side effects. Safe to run unattended."
      : label === "propose_only"
      ? "Generates plans/instructions. Requires operator approval to execute."
      : label === "execute_with_limits"
      ? "May execute under strict caps/allowlists + explicit approvals."
      : "Not classified yet.";

  return (
    <Tooltip label={help}>
      <span className="cursor-help">
        <Pill>{label}</Pill>
      </span>
    </Tooltip>
  );
}

export function SkillCard({
  skill,
  onCopyCurl,
}: {
  skill: SkillManifestEntry;
  onCopyCurl?: (curl: string) => void;
}) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 p-4 shadow-sm">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <h3 className="text-base font-semibold text-white">
              {skill.name}
            </h3>
            <SafetyPill safety={skill.safety} />
            {skill.version ? <Pill>v{skill.version}</Pill> : null}
          </div>
          {skill.description ? (
            <p className="mt-1 text-sm text-neutral-300">
              {skill.description}
            </p>
          ) : null}
          <div className="mt-2 flex flex-wrap gap-2">
            {skill.tags?.slice(0, 6)?.map((t) => (
              <Pill key={t}>{t}</Pill>
            ))}
          </div>
        </div>
        <div className="text-right text-xs text-neutral-400">
          <div className="font-mono">{skill.id}</div>
        </div>
      </div>

      {skill.endpoints?.length ? (
        <div className="mt-3">
          <div className="text-xs font-semibold text-neutral-300">
            Endpoints
          </div>
          <div className="mt-1 flex flex-wrap gap-2">
            {skill.endpoints.map((e) => (
              <span
                key={e}
                className="rounded-lg border border-white/10 bg-neutral-950/40 px-2 py-1 text-xs font-mono text-neutral-200"
              >
                {e}
              </span>
            ))}
          </div>
        </div>
      ) : null}

      {skill.requiredEnv?.length ? (
        <div className="mt-3">
          <div className="text-xs font-semibold text-neutral-300">
            Required env
          </div>
          <div className="mt-1 flex flex-wrap gap-2">
            {skill.requiredEnv.map((k) => (
              <span
                key={k}
                className="rounded-lg border border-white/10 bg-neutral-950/40 px-2 py-1 text-xs font-mono text-neutral-200"
              >
                {k}
              </span>
            ))}
          </div>
        </div>
      ) : null}

      {skill.examples?.length ? (
        <div className="mt-3">
          <div className="text-xs font-semibold text-neutral-300">
            Examples
          </div>
          <div className="mt-2 space-y-2">
            {skill.examples.slice(0, 2).map((ex) => (
              <div
                key={ex.title}
                className="rounded-xl border border-white/10 bg-neutral-950/40 p-3"
              >
                <div className="flex items-center justify-between gap-2">
                  <div className="text-xs font-semibold text-neutral-200">
                    {ex.title}
                  </div>
                  {onCopyCurl ? (
                    <button
                      className="rounded-lg border border-white/10 bg-white/5 px-2 py-1 text-xs text-white hover:bg-white/10"
                      onClick={() => onCopyCurl(ex.curl)}
                    >
                      Copy curl
                    </button>
                  ) : null}
                </div>
                <pre className="mt-2 overflow-auto whitespace-pre-wrap break-words text-xs text-neutral-200">
{ex.curl}
                </pre>
              </div>
            ))}
          </div>
        </div>
      ) : null}
    </div>
  );
}
