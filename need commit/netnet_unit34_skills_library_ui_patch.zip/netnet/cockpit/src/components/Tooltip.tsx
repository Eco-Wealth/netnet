"use client";

import { ReactNode, useState } from "react";

export function Tooltip({
  label,
  children,
  align = "center",
}: {
  label: ReactNode;
  children: ReactNode;
  align?: "left" | "center" | "right";
}) {
  const [open, setOpen] = useState(false);

  const alignClass =
    align === "left"
      ? "left-0"
      : align === "right"
      ? "right-0"
      : "left-1/2 -translate-x-1/2";

  return (
    <span
      className="relative inline-flex"
      onMouseEnter={() => setOpen(true)}
      onMouseLeave={() => setOpen(false)}
      onFocus={() => setOpen(true)}
      onBlur={() => setOpen(false)}
    >
      {children}
      {open ? (
        <span
          className={`absolute z-50 ${alignClass} top-full mt-2 w-max max-w-[280px] rounded-xl border border-white/10 bg-neutral-950/95 px-3 py-2 text-xs text-neutral-200 shadow-lg`}
          role="tooltip"
        >
          {label}
        </span>
      ) : null}
    </span>
  );
}
