"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

type NavItem = { href: string; label: string };

const NAV: NavItem[] = [
  { href: "/proof", label: "Proof" },
  { href: "/retire", label: "Retire" },
  { href: "/execute", label: "Execute" },
  { href: "/skills", label: "Skills" },
  { href: "/identity", label: "Identity" },
];

function isActive(pathname: string, href: string) {
  if (href === "/") return pathname === "/";
  return pathname === href || pathname.startsWith(href + "/");
}

export default function Shell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();

  return (
    <div className="min-h-dvh bg-neutral-950 text-white">
      <div className="mx-auto w-full max-w-5xl px-4 py-4">
        <div className="flex items-center justify-between gap-4">
          <div className="text-sm font-semibold tracking-wide">
            netnet-cockpit
          </div>

          {/* Desktop nav */}
          <nav className="hidden items-center gap-1 sm:flex">
            {NAV.map((item) => {
              const active = isActive(pathname, item.href);
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={[
                    "rounded-xl border px-3 py-2 text-sm",
                    active
                      ? "border-white/20 bg-white/10"
                      : "border-white/10 bg-white/5 hover:bg-white/10",
                  ].join(" ")}
                >
                  {item.label}
                </Link>
              );
            })}
          </nav>
        </div>

        <main className="mt-4">{children}</main>
      </div>

      {/* Mobile bottom nav */}
      <nav className="fixed bottom-0 left-0 right-0 border-t border-white/10 bg-neutral-950/95 backdrop-blur sm:hidden">
        <div className="mx-auto flex max-w-3xl items-center justify-around px-2 py-2">
          {NAV.slice(0, 4).map((item) => {
            const active = isActive(pathname, item.href);
            return (
              <Link
                key={item.href}
                href={item.href}
                className={[
                  "rounded-xl px-3 py-2 text-xs",
                  active ? "bg-white/10 text-white" : "text-neutral-300",
                ].join(" ")}
              >
                {item.label}
              </Link>
            );
          })}
        </div>
      </nav>

      <div className="h-16 sm:hidden" />
    </div>
  );
}
