# Unit 34 — Skills Library UI

Adds a Skills page that reads a versioned manifest and presents:
- skill name/id/version
- safety class
- endpoints + required env
- copyable curl examples

## Manifest source of truth
Expected file location (repo root):
- `skills/manifest.json`

The cockpit reads it via:
- `GET /api/skills/manifest`

## Add a new skill
1) Add/modify skill docs in `/skills/*.md`
2) Update `skills/manifest.json` with new entry
3) Verify in UI: `/skills`
