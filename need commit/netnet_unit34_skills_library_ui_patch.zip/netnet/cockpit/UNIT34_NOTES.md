Unit 34 adds /skills page and an API route to load skills manifest.

If your navigation is defined in `netnet/cockpit/src/components/Shell.tsx`,
add a nav item to point to `/skills` labeled "Skills".

This unit does NOT auto-edit Shell.tsx to avoid overwriting custom nav changes.
