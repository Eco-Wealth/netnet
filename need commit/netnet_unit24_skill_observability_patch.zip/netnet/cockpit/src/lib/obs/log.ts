type Level = "debug" | "info" | "warn" | "error";

export type SkillLog = {
  level: Level;
  ts: string;
  requestId: string;
  skill?: string;
  action?: string;
  route?: string;
  msg: string;
  data?: Record<string, unknown>;
};

function nowIso() {
  return new Date().toISOString();
}

export function skillLog(entry: Omit<SkillLog, "ts">) {
  const payload: SkillLog = { ts: nowIso(), ...entry };

  // JSON logs: good for VPS + Docker + Vercel logs
  // Never log secrets; callers should scrub inputs.
  // eslint-disable-next-line no-console
  console.log(JSON.stringify(payload));
}

export function safeError(err: unknown): { name?: string; message: string } {
  if (err instanceof Error) return { name: err.name, message: err.message };
  try {
    return { message: JSON.stringify(err) };
  } catch {
    return { message: String(err) };
  }
}
