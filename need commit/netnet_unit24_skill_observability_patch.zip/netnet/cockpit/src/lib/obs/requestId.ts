export function getRequestId(headers: Headers): string {
  // Accept upstream IDs if present; otherwise generate a short deterministic-ish id.
  const existing =
    headers.get("x-request-id") ||
    headers.get("x-correlation-id") ||
    headers.get("cf-ray") ||
    headers.get("x-vercel-id");

  if (existing && existing.trim().length > 0) return existing.trim();

  // 16 chars base36-ish
  const rnd = Math.random().toString(36).slice(2, 10);
  const ts = Date.now().toString(36).slice(-6);
  return `${ts}-${rnd}`;
}
