import { NextResponse } from "next/server";
import { getRequestId } from "./requestId";
import { skillLog, safeError } from "./log";

export type ObsContext = {
  requestId: string;
  route: string;
  skill?: string;
  action?: string;
};

export function withObs(
  route: string,
  handler: (req: Request, ctx: ObsContext) => Promise<Response>
) {
  return async (req: Request) => {
    const requestId = getRequestId(req.headers);
    const ctx: ObsContext = { requestId, route };

    const started = Date.now();
    skillLog({ level: "info", requestId, route, msg: "request.start" });

    try {
      const res = await handler(req, ctx);

      // Attach requestId header for tracing from curl/agent
      const out = NextResponse.clone(res);
      out.headers.set("x-request-id", requestId);

      skillLog({
        level: "info",
        requestId,
        route,
        msg: "request.end",
        data: { ms: Date.now() - started, status: out.status },
      });

      return out;
    } catch (err) {
      const e = safeError(err);
      skillLog({
        level: "error",
        requestId,
        route,
        msg: "request.error",
        data: { ms: Date.now() - started, error: e },
      });

      const body = {
        ok: false,
        error: { code: "INTERNAL_ERROR", message: "Internal server error" },
        requestId,
      };

      const out = NextResponse.json(body, { status: 500 });
      out.headers.set("x-request-id", requestId);
      return out;
    }
  };
}
