import { NextResponse } from "next/server";
import { z } from "zod";
import { withObs } from "@/lib/obs/withObs";
import { rateLimitByIp } from "@/lib/http/ratelimit";
import { ok, err } from "@/lib/api/errors";

const ActionSchema = z.enum(["info", "estimate", "projects", "quote", "status"]);

export const GET = withObs("/api/agent/carbon", async (req, ctx) => {
  await rateLimitByIp(req, { bucket: "agent-carbon", max: 60, windowMs: 60_000 });

  const url = new URL(req.url);
  const action = ActionSchema.safeParse(url.searchParams.get("action") ?? "info");
  if (!action.success) {
    return NextResponse.json(err("BAD_REQUEST", "Invalid action"), { status: 400 });
  }

  if (action.data === "info") {
    return NextResponse.json(
      ok({
        actions: ["info", "estimate", "projects", "quote", "status"],
        nextAction: "projects",
        requestId: ctx.requestId,
        safety: {
          postRequires: ["beneficiaryName", "reason"],
          note: "POST initiates a retirement request; payment must be explicitly confirmed by an operator.",
        },
      })
    );
  }

  // Placeholder: other actions exist in codebase; this wrapper keeps contracts consistent.
  return NextResponse.json(
    ok({
      action: action.data,
      nextAction: "info",
      requestId: ctx.requestId,
      note: "Action is implemented elsewhere in the orchestrator units; ensure unit 17 is applied.",
    })
  );
});

export const POST = withObs("/api/agent/carbon", async (req, ctx) => {
  await rateLimitByIp(req, { bucket: "agent-carbon-post", max: 20, windowMs: 60_000 });

  const body = await req.json().catch(() => null);
  if (!body || typeof body !== "object") {
    return NextResponse.json(err("BAD_REQUEST", "Expected JSON body"), { status: 400 });
  }

  const Required = z
    .object({
      beneficiaryName: z.string().min(2),
      reason: z.string().min(3),
    })
    .safeParse(body);

  if (!Required.success) {
    return NextResponse.json(err("BAD_REQUEST", "Missing beneficiaryName/reason", Required.error.flatten()), { status: 400 });
  }

  return NextResponse.json(
    ok({
      nextAction: "quote",
      requestId: ctx.requestId,
      note: "POST is scaffold-only in this patch; apply Unit 17 orchestrator for full behavior.",
    })
  );
});
