import { NextResponse } from "next/server";
import { z } from "zod";
import { withObs } from "@/lib/obs/withObs";
import { rateLimitByIp } from "@/lib/http/ratelimit";
import { ok, err } from "@/lib/api/errors";

const ActionSchema = z.enum(["info", "quote"]);

function envBool(name: string, fallback = false) {
  const v = process.env[name];
  if (!v) return fallback;
  return v === "1" || v.toLowerCase() === "true";
}

export const GET = withObs("/api/agent/trade", async (req, ctx) => {
  await rateLimitByIp(req, { bucket: "agent-trade", max: 60, windowMs: 60_000 });

  const url = new URL(req.url);
  const action = ActionSchema.safeParse(url.searchParams.get("action") ?? "info");
  if (!action.success) return NextResponse.json(err("BAD_REQUEST", "Invalid action"), { status: 400 });

  const enabled = envBool("TRADE_ENABLED", false);
  const maxUsd = Number(process.env.TRADE_MAX_USD ?? "25");
  const allowlistTokens = (process.env.TRADE_ALLOWLIST_TOKENS ?? "USDC,ETH")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);

  if (action.data === "info") {
    return NextResponse.json(
      ok({
        trade: { enabled, maxUsd, allowlistTokens, defaultMode: "DRY_RUN" },
        requestId: ctx.requestId,
        nextAction: "Use action=quote to simulate a quote; POST to get an executionPlan (DRY_RUN).",
      })
    );
  }

  return NextResponse.json(
    ok({
      action: "quote",
      requestId: ctx.requestId,
      note: "Quote simulation is implemented in Unit 9; ensure that patch is applied.",
    })
  );
});

export const POST = withObs("/api/agent/trade", async (req, ctx) => {
  await rateLimitByIp(req, { bucket: "agent-trade-post", max: 20, windowMs: 60_000 });
  const body = await req.json().catch(() => null);
  if (!body || typeof body !== "object") return NextResponse.json(err("BAD_REQUEST", "Expected JSON body"), { status: 400 });

  return NextResponse.json(
    ok({
      mode: "DRY_RUN",
      requestId: ctx.requestId,
      note: "Execution plan generation is implemented in Unit 9; ensure that patch is applied.",
    })
  );
});
