import { NextResponse } from "next/server";
import { withObs } from "@/lib/obs/withObs";

export const GET = withObs("/api/health", async () => {
  return NextResponse.json({ ok: true, service: "netnet-cockpit" });
});
