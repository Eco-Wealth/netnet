import { NextResponse } from "next/server";
import { withObs } from "@/lib/obs/withObs";

// NOTE: We intentionally implement a safe, testable 402 gate here without relying
// on any framework-specific runtime assumptions that may crash in dev.
// If you later wire full @x402 middleware, keep this route as the semantic contract.

function envBool(name: string, fallback = false) {
  const v = process.env[name];
  if (!v) return fallback;
  return v === "1" || v.toLowerCase() === "true";
}

export const GET = withObs("/api/proof-paid", async () => {
  const bypass = envBool("X402_DEV_BYPASS", false);

  // In dev, allow explicit bypass for local iteration only.
  if (bypass) {
    return NextResponse.json({ ok: true, paid: true, bypass: true });
  }

  const payTo = process.env.X402_PAY_TO ?? "";
  const network = process.env.X402_NETWORK ?? "";

  const res = NextResponse.json(
    { ok: false, paid: false, error: { code: "PAYMENT_REQUIRED", message: "x402 payment required" } },
    { status: 402 }
  );

  // Challenge headers (empty values are acceptable for local testing, but populate in prod)
  res.headers.set("x402-pay-to", payTo);
  res.headers.set("x402-network", network);
  return res;
});
