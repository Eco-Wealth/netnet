# Observability (Skill-Level)

Goals:
- Every API response includes `x-request-id`
- Every API request emits structured JSON logs with that same id
- Agents can attach request ids to proof objects / audits

What you get:
- `x-request-id` header on **all** wrapped routes
- Logs in JSON (one line per event) suitable for Docker/Vercel log drains

Log shape:
```json
{
  "level": "info",
  "ts": "2026-02-08T00:00:00.000Z",
  "requestId": "k3l9ab-9q1w2e3r",
  "route": "/api/agent/carbon",
  "msg": "request.end",
  "data": { "ms": 42, "status": 200 }
}
```

Usage in routes:
- Prefer wrapping handlers with `withObs("/api/...", async (req, ctx) => { ... })`
- Never log secrets (API keys, auth headers, private keys).
