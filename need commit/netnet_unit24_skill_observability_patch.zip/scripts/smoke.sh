#!/usr/bin/env bash
set -euo pipefail

BASE_URL="${BASE_URL:-http://localhost:3000}"

echo "== health =="
curl -isS "$BASE_URL/api/health" | sed -n '1,20p'
echo

echo "== proof-paid (expects 402 unless bypass) =="
curl -isS "$BASE_URL/api/proof-paid" | sed -n '1,40p'
echo

echo "== agent/carbon info =="
curl -isS "$BASE_URL/api/agent/carbon?action=info" | sed -n '1,40p'
echo

echo "== agent/trade info =="
curl -isS "$BASE_URL/api/agent/trade?action=info" | sed -n '1,40p'
echo

echo "Done."
