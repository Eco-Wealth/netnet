#!/usr/bin/env bash
set -euo pipefail

BASE_URL="${BASE_URL:-http://localhost:3000}"

echo "[trade] info"
curl -fsS "$BASE_URL/api/agent/trade?action=info" >/dev/null

echo "[trade] quote (simulated)"
curl -fsS "$BASE_URL/api/agent/trade?action=quote&side=BUY&baseToken=ETH&quoteToken=USDC&amountUsd=5" >/dev/null

echo "[trade] plan (dry run)"
curl -fsS -X POST "$BASE_URL/api/agent/trade"     -H "content-type: application/json"     -d '{"side":"BUY","baseToken":"ETH","quoteToken":"USDC","amountUsd":5,"beneficiaryName":"EcoWealth Ops","reason":"smoke test","mode":"DRY_RUN"}' >/dev/null

echo "[trade] ok"
