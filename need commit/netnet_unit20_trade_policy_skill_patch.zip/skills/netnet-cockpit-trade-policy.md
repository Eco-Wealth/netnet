# netnet-cockpit trade policy skill (v1)

Purpose: ensure every trade attempt is gated by explicit policy checks.

## Endpoints

- `GET /api/agent/trade?action=info`
- `GET /api/agent/trade?action=quote&side=&baseToken=&quoteToken=&amountUsd=`
- `POST /api/agent/trade` (returns an `executionPlan`, never broadcasts)

## Guardrails

- `TRADE_ENABLED` defaults to `false`
- `TRADE_MAX_USD` defaults to `25`
- `TRADE_ALLOWLIST_TOKENS` defaults to `USDC,ETH`
- POST requires `beneficiaryName` + `reason`

## Agent rule

Never request LIVE mode unless an operator explicitly approves and the environment is configured.
