import { z } from "zod";

export type TradePolicy = {
  enabled: boolean;
  maxUsd: number;
  allowlistTokens: string[];
  defaultMode: "DRY_RUN" | "LIVE";
};

export type TradeIntent = {
  side: "BUY" | "SELL";
  baseToken: string;     // e.g. ETH
  quoteToken: string;    // e.g. USDC
  amountUsd: number;     // always expressed in USD for cap checks
  venue?: string;        // e.g. GMX (placeholder)
  reason?: string;       // required for execution paths
  beneficiaryName?: string; // required for execution paths
  mode?: "DRY_RUN" | "LIVE";
};

export const tradeIntentSchema = z.object({
  side: z.enum(["BUY", "SELL"]),
  baseToken: z.string().min(1),
  quoteToken: z.string().min(1),
  amountUsd: z.number().finite().positive(),
  venue: z.string().optional(),
  reason: z.string().min(3).optional(),
  beneficiaryName: z.string().min(2).optional(),
  mode: z.enum(["DRY_RUN", "LIVE"]).optional(),
});

export type TradeGateResult =
  | { ok: true; policy: TradePolicy; intent: Required<Pick<TradeIntent, "mode">> & TradeIntent }
  | { ok: false; code: "TRADE_DISABLED" | "AMOUNT_TOO_LARGE" | "TOKEN_NOT_ALLOWED" | "MISSING_APPROVAL_FIELDS"; message: string; details?: any; policy: TradePolicy };

export function getTradePolicyFromEnv(): TradePolicy {
  const enabled = (process.env.TRADE_ENABLED ?? "false").toLowerCase() === "true";
  const maxUsd = Number(process.env.TRADE_MAX_USD ?? "25");
  const allowlistTokens = (process.env.TRADE_ALLOWLIST_TOKENS ?? "USDC,ETH")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);

  const defaultMode: TradePolicy["defaultMode"] = "DRY_RUN";
  return {
    enabled,
    maxUsd: Number.isFinite(maxUsd) && maxUsd > 0 ? maxUsd : 25,
    allowlistTokens: allowlistTokens.length ? allowlistTokens : ["USDC", "ETH"],
    defaultMode,
  };
}

function isAllowedToken(policy: TradePolicy, token: string) {
  return policy.allowlistTokens.map((t) => t.toUpperCase()).includes(token.toUpperCase());
}

/**
 * Gatekeeper for ANY trade-related route (quote/plan/execute).
 * - DRY_RUN always allowed (even when TRADE_ENABLED=false), but still enforces caps + allowlist.
 * - LIVE mode is blocked unless TRADE_ENABLED=true.
 * - For execution-like flows, require beneficiaryName + reason.
 */
export function gateTradeIntent(input: TradeIntent, opts?: { requireApprovalFields?: boolean }): TradeGateResult {
  const policy = getTradePolicyFromEnv();
  const mode = (input.mode ?? policy.defaultMode) as "DRY_RUN" | "LIVE";
  const intent = { ...input, mode };

  if (!isAllowedToken(policy, intent.baseToken) || !isAllowedToken(policy, intent.quoteToken)) {
    return {
      ok: false,
      code: "TOKEN_NOT_ALLOWED",
      message: "Token not allowed by TRADE_ALLOWLIST_TOKENS.",
      details: { baseToken: intent.baseToken, quoteToken: intent.quoteToken, allowlist: policy.allowlistTokens },
      policy,
    };
  }

  if (intent.amountUsd > policy.maxUsd) {
    return {
      ok: false,
      code: "AMOUNT_TOO_LARGE",
      message: "Trade amount exceeds TRADE_MAX_USD cap.",
      details: { amountUsd: intent.amountUsd, maxUsd: policy.maxUsd },
      policy,
    };
  }

  if (intent.mode === "LIVE" && !policy.enabled) {
    return {
      ok: false,
      code: "TRADE_DISABLED",
      message: "Trading is disabled (TRADE_ENABLED=false).",
      details: { mode: intent.mode },
      policy,
    };
  }

  if (opts?.requireApprovalFields) {
    if (!intent.beneficiaryName || !intent.reason) {
      return {
        ok: false,
        code: "MISSING_APPROVAL_FIELDS",
        message: "Missing required fields for execution: beneficiaryName + reason.",
        details: { beneficiaryName: intent.beneficiaryName, reason: intent.reason },
        policy,
      };
    }
  }

  return { ok: true, policy, intent };
}

export function buildExecutionPlan(intent: TradeIntent) {
  // This is intentionally non-broadcasting scaffolding.
  return {
    kind: "trade_attempt",
    mode: intent.mode ?? "DRY_RUN",
    venue: intent.venue ?? "GMX",
    pair: `${intent.baseToken}/${intent.quoteToken}`,
    side: intent.side,
    amountUsd: intent.amountUsd,
    safety: {
      note: "This plan does not broadcast transactions. Execution must be explicitly approved and implemented later.",
    },
    steps: [
      { step: 1, action: "Validate policy + caps + allowlist" },
      { step: 2, action: "Fetch venue quote (simulated for now)" },
      { step: 3, action: "Prepare execution calldata (not implemented)" },
      { step: 4, action: "Operator approval required before any broadcast" },
    ],
  };
}
