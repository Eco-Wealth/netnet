import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { gateTradeIntent, tradeIntentSchema, getTradePolicyFromEnv, buildExecutionPlan } from "@/lib/trade/policy";

const actionSchema = z.enum(["info", "quote"]);
const querySchema = z.object({
  action: actionSchema.optional(),
  side: z.enum(["BUY", "SELL"]).optional(),
  baseToken: z.string().optional(),
  quoteToken: z.string().optional(),
  amountUsd: z.coerce.number().optional(),
});

function json(data: any, status = 200) {
  return NextResponse.json(data, { status });
}

export async function GET(req: NextRequest) {
  const url = new URL(req.url);
  const parsed = querySchema.safeParse(Object.fromEntries(url.searchParams.entries()));
  if (!parsed.success) {
    return json({ ok: false, error: { code: "BAD_REQUEST", message: "Invalid query params", details: parsed.error.flatten() } }, 400);
  }

  const action = parsed.data.action ?? "info";
  const policy = getTradePolicyFromEnv();

  if (action === "info") {
    return json({
      ok: true,
      trade: {
        enabled: policy.enabled,
        maxUsd: policy.maxUsd,
        allowlistTokens: policy.allowlistTokens,
        defaultMode: policy.defaultMode,
      },
      nextAction: "Use action=quote to simulate a quote; POST to get an executionPlan (DRY_RUN by default).",
    });
  }

  // quote
  const { side, baseToken, quoteToken, amountUsd } = parsed.data;
  const intent = {
    side: side ?? "BUY",
    baseToken: baseToken ?? "ETH",
    quoteToken: quoteToken ?? "USDC",
    amountUsd: amountUsd ?? 5,
    mode: "DRY_RUN" as const,
  };

  const gate = gateTradeIntent(intent);
  if (!gate.ok) {
    return json({ ok: false, error: { code: gate.code, message: gate.message, details: gate.details }, policy: gate.policy }, 400);
  }

  // simulated quote
  const quote = {
    ok: true,
    simulated: true,
    pair: `${gate.intent.baseToken}/${gate.intent.quoteToken}`,
    side: gate.intent.side,
    amountUsd: gate.intent.amountUsd,
    estPrice: 2000, // placeholder
    estFeesUsd: Math.max(0.01, gate.intent.amountUsd * 0.002),
    warning: "Simulated quote only. No venue execution implemented.",
  };

  return json({ ok: true, quote, nextAction: "POST /api/agent/trade to get a DRY_RUN executionPlan." });
}

const postSchema = z.object({
  side: z.enum(["BUY", "SELL"]),
  baseToken: z.string().min(1),
  quoteToken: z.string().min(1),
  amountUsd: z.number().finite().positive(),
  venue: z.string().optional(),
  // Safety: require these for POST (represents an execution attempt, even in DRY_RUN)
  beneficiaryName: z.string().min(2),
  reason: z.string().min(3),
  mode: z.enum(["DRY_RUN", "LIVE"]).optional(),
});

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null);
  const parsed = postSchema.safeParse(body);
  if (!parsed.success) {
    return json({ ok: false, error: { code: "BAD_REQUEST", message: "Invalid JSON body", details: parsed.error.flatten() } }, 400);
  }

  const gate = gateTradeIntent(parsed.data, { requireApprovalFields: true });
  if (!gate.ok) {
    return json({ ok: false, error: { code: gate.code, message: gate.message, details: gate.details }, policy: gate.policy }, 400);
  }

  const executionPlan = buildExecutionPlan(gate.intent);

  return json({
    ok: true,
    mode: gate.intent.mode,
    executionPlan,
    nextAction: gate.intent.mode === "DRY_RUN" ? "Review plan; no broadcast will occur." : "Trading enabled, but broadcast not implemented. Keep DRY_RUN until connector exists.",
  });
}
