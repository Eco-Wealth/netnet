# Trade policy (Unit 20)

Trading is **safe-by-default** and **non-broadcasting** in v0.4.x.

## Env flags

- `TRADE_ENABLED=false` (default)
- `TRADE_MAX_USD=25` (default cap)
- `TRADE_ALLOWLIST_TOKENS=USDC,ETH` (default)

## What is enforced

- **Allowlist**: both base + quote token must be allowlisted.
- **Cap**: `amountUsd` must be <= `TRADE_MAX_USD`.
- **LIVE mode blocked** unless `TRADE_ENABLED=true`.
- **POST requires** `beneficiaryName` + `reason` (operator accountability).

## Quick checks

- Info:
  `curl -s "http://localhost:3000/api/agent/trade?action=info"`

- Quote (simulated):
  `curl -s "http://localhost:3000/api/agent/trade?action=quote&side=BUY&baseToken=ETH&quoteToken=USDC&amountUsd=5"`

- Plan (DRY_RUN):
  ```bash
  curl -s -X POST "http://localhost:3000/api/agent/trade" \
    -H "content-type: application/json" \
    -d '{"side":"BUY","baseToken":"ETH","quoteToken":"USDC","amountUsd":5,"beneficiaryName":"EcoWealth Ops","reason":"test plan","mode":"DRY_RUN"}'
  ```
