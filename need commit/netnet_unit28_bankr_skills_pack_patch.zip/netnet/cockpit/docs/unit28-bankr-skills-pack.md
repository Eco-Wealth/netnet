# Unit 28 — Bankr Skills Pack (v1)

This unit adds **skill documentation** and an operator-friendly baseline for Bankr planning workflows.

## What’s included
- Skill docs under `/skills/bankr/*` (proposal-only)
- Minimal curl-based acceptance examples

## What’s NOT included
- No private key handling
- No autonomous execution
- No on-chain broadcasting

## Acceptance
From repo root (cockpit running):
```bash
curl -s "http://localhost:3000/api/agent/bankr?action=info"
curl -s -X POST "http://localhost:3000/api/agent/bankr" -H "content-type: application/json" \
  -d '{"action":"propose","reason":"test","chain":"base","intent":"wallet_overview"}'
```
