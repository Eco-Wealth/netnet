# Unit 28 Notes

- Adds Bankr skills documentation under `/skills/bankr`.
- Adds `scripts/bankr_smoke.sh` (curl-based).
- Keeps all actions proposal-only; execution remains operator-controlled.
