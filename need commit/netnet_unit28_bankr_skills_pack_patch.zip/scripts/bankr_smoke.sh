#!/usr/bin/env bash
set -euo pipefail

BASE_URL="${BASE_URL:-http://localhost:3000}"

echo "== bankr: info"
curl -s "${BASE_URL}/api/agent/bankr?action=info" | cat
echo

echo "== bankr: propose wallet_overview"
curl -s -X POST "${BASE_URL}/api/agent/bankr"   -H "content-type: application/json"   -d '{"action":"propose","reason":"smoke","chain":"base","intent":"wallet_overview"}' | cat
echo
