# Skill: Bankr Wallet Operations (proposal-only)

Goal: Let an agent **plan** wallet actions (balance checks, transfer plan, allowance plan) in a way that is safe-by-default and operator-approved.

## Inputs
- `chain` (string): e.g. `base`, `ethereum`, `polygon`
- `intent` (string): one of:
  - `wallet_overview`
  - `prepare_transfer`
  - `prepare_swap` (proposal only)
- `reason` (string): required, operator-visible
- Optional:
  - `token` (string): e.g. `USDC`
  - `to` (0x address)
  - `amount` (string)

## Call
`POST /api/agent/bankr`

Example:
```bash
curl -s -X POST "http://localhost:3000/api/agent/bankr" \
  -H "content-type: application/json" \
  -d '{
    "action":"propose",
    "reason":"Need wallet overview before planning payments",
    "chain":"base",
    "intent":"wallet_overview"
  }'
```

## Output
- `ok: true`
- `proposal`: includes a human-readable plan + machine payload
- `nextAction`: what the agent should do next (usually "operator_approve" or "fetch_status")
