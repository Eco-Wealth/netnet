# Bankr Skills Pack (v1)

These skills are **proposal-only by default**. They generate *plans* and *payloads* for BankrBot-compatible actions, but **do not execute** unless an operator explicitly approves the final step.

## Agent endpoints used
- `GET /api/agent/bankr?action=info`
- `POST /api/agent/bankr` (proposal-only; returns `nextAction`)

## Safety rules
- No private keys are ever requested or stored.
- All actions require explicit `reason`.
- Execution is disabled by default; only proposals are emitted.

## Quick acceptance (dev)
1) Start cockpit, then:
```bash
curl -s "http://localhost:3000/api/agent/bankr?action=info" | jq
curl -s -X POST "http://localhost:3000/api/agent/bankr" \
  -H "content-type: application/json" \
  -d '{"action":"propose","reason":"test","chain":"base","intent":"wallet_overview"}' | jq
```
