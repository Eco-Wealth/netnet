# Skill: Bankr Token Launch (proposal-only)

Goal: Generate a **token launch proposal** compatible with Bankr workflows:
- name / symbol
- initial supply plan
- fee routing plan (operator + inference budget + micro-retirement budget)
- deployment chain

## Inputs
- `chain` (string) e.g. `base`
- `reason` (string) required
- `token`: { `name`, `symbol`, `supply` }
- `fees`: { `operatorBps`, `inferenceBps`, `retireBps`, `recipient` }

## Call
`POST /api/agent/bankr` with:
- `intent: "token_launch"`

Example:
```bash
curl -s -X POST "http://localhost:3000/api/agent/bankr" \
  -H "content-type: application/json" \
  -d '{
    "action":"propose",
    "reason":"Draft launch plan for revenue-funded ops + micro-retirements",
    "chain":"base",
    "intent":"token_launch",
    "token":{"name":"EcoWealth Operator","symbol":"ECOOP","supply":"1000000000"},
    "fees":{"operatorBps":600,"inferenceBps":300,"retireBps":100,"recipient":"0x0000000000000000000000000000000000000000"}
  }'
```

## Output
Returns a proposal with:
- guardrails (caps + allowlists)
- execution steps (operator-confirmed)
- receipt/proof hooks for `netnet.proof.v1`
