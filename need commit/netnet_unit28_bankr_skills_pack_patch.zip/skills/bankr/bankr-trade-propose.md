# Skill: Bankr Trading Proposals (paper-first)

Goal: Let an agent propose a trade plan that can later be handed to Bankr or other execution tooling.

## Inputs
- `chain`
- `reason` (required)
- `market`: { `in`, `out` } e.g. `USDC` -> `ETH`
- `maxUsd` (optional; defaults to policy cap)

## Call
`POST /api/agent/bankr` with:
- `intent: "trade_proposal"`

Example:
```bash
curl -s -X POST "http://localhost:3000/api/agent/bankr" \
  -H "content-type: application/json" \
  -d '{
    "action":"propose",
    "reason":"Paper plan only",
    "chain":"base",
    "intent":"trade_proposal",
    "market":{"in":"USDC","out":"ETH"},
    "maxUsd":25
  }'
```

## Safety
- proposal-only unless TRADE_ENABLED is explicitly turned on elsewhere
- caps + allowlists enforced
