# Proof Objects (netnet.proof.v1)

`POST /api/proof/build` builds a deterministic proof object and returns share text.

## Request (recommended)

```json
{
  "kind": "bridge_retirement",
  "subject": { "agentId": "netnet-01", "wallet": "0x...", "operator": "brandon" },
  "refs": { "txHash": "0x...", "certificateId": "abc123", "url": "https://..." },
  "claims": { "amount": 1.23, "token": "USDC", "chain": "base" }
}
```

## Request (compat)

Top-level `txHash`, `certificateId`, and `url` are accepted for older skills/docs.

## Response

```json
{
  "ok": true,
  "proof": { "schema": "netnet.proof.v1", "id": "...", "kind": "...", "timestamp": "...", "refs": { ... }, "claims": { ... } },
  "post": { "short": "...", "long": "..." }
}
```
