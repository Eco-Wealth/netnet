import crypto from "crypto";

export type ProofKind =
  | "x402"
  | "bridge_retirement"
  | "ecotoken_scan"
  | "agent_action"
  | "trade_attempt";

export type ProofObjectV1 = {
  schema: "netnet.proof.v1";
  id: string; // sha256 of canonical payload
  kind: ProofKind;
  timestamp: string; // ISO
  subject?: { agentId?: string; wallet?: string; operator?: string };
  refs?: { txHash?: string; certificateId?: string; url?: string; chain?: string; token?: string };
  claims?: Record<string, unknown>;
  signatures?: { type: string; value: string }[];
};

// Canonicalize JSON with stable key ordering (deterministic)
function canonicalize(value: unknown): string {
  const seen = new WeakSet();
  const sorter = (v: any): any => {
    if (v === null || typeof v !== "object") return v;
    if (seen.has(v)) return v; // avoid cycles (shouldn't happen)
    seen.add(v);
    if (Array.isArray(v)) return v.map(sorter);
    const out: Record<string, any> = {};
    Object.keys(v)
      .sort()
      .forEach((k) => {
        out[k] = sorter(v[k]);
      });
    return out;
  };
  return JSON.stringify(sorter(value));
}

export function computeProofId(proof: Omit<ProofObjectV1, "id">): string {
  const canon = canonicalize(proof);
  return crypto.createHash("sha256").update(canon).digest("hex");
}

export function buildProof(input: {
  kind: ProofKind;
  timestamp?: string;
  subject?: ProofObjectV1["subject"];
  refs?: ProofObjectV1["refs"];
  claims?: ProofObjectV1["claims"];
  signatures?: ProofObjectV1["signatures"];
}): ProofObjectV1 {
  const base: Omit<ProofObjectV1, "id"> = {
    schema: "netnet.proof.v1",
    kind: input.kind,
    timestamp: input.timestamp ?? new Date().toISOString(),
    subject: input.subject,
    refs: input.refs,
    claims: input.claims ?? {},
    signatures: input.signatures ?? [],
  };
  const id = computeProofId(base);
  return { ...base, id };
}

export function buildPosts(proof: ProofObjectV1, opts?: { baseUrl?: string }) {
  const tx = proof.refs?.txHash;
  const cert = proof.refs?.certificateId;
  const url = proof.refs?.url;
  const base = opts?.baseUrl?.replace(/\/$/, "");

  const links: string[] = [];
  if (url) links.push(url);
  if (base && tx) links.push(`${base}/retire?txHash=${encodeURIComponent(tx)}`);
  if (base && cert) links.push(`${base}/proof?certificateId=${encodeURIComponent(cert)}`);

  const what =
    proof.kind === "bridge_retirement"
      ? "Carbon retirement initiated / verified"
      : proof.kind === "x402"
        ? "Paid proof check"
        : proof.kind === "trade_attempt"
          ? "Trade attempt (dry-run by default)"
          : "Agent action";

  const why =
    proof.kind === "bridge_retirement"
      ? "This is a verifiable step toward carbon-neutral operations."
      : "This is a verifiable, machine-readable action proof.";

  const shortCore = `${what}. id:${proof.id.slice(0, 10)}${tx ? ` tx:${tx.slice(0, 10)}…` : ""}${cert ? ` cert:${cert}` : ""}`;
  const shortLinks = links.length ? ` ${links.join(" ")}` : "";
  const short = (shortCore + shortLinks).slice(0, 280);

  const longLines = [
    what,
    `• schema: ${proof.schema}`,
    `• kind: ${proof.kind}`,
    `• id: ${proof.id}`,
    proof.timestamp ? `• time: ${proof.timestamp}` : null,
    tx ? `• txHash: ${tx}` : null,
    cert ? `• certificateId: ${cert}` : null,
    url ? `• url: ${url}` : null,
    `• why it matters: ${why}`,
    links.length ? `• links: ${links.join(" ")}` : null,
  ].filter(Boolean) as string[];

  const long = longLines.join("\n");
  return { short, long };
}
