# Skill: Build Proof Object (netnet.proof.v1)

## Endpoint
`POST /api/proof/build`

## Purpose
Turn an on-chain artifact (tx hash, certificate id, links) into:
- a deterministic machine-readable proof object
- a human-shareable short and long post

## Inputs (preferred)
- `kind` (string): `bridge_retirement | x402 | ecotoken_scan | agent_action | trade_attempt`
- `subject` (object, optional)
- `refs` (object, optional): `txHash`, `certificateId`, `url`, `chain`, `token`
- `claims` (object, optional)

## Inputs (compat)
- `txHash`, `certificateId`, `url` may be provided at the top level.

## Example
```bash
curl -s http://localhost:3000/api/proof/build \
  -H "content-type: application/json" \
  -d '{"kind":"bridge_retirement","refs":{"txHash":"0x..."},"claims":{"chain":"base","token":"USDC","amount":1}}'
```

## Expected Output
- `proof.id` is stable for identical inputs (including timestamp if supplied)
- `post.short` is <= 280 chars
- `post.long` is multi-line and includes identifiers + links
