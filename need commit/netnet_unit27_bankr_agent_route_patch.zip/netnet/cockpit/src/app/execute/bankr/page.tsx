"use client";

import { useMemo, useState } from "react";

type BankrJob = any;

export default function BankrExecutePage() {
  const [prompt, setPrompt] = useState("");
  const [job, setJob] = useState<BankrJob | null>(null);
  const [jobId, setJobId] = useState<string>("");
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string>("");

  const statusUrl = useMemo(() => (jobId ? `/api/agent/bankr?action=status&jobId=${encodeURIComponent(jobId)}` : ""), [jobId]);

  async function propose() {
    setErr("");
    setLoading(true);
    setJob(null);
    setJobId("");
    try {
      const res = await fetch("/api/agent/bankr", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ prompt, mode: "PROPOSE" }),
      });
      const j = await res.json();
      if (!res.ok || !j?.ok) throw new Error(j?.error?.message || "request failed");
      setJob(j);
      setJobId(j.jobId);
    } catch (e: any) {
      setErr(String(e?.message || e));
    } finally {
      setLoading(false);
    }
  }

  async function refresh() {
    if (!statusUrl) return;
    setErr("");
    setLoading(true);
    try {
      const res = await fetch(statusUrl);
      const j = await res.json();
      if (!res.ok || !j?.ok) throw new Error(j?.error?.message || "status failed");
      setJob(j);
    } catch (e: any) {
      setErr(String(e?.message || e));
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="mx-auto max-w-xl p-4 space-y-4">
      <h1 className="text-xl font-semibold">Bankr (proposal-only)</h1>
      <p className="text-sm opacity-80">
        This creates a Bankr job for planning/review. It does not sign/submit transactions from this UI.
      </p>

      <div className="space-y-2">
        <textarea
          className="w-full min-h-[140px] rounded-lg border p-3 text-sm"
          placeholder="Describe what you want Bankr to do (e.g., 'Plan a token launch, show steps, do not execute.')"
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
        />
        <button
          className="w-full rounded-lg border px-4 py-2 text-sm disabled:opacity-50"
          disabled={loading || !prompt.trim()}
          onClick={propose}
        >
          {loading ? "Working…" : "Propose (create job)"}
        </button>
        {jobId ? (
          <button className="w-full rounded-lg border px-4 py-2 text-sm disabled:opacity-50" disabled={loading} onClick={refresh}>
            Refresh status
          </button>
        ) : null}
      </div>

      {err ? <div className="rounded-lg border p-3 text-sm text-red-600">{err}</div> : null}

      {job ? (
        <pre className="rounded-lg border p-3 text-xs overflow-auto whitespace-pre-wrap">{JSON.stringify(job, null, 2)}</pre>
      ) : null}
    </div>
  );
}
