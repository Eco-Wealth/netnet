import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";

import { rateLimit } from "@/lib/http/ratelimit";
import { jsonError, okJson } from "@/lib/http/errors";
import { bankrPrompt, bankrGetJob } from "@/lib/bankr/client";

/**
 * Agent-facing Bankr surface.
 * Safe-by-default: proposal-only (PROPOSE) unless BANKR_EXECUTION_ENABLED=true.
 *
 * Supported:
 *  GET  /api/agent/bankr?action=info
 *  GET  /api/agent/bankr?action=status&jobId=...
 *  POST /api/agent/bankr  { prompt, mode?: "PROPOSE" | "EXECUTE" }
 */
const ActionSchema = z.enum(["info", "status"]);
const ModeSchema = z.enum(["PROPOSE", "EXECUTE"]).default("PROPOSE");

const StatusQuerySchema = z.object({
  action: z.literal("status"),
  jobId: z.string().min(6, "jobId is required"),
});

const PostBodySchema = z.object({
  prompt: z.string().min(1, "prompt is required").max(8000, "prompt too long"),
  mode: ModeSchema.optional(),
  // optional metadata (kept for future policy engine hooks)
  beneficiaryName: z.string().min(1).max(120).optional(),
  reason: z.string().min(1).max(280).optional(),
});

function isExecutionEnabled() {
  return (process.env.BANKR_EXECUTION_ENABLED || "").toLowerCase() === "true";
}

export async function GET(req: NextRequest) {
  const rl = rateLimit(req, { key: "agent:bankr:get", limit: 60, windowMs: 60_000 });
  if (!rl.ok) return jsonError(429, { code: "RATE_LIMITED", message: "Too many requests" });

  const url = new URL(req.url);
  const actionRaw = url.searchParams.get("action") || "info";

  const parsedAction = ActionSchema.safeParse(actionRaw);
  if (!parsedAction.success) {
    return jsonError(400, { code: "BAD_REQUEST", message: "Invalid action", details: parsedAction.error.flatten() });
  }

  if (parsedAction.data === "info") {
    return okJson({
      ok: true,
      actions: ["info", "status", "propose"],
      safety: {
        modeDefault: "PROPOSE",
        executionEnabled: isExecutionEnabled(),
        note: "This endpoint does not submit transactions by default. It only requests a Bankr job for proposal/preview.",
      },
      nextAction: "POST to propose a plan",
    });
  }

  const query = StatusQuerySchema.safeParse({
    action: "status",
    jobId: url.searchParams.get("jobId"),
  });

  if (!query.success) {
    return jsonError(400, { code: "BAD_REQUEST", message: "Invalid status query", details: query.error.flatten() });
  }

  try {
    const job = await bankrGetJob(query.data.jobId);
    return okJson({ ok: true, job, nextAction: job?.status === "completed" ? "review" : "poll" });
  } catch (e: any) {
    return jsonError(502, { code: "UPSTREAM_ERROR", message: "Bankr job lookup failed", details: String(e?.message || e) });
  }
}

export async function POST(req: NextRequest) {
  const rl = rateLimit(req, { key: "agent:bankr:post", limit: 20, windowMs: 60_000 });
  if (!rl.ok) return jsonError(429, { code: "RATE_LIMITED", message: "Too many requests" });

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return jsonError(400, { code: "BAD_REQUEST", message: "Invalid JSON body" });
  }

  const parsed = PostBodySchema.safeParse(body);
  if (!parsed.success) {
    return jsonError(400, { code: "BAD_REQUEST", message: "Invalid request body", details: parsed.error.flatten() });
  }

  const mode = (parsed.data.mode || "PROPOSE") as z.infer<typeof ModeSchema>;
  if (mode === "EXECUTE" && !isExecutionEnabled()) {
    return jsonError(403, {
      code: "EXECUTION_DISABLED",
      message: "BANKR execution is disabled by default. Set BANKR_EXECUTION_ENABLED=true to enable (not recommended).",
    });
  }

  // For now: both PROPOSE and EXECUTE map to Bankr "prompt" job creation.
  // Actual submit/sign flows are intentionally NOT exposed here yet (Unit 28+),
  // and should remain operator-gated with explicit spend caps.
  try {
    const job = await bankrPrompt({
      prompt: parsed.data.prompt,
      metadata: {
        mode,
        beneficiaryName: parsed.data.beneficiaryName,
        reason: parsed.data.reason,
      },
    });

    return okJson({
      ok: true,
      mode,
      jobId: job.jobId,
      job,
      nextAction: "status",
      statusUrl: `/api/agent/bankr?action=status&jobId=${encodeURIComponent(job.jobId)}`,
    });
  } catch (e: any) {
    return jsonError(502, { code: "UPSTREAM_ERROR", message: "Bankr prompt failed", details: String(e?.message || e) });
  }
}
