# Bankr Agent Surface (netnet)

Endpoints:

- `GET /api/agent/bankr?action=info`
- `GET /api/agent/bankr?action=status&jobId=...`
- `POST /api/agent/bankr`

Safe-by-default:
- Only creates a Bankr job (proposal/preview).
- No signing or submission is exposed here yet.
- Execution mode is disabled unless `BANKR_EXECUTION_ENABLED=true` (not recommended).

Example: propose a plan

```bash
curl -sS -X POST http://localhost:3000/api/agent/bankr \
  -H 'content-type: application/json' \
  -d '{"prompt":"Draft a safe token-launch checklist. Do not execute."}'
```

Then poll:

```bash
curl -sS "http://localhost:3000/api/agent/bankr?action=status&jobId=<jobId>"
```
