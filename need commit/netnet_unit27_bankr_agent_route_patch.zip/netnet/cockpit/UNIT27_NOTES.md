UNIT 27 — Bankr Agent Route (proposal-only)

What shipped:
- /api/agent/bankr (info/status + POST propose)
- /execute/bankr UI page for manual testing

What is intentionally NOT shipped:
- Any signing/submitting of transactions (must remain operator-gated + spend-capped).
- Any private key handling.

Next:
- Unit 28: add explicit “plan -> approve -> sign -> submit” state machine with caps + allowlists, wired into policy engine.
