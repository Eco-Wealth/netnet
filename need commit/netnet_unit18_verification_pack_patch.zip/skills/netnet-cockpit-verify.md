# netnet-cockpit-verify (Unit 18)

Purpose: given a Bridge tx hash, return a single packet that an agent can use to verify completion and produce proof artifacts.

## Call

GET /api/agent/carbon?action=verify&txHash=<txHash>

## Interpret

- If `nextAction` is `wait`, poll again later.
- If `nextAction` is `proof`, call `/api/proof/build` to generate a `netnet.proof.v1` JSON object for sharing/audit.
