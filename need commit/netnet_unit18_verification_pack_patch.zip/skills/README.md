# Skills

- netnet-cockpit.md
- netnet-cockpit-carbon.md
- netnet-cockpit-trade-stub.md
- netnet-cockpit-verify.md (Unit 18)
