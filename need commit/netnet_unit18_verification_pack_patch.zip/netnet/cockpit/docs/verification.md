# Verification Skill Pack (Unit 18)

This unit adds a **single verification surface** that composes:
- Bridge transaction status (pending/completed)
- Certificate reference (if present)
- Deterministic external verification links (Bridge + ecoToken scan)

## Endpoint

`GET /api/agent/carbon?action=verify&txHash=<hash>`

### Response (shape)

```json
{
  "ok": true,
  "action": "verify",
  "verification": {
    "txHash": "0x...",
    "status": "PENDING|COMPLETED|...",
    "completed": false,
    "chainId": 8453,
    "certificateId": "abc123",
    "links": {
      "ecoTokenScan": "https://scan.ecotoken.earth/?tx=...",
      "bridgeTx": "https://bridge.eco/tx/...",
      "bridgeCertificate": "https://bridge.eco/certificates/..."
    }
  },
  "nextAction": "wait|proof"
}
```

## Agent semantics

- `nextAction="wait"`: poll again later.
- `nextAction="proof"`: the agent can call `/api/proof/build` using the tx/certificate references and generate a proof object for sharing/auditing.
