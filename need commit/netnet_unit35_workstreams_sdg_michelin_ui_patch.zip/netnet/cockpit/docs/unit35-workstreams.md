# Unit 35 — Workstreams UI (SDG Ops + Michelin Standard)

Adds a new cockpit page at `/workstreams` for proposing operator-approved work items with a clear, safe-by-default packet.

## What it is
- Centered UI for:
  - selecting a workstream
  - viewing a checklist (hover descriptions + SDG tags)
  - building a **proposal JSON** (copy-to-clipboard)

## What it is not (yet)
- No execution.
- No persistence.
- No server proof-building call.

## Next units it enables
- Wire proposal → policy engine → `/api/proof/build`.
- Persist proposals + approvals.
- Add templates for Bankr token ops, trading, retirements.
