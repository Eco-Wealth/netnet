"use client";

import { useMemo, useState } from "react";

type SafetyClass = "READ_ONLY" | "PROPOSE_ONLY" | "EXECUTE_WITH_LIMITS";

type ChecklistItem = {
  id: string;
  label: string;
  description: string;
  sdgs?: number[];
  defaultRisk: "low" | "medium" | "high";
};

type Workstream = {
  id: string;
  title: string;
  intent: string;
  ownerRole: string;
  safetyClass: SafetyClass;
  checklist: ChecklistItem[];
};

const WORKSTREAMS: Workstream[] = [
  {
    id: "sdg-ops",
    title: "SDG Ops Workstream",
    intent: "Turn ideas into measurable, auditable operations: plan → approve → execute → prove.",
    ownerRole: "Operator",
    safetyClass: "PROPOSE_ONLY",
    checklist: [
      {
        id: "define-scope",
        label: "Define scope + success metric",
        description: "Write one sentence: what changes, for who, by when, how we measure.",
        sdgs: [8, 9, 12, 13],
        defaultRisk: "low",
      },
      {
        id: "estimate-cost",
        label: "Estimate time + spend",
        description: "Rough budget: labor hours, inference budget, on-chain fees.",
        sdgs: [8, 12],
        defaultRisk: "medium",
      },
      {
        id: "approval",
        label: "Operator approval required",
        description: "No execution without explicit approval event and caps.",
        sdgs: [16],
        defaultRisk: "high",
      },
    ],
  },
  {
    id: "michelin",
    title: "Michelin Standard Workflow",
    intent: "Discipline, cleanliness, repeatability. Each step is a receipt.",
    ownerRole: "Chef/Operator",
    safetyClass: "PROPOSE_ONLY",
    checklist: [
      {
        id: "mise-en-place",
        label: "Mise en place",
        description: "Inputs ready, tools ready, environment clean, preflight complete.",
        sdgs: [12],
        defaultRisk: "low",
      },
      {
        id: "qa-gate",
        label: "Quality gate",
        description: "Define what \"done\" means; refuse partial execution.",
        sdgs: [9, 12],
        defaultRisk: "medium",
      },
      {
        id: "postmortem",
        label: "Postmortem + learn",
        description: "Capture what happened, costs, outputs, and next improvements.",
        sdgs: [4, 9],
        defaultRisk: "low",
      },
    ],
  },
];

type ProposedAction = {
  id: string;
  workstreamId: string;
  title: string;
  notes: string;
  inferenceBudgetUsd: number;
  maxOnchainFeesUsd: number;
  safetyClass: SafetyClass;
  createdAt: string;
};

function uid(prefix: string) {
  return `${prefix}_${Math.random().toString(16).slice(2)}_${Date.now().toString(16)}`;
}

export default function WorkstreamsPage() {
  const [selected, setSelected] = useState<string>(WORKSTREAMS[0]?.id ?? "sdg-ops");
  const ws = useMemo(() => WORKSTREAMS.find((w) => w.id === selected) ?? WORKSTREAMS[0], [selected]);

  const [title, setTitle] = useState("Define next skill improvement");
  const [notes, setNotes] = useState("One sentence goal. Include constraints and a measurable output.");
  const [inferenceBudgetUsd, setInferenceBudgetUsd] = useState(1);
  const [maxOnchainFeesUsd, setMaxOnchainFeesUsd] = useState(3);

  const [proposal, setProposal] = useState<ProposedAction | null>(null);
  const [copied, setCopied] = useState(false);

  function buildProposal() {
    const p: ProposedAction = {
      id: uid("proposal"),
      workstreamId: ws.id,
      title: title.trim() || "Untitled proposal",
      notes: notes.trim(),
      inferenceBudgetUsd: Number.isFinite(inferenceBudgetUsd) ? inferenceBudgetUsd : 1,
      maxOnchainFeesUsd: Number.isFinite(maxOnchainFeesUsd) ? maxOnchainFeesUsd : 3,
      safetyClass: ws.safetyClass,
      createdAt: new Date().toISOString(),
    };
    setProposal(p);
    setCopied(false);
  }

  async function copyJson() {
    if (!proposal) return;
    await navigator.clipboard.writeText(JSON.stringify(proposal, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 1200);
  }

  return (
    <div className="mx-auto w-full max-w-5xl px-6 py-10">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-semibold tracking-tight">Workstreams</h1>
        <p className="text-sm text-neutral-400">
          Operator cockpit for SDG ops + Michelin workflow. Build proposals, then route them into skills/execution.
        </p>
      </div>

      <div className="mt-8 grid grid-cols-1 gap-6 md:grid-cols-12">
        <div className="md:col-span-4">
          <div className="rounded-2xl border border-neutral-800 bg-neutral-950/40 p-4">
            <div className="text-xs uppercase tracking-wider text-neutral-500">Select</div>
            <div className="mt-3 flex flex-col gap-2">
              {WORKSTREAMS.map((w) => (
                <button
                  key={w.id}
                  onClick={() => setSelected(w.id)}
                  className={[
                    "rounded-xl border px-3 py-3 text-left transition",
                    selected === w.id
                      ? "border-neutral-700 bg-neutral-900/60"
                      : "border-neutral-900 bg-neutral-950/20 hover:border-neutral-800 hover:bg-neutral-900/30",
                  ].join(" ")}
                >
                  <div className="flex items-center justify-between gap-3">
                    <div className="font-medium">{w.title}</div>
                    <span className="rounded-full border border-neutral-800 bg-neutral-950/40 px-2 py-0.5 text-[11px] text-neutral-400">
                      {w.safetyClass}
                    </span>
                  </div>
                  <div className="mt-1 text-xs text-neutral-400">{w.intent}</div>
                </button>
              ))}
            </div>
          </div>

          <div className="mt-6 rounded-2xl border border-neutral-800 bg-neutral-950/40 p-4">
            <div className="text-xs uppercase tracking-wider text-neutral-500">Checklist</div>
            <ul className="mt-3 space-y-2">
              {ws.checklist.map((c) => (
                <li key={c.id} className="group rounded-xl border border-neutral-900 bg-neutral-950/20 px-3 py-2">
                  <div className="flex items-center justify-between gap-3">
                    <div className="text-sm font-medium">{c.label}</div>
                    <span
                      className={[
                        "rounded-full border px-2 py-0.5 text-[11px]",
                        c.defaultRisk === "low"
                          ? "border-neutral-800 text-neutral-400"
                          : c.defaultRisk === "medium"
                          ? "border-neutral-700 text-neutral-300"
                          : "border-neutral-600 text-neutral-200",
                      ].join(" ")}
                      title="Default risk level"
                    >
                      {c.defaultRisk}
                    </span>
                  </div>
                  <div
                    className="mt-1 text-xs text-neutral-500 group-hover:text-neutral-400 transition"
                    title={c.description}
                  >
                    {c.description}
                  </div>
                  {c.sdgs?.length ? (
                    <div className="mt-2 flex flex-wrap gap-1">
                      {c.sdgs.map((n) => (
                        <span
                          key={n}
                          className="rounded-full border border-neutral-900 bg-neutral-950/20 px-2 py-0.5 text-[11px] text-neutral-500"
                          title="UN SDG reference (tag only)"
                        >
                          SDG {n}
                        </span>
                      ))}
                    </div>
                  ) : null}
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="md:col-span-8">
          <div className="rounded-2xl border border-neutral-800 bg-neutral-950/40 p-5">
            <div className="flex items-start justify-between gap-4">
              <div>
                <div className="text-xs uppercase tracking-wider text-neutral-500">Propose action</div>
                <div className="mt-2 text-lg font-semibold">{ws.title}</div>
                <div className="mt-1 text-sm text-neutral-400">Owner role: {ws.ownerRole}</div>
              </div>
              <span className="rounded-full border border-neutral-800 bg-neutral-950/40 px-3 py-1 text-xs text-neutral-400">
                Safe-by-default: {ws.safetyClass}
              </span>
            </div>

            <div className="mt-6 grid grid-cols-1 gap-4">
              <label className="flex flex-col gap-2">
                <span className="text-xs text-neutral-500">Title</span>
                <input
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="rounded-xl border border-neutral-800 bg-neutral-950/40 px-3 py-2 text-sm outline-none focus:border-neutral-700"
                  placeholder="What are we doing?"
                />
              </label>

              <label className="flex flex-col gap-2">
                <span className="text-xs text-neutral-500">Notes</span>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="min-h-[92px] rounded-xl border border-neutral-800 bg-neutral-950/40 px-3 py-2 text-sm outline-none focus:border-neutral-700"
                  placeholder="Constraints, context, measurable output."
                />
              </label>

              <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                <label className="flex flex-col gap-2">
                  <span className="text-xs text-neutral-500" title="Hard cap for inference spend (USD).">
                    Inference budget (USD)
                  </span>
                  <input
                    type="number"
                    min={0}
                    step={0.25}
                    value={inferenceBudgetUsd}
                    onChange={(e) => setInferenceBudgetUsd(Number(e.target.value))}
                    className="rounded-xl border border-neutral-800 bg-neutral-950/40 px-3 py-2 text-sm outline-none focus:border-neutral-700"
                  />
                </label>

                <label className="flex flex-col gap-2">
                  <span className="text-xs text-neutral-500" title="Hard cap for on-chain fees (USD).">
                    Max on-chain fees (USD)
                  </span>
                  <input
                    type="number"
                    min={0}
                    step={0.25}
                    value={maxOnchainFeesUsd}
                    onChange={(e) => setMaxOnchainFeesUsd(Number(e.target.value))}
                    className="rounded-xl border border-neutral-800 bg-neutral-950/40 px-3 py-2 text-sm outline-none focus:border-neutral-700"
                  />
                </label>
              </div>

              <div className="flex flex-wrap items-center gap-3">
                <button
                  onClick={buildProposal}
                  className="rounded-xl border border-neutral-700 bg-neutral-900/60 px-4 py-2 text-sm font-medium hover:bg-neutral-900 transition"
                  title="Build a proposal packet (no execution)."
                >
                  Build proposal
                </button>

                {proposal ? (
                  <button
                    onClick={copyJson}
                    className="rounded-xl border border-neutral-800 bg-neutral-950/30 px-4 py-2 text-sm text-neutral-300 hover:border-neutral-700 hover:bg-neutral-950/50 transition"
                    title="Copy JSON to clipboard (send to agent / operator)."
                  >
                    {copied ? "Copied" : "Copy JSON"}
                  </button>
                ) : null}

                <div className="text-xs text-neutral-500">
                  Next: route proposal into a skill (operator approval) → proof-of-action.
                </div>
              </div>
            </div>
          </div>

          <div className="mt-6 rounded-2xl border border-neutral-800 bg-neutral-950/40 p-5">
            <div className="text-xs uppercase tracking-wider text-neutral-500">Proposal packet</div>
            <pre className="mt-3 overflow-auto rounded-xl border border-neutral-900 bg-neutral-950/20 p-3 text-xs text-neutral-200">
{proposal ? JSON.stringify(proposal, null, 2) : "// Build a proposal to generate a packet."}
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
}
