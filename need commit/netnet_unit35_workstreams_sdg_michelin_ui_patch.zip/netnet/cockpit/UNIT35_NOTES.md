Unit 35: Workstreams UI
- Adds /workstreams page (client) for SDG Ops + Michelin workflow proposals.
- Generates proposal JSON packets with budgets + safety class.
- Designed to be wired into policy engine + proof-of-action in follow-on unit.
