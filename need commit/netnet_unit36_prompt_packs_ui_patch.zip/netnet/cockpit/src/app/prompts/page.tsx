  "use client";

  import { useMemo, useState } from "react";
  import { PROMPT_PACKS } from "@/lib/promptPacks";

  function CopyButton({ text }: { text: string }) {
    const [copied, setCopied] = useState(false);

    return (
      <button
        className="rounded-lg border px-3 py-1 text-sm hover:bg-black/5 active:scale-[0.98]"
        onClick={async () => {
          await navigator.clipboard.writeText(text);
          setCopied(true);
          window.setTimeout(() => setCopied(false), 900);
        }}
      >
        {copied ? "Copied" : "Copy"}
      </button>
    );
  }

  export default function PromptsPage() {
    const packs = useMemo(() => PROMPT_PACKS, []);

    return (
      <main className="mx-auto max-w-4xl px-4 py-8">
        <div className="mb-6">
          <h1 className="text-2xl font-semibold">Prompt Packs</h1>
          <p className="mt-2 text-sm opacity-80">
            Context-window efficient prompts for adding skills and running operator workflows.
            Replace the placeholders (e.g. <code>{"{{SKILL_REQUEST}}"}</code>) before use.
          </p>
        </div>

        <div className="grid gap-4">
          {packs.map((p) => (
            <section key={p.id} className="rounded-2xl border bg-white p-4 shadow-sm">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <div className="text-lg font-medium">{p.title}</div>
                  <div className="mt-1 text-xs opacity-70">
                    intent: <span className="font-mono">{p.intent}</span> · tokens: {p.tokensHint}
                  </div>
                </div>
                <CopyButton text={p.prompt} />
              </div>

              <pre className="mt-3 overflow-auto rounded-xl bg-black/5 p-3 text-xs leading-relaxed">
{p.prompt}
              </pre>
            </section>
          ))}
        </div>
      </main>
    );
  }
