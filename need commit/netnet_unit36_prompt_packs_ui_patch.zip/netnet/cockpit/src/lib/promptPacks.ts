export type PromptPack = {
  id: string;
  title: string;
  intent: "read_only" | "propose_only" | "execute_with_limits";
  tokensHint: string; // human hint, not a calculator
  prompt: string;
};

// Unit 36: context-window efficient prompt packs for operators + agents.
// Designed to be copy/pasteable, stable, and short.
export const PROMPT_PACKS: PromptPack[] = [
  {
    id: "skill-add",
    title: "Add a skill (safe-by-default)",
    intent: "propose_only",
    tokensHint: "~250-450 tokens",
    prompt: [
      "You are NetNet Agent Builder.",
      "Goal: add ONE new skill to netnet/cockpit.",
      "Constraints:",
      "- Safe-by-default: READ_ONLY unless explicitly approved.",
      "- Output a patch plan + exact file paths + API contract (req/resp).",
      "- Include: what will happen, estimated costs, requires approval.",
      "- No secrets; use env vars + .env.example updates.",
      "",
      "Skill request:",
      "{{SKILL_REQUEST}}",
    ].join("\n"),
  },
  {
    id: "trade-plan",
    title: "Generate a trade plan (paper by default)",
    intent: "propose_only",
    tokensHint: "~200-350 tokens",
    prompt: [
      "You are a trading assistant operating under strict policy.",
      "Return JSON only.",
      "Rules:",
      "- Default DRY_RUN / paper mode.",
      "- Enforce allowlists, maxUsd, maxPerDay.",
      "- Output must include 'requiresApproval': true.",
      "",
      "Input:",
      "{{TRADE_INPUT_JSON}}",
    ].join("\n"),
  },
  {
    id: "retire-proof",
    title: "Retirement → proof packet (operator handoff)",
    intent: "propose_only",
    tokensHint: "~250-400 tokens",
    prompt: [
      "You are NetNet carbon operator assistant.",
      "Given a retirement intent + quote + tx/cert refs, produce:",
      "1) nextAction",
      "2) operator handoff packet (payment / confirmations)",
      "3) proof-of-action object (netnet.proof.v1)",
      "Keep it concise. No speculation.",
      "",
      "Input:",
      "{{RETIREMENT_CONTEXT_JSON}}",
    ].join("\n"),
  },
];
