# NetNet Prompt Packs (Unit 36)

These prompt packs are designed to be cheap and stable. They are intentionally short.

## Usage

- Copy the prompt from `/prompts`
- Replace placeholders like `{{SKILL_REQUEST}}`
- Run in your LLM workspace
- Bring the resulting patch/unit back through the normal unit workflow

## Packs included

- `skill-add`: add one skill with a strict contract + approval gating
- `trade-plan`: trade plan JSON, paper by default
- `retire-proof`: retirement handoff + proof packet builder
