#!/usr/bin/env bash
set -euo pipefail

BASE_URL="${BASE_URL:-http://localhost:3000}"

echo "[smoke] BASE_URL=$BASE_URL"

# 1) Health must always be 200
echo "[smoke] GET /api/health (expect 200)"
code="$(curl -s -o /tmp/netnet_health.json -w "%{http_code}" "$BASE_URL/api/health")"
if [[ "$code" != "200" ]]; then
  echo "FAIL: /api/health expected 200, got $code"
  cat /tmp/netnet_health.json || true
  exit 1
fi
echo "OK"

# 2) Paywalled endpoint should return 402 unless bypass is enabled
if [[ "${X402_DEV_BYPASS:-}" == "true" ]]; then
  echo "[smoke] GET /api/proof-paid (bypass=true expect 200)"
  code="$(curl -s -o /tmp/netnet_proof_paid.json -w "%{http_code}" "$BASE_URL/api/proof-paid")"
  if [[ "$code" != "200" ]]; then
    echo "FAIL: /api/proof-paid expected 200 with bypass, got $code"
    cat /tmp/netnet_proof_paid.json || true
    exit 1
  fi
  echo "OK"
else
  echo "[smoke] GET /api/proof-paid (bypass!=true expect 402)"
  code="$(curl -s -o /tmp/netnet_proof_paid.json -w "%{http_code}" "$BASE_URL/api/proof-paid")"
  if [[ "$code" != "402" ]]; then
    echo "FAIL: /api/proof-paid expected 402, got $code"
    cat /tmp/netnet_proof_paid.json || true
    exit 1
  fi
  echo "OK"
fi

# 3) Bridge registry (optional) - only if env appears configured
if [[ -n "${BRIDGE_ECO_API_BASE_URL:-}" || -n "${BRIDGE_API_BASE_URL:-}" ]]; then
  echo "[smoke] GET /api/bridge/registry (expect 200)"
  code="$(curl -s -o /tmp/netnet_bridge_registry.json -w "%{http_code}" "$BASE_URL/api/bridge/registry")"
  if [[ "$code" != "200" ]]; then
    echo "FAIL: /api/bridge/registry expected 200, got $code"
    cat /tmp/netnet_bridge_registry.json || true
    exit 1
  fi
  echo "OK"
else
  echo "[smoke] SKIP /api/bridge/registry (Bridge env not set)"
fi

echo "[smoke] PASS"
