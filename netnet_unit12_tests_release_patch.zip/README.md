# netnet

## Quickstart

**Requirements**
- Node >= 20 (see `.nvmrc`)
- npm >= 9

**Run**
```bash
npm install
npm run dev
```

Open: http://localhost:3000

## Smoke tests

With the dev server running in another terminal:
```bash
npm run smoke
```

Or run Playwright smoke (will start a dev server automatically):
```bash
npm test
```

## Release checklist

- [ ] `npm install` clean
- [ ] `npm run build` succeeds
- [ ] `npm run smoke` passes
- [ ] `npm test` (Playwright smoke) passes
- [ ] Confirm paywall behavior:
  - `curl -i http://localhost:3000/api/proof-paid` returns **402** unless `X402_DEV_BYPASS=true`
- [ ] Verify env vars set in Vercel (prod) and VPS (optional):
  - X402_PAY_TO (required for real paywall)
  - X402_DEV_BYPASS (dev only; keep unset/false in prod)
  - Bridge env vars (for retirement flow)
- [ ] No secrets committed: review `git diff --cached`

