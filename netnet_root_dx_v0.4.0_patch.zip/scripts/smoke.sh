#!/usr/bin/env bash
set -euo pipefail

BASE_URL="${BASE_URL:-http://localhost:3000}"

echo "==> health"
curl -fsS "$BASE_URL/api/health" | sed 's/^/   /'

echo "==> proof-paid (expects 402 unless X402_DEV_BYPASS=true)"
status=$(curl -s -o /dev/null -w "%{http_code}" "$BASE_URL/api/proof-paid" || true)
if [[ "${X402_DEV_BYPASS:-}" == "true" ]]; then
  if [[ "$status" != "200" ]]; then
    echo "Expected 200 but got $status"
    exit 1
  fi
else
  if [[ "$status" != "402" ]]; then
    echo "Expected 402 but got $status"
    exit 1
  fi
fi

echo "==> bridge registry (skips if BRIDGE_API_BASE_URL not set)"
if [[ -n "${BRIDGE_API_BASE_URL:-}" ]]; then
  curl -fsS "$BASE_URL/api/bridge/registry" | sed 's/^/   /'
else
  echo "   (skipped: BRIDGE_API_BASE_URL not set)"
fi

echo "OK"
