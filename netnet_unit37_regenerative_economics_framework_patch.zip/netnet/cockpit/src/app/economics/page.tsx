import { Shell } from "@/components/Shell";

async function getCatalog() {
  const res = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL || ""}/api/econ/capitals`, {
    cache: "no-store",
  }).catch(() => null);

  if (!res || !res.ok) return null;
  return res.json();
}

export default async function EconomicsPage() {
  const catalog = await getCatalog();

  return (
    <Shell title="Economics" subtitle="Regenerative capitals + principles (planning layer)">
      <div className="space-y-6">
        <div className="rounded-2xl border border-white/10 bg-white/5 p-5">
          <div className="text-sm text-white/70">
            This is a shared scoring vocabulary for humans + agents. It produces planning outputs (no execution).
          </div>
          <div className="mt-3 text-xs text-white/50">
            Endpoints: <span className="font-mono">GET /api/econ/capitals</span>,{" "}
            <span className="font-mono">POST /api/econ/delta</span>
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-2">
          <div className="rounded-2xl border border-white/10 bg-white/5 p-5">
            <div className="text-base font-semibold">Capitals</div>
            <div className="mt-3 space-y-3">
              {(catalog?.capitals || []).map((c: any) => (
                <div key={c.id} className="rounded-xl border border-white/10 bg-black/20 p-3 hover:bg-black/30">
                  <div className="flex items-center justify-between">
                    <div className="font-medium">{c.label}</div>
                    <div className="text-xs font-mono text-white/50">{c.id}</div>
                  </div>
                  <div className="mt-1 text-sm text-white/70">{c.description}</div>
                  {Array.isArray(c.examples) && c.examples.length > 0 && (
                    <div className="mt-2 text-xs text-white/50">
                      Examples: {c.examples.slice(0, 3).join(" · ")}
                    </div>
                  )}
                </div>
              ))}
              {!catalog && <div className="text-sm text-white/60">Catalog unavailable (dev fetch). Use /api/econ/capitals.</div>}
            </div>
          </div>

          <div className="rounded-2xl border border-white/10 bg-white/5 p-5">
            <div className="text-base font-semibold">Principles</div>
            <div className="mt-3 space-y-3">
              {(catalog?.principles || []).map((p: any) => (
                <div key={p.id} className="rounded-xl border border-white/10 bg-black/20 p-3 hover:bg-black/30">
                  <div className="flex items-center justify-between">
                    <div className="font-medium">{p.label}</div>
                    <div className="text-xs font-mono text-white/50">{p.id}</div>
                  </div>
                  <div className="mt-1 text-sm text-white/70">{p.why}</div>
                  {Array.isArray(p.checks) && p.checks.length > 0 && (
                    <ul className="mt-2 list-disc pl-5 text-xs text-white/55">
                      {p.checks.slice(0, 3).map((x: string) => (
                        <li key={x}>{x}</li>
                      ))}
                    </ul>
                  )}
                </div>
              ))}
              {!catalog && <div className="text-sm text-white/60">Catalog unavailable (dev fetch). Use /api/econ/capitals.</div>}
            </div>
          </div>
        </div>
      </div>
    </Shell>
  );
}
