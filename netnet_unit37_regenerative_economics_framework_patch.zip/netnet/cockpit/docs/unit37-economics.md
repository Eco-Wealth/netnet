# Unit 37 — Regenerative Economics Framework

Adds a planning layer:
- Capitals + principles catalog
- Action→capital delta packet (schema netnet.econ.delta.v1)
- UI page at /economics

Endpoints:
- GET /api/econ/capitals
- POST /api/econ/delta
