import RunProgramsClient from "./run-programs-client";

export const dynamic = "force-dynamic";

export default function ProgramsRunPage() {
  return <RunProgramsClient />;
}
